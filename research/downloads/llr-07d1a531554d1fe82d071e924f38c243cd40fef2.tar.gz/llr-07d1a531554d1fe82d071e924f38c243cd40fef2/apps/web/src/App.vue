<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, onMounted, reactive, ref, shallowRef, watch } from "vue";
import { PipelineRenderer, parseDcpTables, type EditParams, type ProfileCurve, type ViewWindow } from "./rendering/pipeline-renderer";
import { sonyChromaNrSlider } from "./rendering/sony-denoise";
import { parseCameraMatch } from "./rendering/camera-match";
import { loadToneFamily, rebuildLookProfile, toneFamilyLoaded } from "./rendering/sony-look";
import {
  curveToLUT, buildToneCurveLUT, defaultToneCurve, normalizeToneCurve,
  DEFAULT_BASIC, sameBasic,
  type BasicAdjust, type ToneCurve,
} from "./rendering/curve";
import {
  defaultCrop, cloneCrop, isDefaultCrop, imageDims, buildCropTransform,
  cropOutputRect, cropOutputSize, straightenedBBox, cssRecomposeMatrix, recomposeMatrix,
  applyAspectRatio, resolveAspectFraction, cropOutputSizeForAspect, CROP_GUIDES, constrainCrop,
  ASPECT_PRESETS, defaultTransform,
  type AspectPreset, type CropState,
} from "./rendering/crop";
import { API, fetchAiMasks, fetchModelStatus, fetchLinear, fetchRelightGeometry, fetchLookProfile, type ColorProfileMeta, type DenoisePayload, type ModelStatus, type LookTweaks, type LookTweakKey } from "./api";
import { type PersistedEdit } from "./edits";
import { gradingTint, gradingHueDeg } from "./rendering/grading";
import { parseLensCorr, mixLensTable, LENS_IDENTITY, type LensCorr } from "./rendering/lens";
import { cloneErase, eraseWire, lensWarp, strokeToView, viewToStroke, ERASE_MAX_LINES, ERASE_MAX_POINTS, ERASE_MAX_STROKES, type EraseStroke } from "./rendering/erase";
import { rasterBrushes, sameBrushes, type BrushStroke } from "./rendering/brush";
import { AUX_LAYER } from "./rendering/pipeline-renderer";
import { cloneRelight, defaultRelight, packRelight, relightActive, RELIGHT_MAX_LIGHTS, LIGHT_KINDS, type RelightGeometry, type RelightState } from "./rendering/relight";
import {
  packMasks, presetGroup, defaultComponent, defaultAdjust, MASK_PRESETS, MASK_GROUPS, MASK_COMPS, AI_KINDS,
  type MaskGroup, type MaskType, type MaskAdjust, type MaskPresetName, type MaskComponent,
} from "./rendering/masks";
import { formatBytes, clamp, IMPORT_ACCEPT, IMPORT_FORMAT_HINT } from "./ui";
import { buildSections, GROUP_KEYS, SORT_KEYS, type GroupKey, type SortKey } from "./librarySort";
import { pathOf, type FolderNode } from "./catalogTree";
import { t, locale, setLocale, LOCALES, type MessageKey } from "./i18n";
import SliderRow from "./components/SliderRow.vue";
import SelectMenu from "./components/SelectMenu.vue";
import Filmstrip from "./components/Filmstrip.vue";
import GroupNav from "./components/GroupNav.vue";
import FolderTree from "./components/FolderTree.vue";
import PhotoGrid from "./components/PhotoGrid.vue";
import { useViewport } from "./composables/useViewport";
import { useHistory } from "./composables/useHistory";
import { useToneCurve } from "./composables/useToneCurve";
import { useCropEditor, DEFAULT_ASPECT } from "./composables/useCropEditor";
import { useMaskEditor } from "./composables/useMaskEditor";
import { useEraseEditor } from "./composables/useEraseEditor";
import { useRelightEditor, useFocusPicker } from "./composables/useRelightEditor";
import { useWorkerAnalysis } from "./composables/useWorkerAnalysis";
import { ROOT_FOLDER_ID, useCatalog } from "./composables/useCatalog";
import { useHistogram } from "./composables/useHistogram";
import { renderPlan, useExport, type ExportPlan } from "./composables/useExport";
import { useAssistant, modelKey, THINKING_LEVELS, type AssistantTool, type ToolContent, type TurnUsage } from "./composables/useAssistant";
import { binImageThrough, measureHint, measureHistogram, measurePixels } from "./rendering/histogram";
import ModelSettings from "./components/ModelSettings.vue";
import AssistantMessage from "./components/AssistantMessage.vue";
import ChatIcon, { type ChatIconName } from "./components/ChatIcon.vue";
import { JIcon } from "@jannchie/icons-vue";
import {
  IconArrowUp, IconArrowsLeftRight, IconAsterisk, IconAperture, IconBookmark, IconCamera, IconChevronRight,
  IconCompare, IconContrast, IconCrop, IconDashedCircle, IconDownload, IconEraserSparkle, IconFlip, IconFlipVertical, IconGrid3x3, IconHistory,
  IconImage, IconLightbulb, IconCameraLens, IconCursorCrosshair, IconBrush, IconBandage, IconPalette, IconRedo, IconReset, IconRotate, IconRotateCcw, IconRuler, IconSettings, IconSliders, IconSparkle,
  IconStop, IconSun, IconUndo, IconX, IconBroom, IconCheck, IconClipboardPaste, IconCopy, IconFitToScreen, IconMinus, IconPlus,
  IconSortAscending, IconSortDescending, type Icon,
} from "@jannchie/icons";
import {
  extractRecipe, applyRecipe, serializeRecipe, parseRecipe, loadSavedRecipes, storeSavedRecipes, loadCopySections, storeCopySections,
  RECIPE_SECTIONS, DEFAULT_SECTIONS, type SavedRecipe, type RecipeData, type RecipeSection,
} from "./rendering/recipes";

// ── types ──

type RecipeKey = "exposure"|"contrast"|"highlights"|"shadows"|"whites"|"blacks"|"vibrance"|"saturation"|"temperature"|"tint"|"clarity"|"dehaze"|"lensDistortion"|"lensVignetting"|"nrLuminance"|"nrDetail"
  |"sharpAmount"|"sharpRadius"|"sharpDetail"|"sharpMasking"|"defringePurple"|"defringeGreen"
  |"blurAmount"|"blurRange"|"blurFocusX"|"blurFocusY"|"fogAmount"|"fogStart"
  |"vigAmount"|"vigMidpoint"|"vigFeather"|"vigRoundness"|"grainAmount"|"grainSize"|"grainRoughness";
type Recipe = Record<RecipeKey, number>;
// Labels are not stored: a slider's caption is always `slider.<key>` and a
// group's is `panel.<title>`, so the catalog can't drift from the controls.
type SliderSpec = { key: RecipeKey; min: number; max: number; step: number };
// needsLensCorr: the group's controls do nothing but blend the shot's own
// correction tables toward identity, so they only mean something when the file
// carried a pair (see lensCorrAvailable).
type GroupTitle = "tone" | "presence" | "color" | "lens" | "noise" | "sharpen" | "defringe" | "lensBlur" | "fog" | "vignette" | "grain";
type SliderGroup = { title: GroupTitle; tab: EditTab; items: SliderSpec[]; needsLensCorr?: boolean };

// The rail shows one group at a time, picked from the icon strip along its
// outer edge. Nine always-open panels stacked to 2400px — reaching the curve
// meant scrolling two and a half screens past controls nobody was using.
type EditTab = "light" | "color" | "masks" | "erase" | "relight" | "effects" | "recipes" | "detail" | "look" | "crop" | "assistant" | "history" | "settings";

// Distortion correction defaults to fully applied (mirrorless glass is designed
// around it — uncorrected geometry reads as broken). Vignetting stays off by
// default: natural falloff is often part of the look, so brightening the
// corners is an opt-in, not a baseline.
const defaultRecipe = (): Recipe => ({
  exposure: 0, contrast: 0, highlights: 0, shadows: 0,
  whites: 0, blacks: 0, vibrance: 0, saturation: 0,
  temperature: 6500, tint: 0, clarity: 0, dehaze: 0,
  lensDistortion: 100, lensVignetting: 0,
  nrLuminance: 0, nrDetail: 50,
  sharpAmount: 0, sharpRadius: 1, sharpDetail: 25, sharpMasking: 0,
  defringePurple: 0, defringeGreen: 0,
  // The lens blur's focus point is source-norm (y down), -1 = the frame's centre;
  // set by clicking the image, not by a slider.
  blurAmount: 0, blurRange: 20, blurFocusX: -1, blurFocusY: -1,
  fogAmount: 0, fogStart: 30,
  vigAmount: 0, vigMidpoint: 50, vigFeather: 50, vigRoundness: 0,
  grainAmount: 0, grainSize: 25, grainRoughness: 50,
});

const groups: SliderGroup[] = [
  { title: "tone", tab: "light", items: [
    { key: "exposure", min: -5, max: 5, step: 0.1 },
    { key: "contrast", min: -100, max: 100, step: 1 },
    { key: "highlights", min: -100, max: 100, step: 1 },
    { key: "shadows", min: -100, max: 100, step: 1 },
    { key: "whites", min: -100, max: 100, step: 1 },
    { key: "blacks", min: -100, max: 100, step: 1 },
  ]},
  { title: "presence", tab: "light", items: [
    { key: "clarity", min: -100, max: 100, step: 1 },
    { key: "dehaze", min: -100, max: 100, step: 1 },
  ]},
  { title: "color", tab: "color", items: [
    { key: "temperature", min: 2000, max: 12000, step: 50 },
    { key: "tint", min: -100, max: 100, step: 1 },
    { key: "vibrance", min: -100, max: 100, step: 1 },
    { key: "saturation", min: -100, max: 100, step: 1 },
  ]},
  { title: "lens", tab: "detail", needsLensCorr: true, items: [
    { key: "lensDistortion", min: 0, max: 100, step: 1 },
    { key: "lensVignetting", min: 0, max: 100, step: 1 },
  ]},
  // The display-side half of noise reduction (rendering/passes.ts
  // NOISE_LUMA_SHADER): a shader stage on the finished frame, so it drags in
  // real time, and it sits on top of whatever the RAW-domain stage below
  // took out. Lightroom's Luminance / Detail pair, on their scale.
  { title: "noise", tab: "detail", items: [
    { key: "nrLuminance", min: 0, max: 100, step: 1 },
    { key: "nrDetail", min: 0, max: 100, step: 1 },
  ]},
  // Output sharpening and defringe (passes.ts FINISH_SHADER / chromaClean):
  // Lightroom's Detail and Lens Corrections controls, on their scales.
  { title: "sharpen", tab: "detail", items: [
    { key: "sharpAmount", min: 0, max: 150, step: 1 },
    { key: "sharpRadius", min: 0.5, max: 3, step: 0.1 },
    { key: "sharpDetail", min: 0, max: 100, step: 1 },
    { key: "sharpMasking", min: 0, max: 100, step: 1 },
  ]},
  { title: "defringe", tab: "detail", items: [
    { key: "defringePurple", min: 0, max: 100, step: 1 },
    { key: "defringeGreen", min: 0, max: 100, step: 1 },
  ]},
  // Depth effects on the relight geometry, then the framing effects.
  { title: "lensBlur", tab: "effects", items: [
    { key: "blurAmount", min: 0, max: 100, step: 1 },
    { key: "blurRange", min: 0, max: 100, step: 1 },
  ]},
  { title: "fog", tab: "effects", items: [
    { key: "fogAmount", min: -100, max: 100, step: 1 },
    { key: "fogStart", min: 0, max: 100, step: 1 },
  ]},
  { title: "vignette", tab: "effects", items: [
    { key: "vigAmount", min: -100, max: 100, step: 1 },
    { key: "vigMidpoint", min: 0, max: 100, step: 1 },
    { key: "vigFeather", min: 0, max: 100, step: 1 },
    { key: "vigRoundness", min: -100, max: 100, step: 1 },
  ]},
  { title: "grain", tab: "effects", items: [
    { key: "grainAmount", min: 0, max: 100, step: 1 },
    { key: "grainSize", min: 0, max: 100, step: 1 },
    { key: "grainRoughness", min: 0, max: 100, step: 1 },
  ]},
];

// The Creative Look tweaks, in the order and on the scale of Imaging Edge
// Edit's own 创意外观 panel: 对比度/高光/阴影/白色/黑色/褪色, then 色相/饱和度,
// then 清晰, every one -100..100 (褪色 and 清晰 0..100). The camera's -9..+9
// stops are converted on the worker (five panel units per stop on the tone
// sliders, ten on 褪色/清晰, 饱和度 by the engine's own ladder), so the as-shot
// numbers here are exactly what Edit shows when it opens the file. These are
// not the Tone panel's sliders under another name — they drive Sony's own
// stages (the look's tone curve, YGamma, RGB2YCC, and Clarity's blur chain),
// which is why they live with the look instead of with our edits.
//
// Each one's range is the engine's and arrives with the profile (lookRanges),
// the way DRO's level ladder does: 清晰, for one, has no negative side at all
// — the engine clamps it at zero — and a slider that let it go there would be
// offering stops that all render the same.
const LOOK_TWEAK_ORDER = [
  "contrast", "highlights", "shadows", "white", "black", "fade", "hue", "saturation", "clarity",
] as const;
// Sessions saved before the panel scale stored the camera's stops. The same
// conversion the worker does (sony/profile.py stops_to_panel), so a restored
// session lands where it rendered; the three sliders the camera lacks were
// never stored and start at zero.
const LOOK_SCALE = "panel";
const SATURATION_STOPS = [0, 10, 20, 25, 30, 35, 40, 45, 50, 55];
function lookStopsToPanel(old: Partial<Record<string, number>>): LookTweaks {
  const n = (k: string) => Math.trunc(old[k] ?? 0);
  const sat = Math.min(Math.abs(n("saturation")), SATURATION_STOPS.length - 1);
  return {
    contrast: n("contrast") * 5, highlights: n("highlights") * 5, shadows: n("shadows") * 5,
    white: 0, black: 0, fade: n("fade") * 10, hue: 0,
    saturation: SATURATION_STOPS[sat]! * (n("saturation") < 0 ? -1 : 1),
    clarity: n("clarity") * 10,
  };
}

function aspectLabel(a: AspectPreset): string {
  return a.labelKey ? t(a.labelKey) : a.label;
}

// "custom" is not a preset — it is the entry that reveals the w × h boxes, and
// a user-entered ratio selects it back through customAspect.
const aspectOptions = computed(() => [
  ...ASPECT_PRESETS.map(a => ({ value: a.key, label: aspectLabel(a) })),
  { value: "custom", label: t("crop.custom") },
]);

// Derived from defaultRecipe so the two can't drift (double-click reset and
// isEdited both compare against these).
const SLIDER_DEFAULTS: Record<string, number> = { ...defaultRecipe() };

// ── Panel switches ──
//
// Lightroom's per-panel on/off: an adjustment stays where it is but leaves
// the render, so a before/after of one panel is a click, not a reset and an
// undo. Part of the edit — snapshot, history, persistence and export all carry
// it, so a photo exported with a panel off exports without that panel, as it
// would from Lightroom. The keys are the panels that have a Reset, minus the
// crop box (which has no switch in Lightroom either: an off crop is a
// different image, not a comparison).
type BypassKey = GroupTitle | "hsl" | "grading" | "curve" | "transform" | "look" | "masks";
const bypass = reactive(new Set<BypassKey>());
function isBypassed(key: BypassKey): boolean { return bypass.has(key); }
function toggleBypass(key: BypassKey): void { if (bypass.has(key)) bypass.delete(key); else bypass.add(key); }

// The recipe as the render should see it: every slider of a switched-off
// group at its default. Returns `r` itself when nothing is off, so the hot
// per-draw path allocates nothing then.
function effectiveRecipe(r: Recipe, b: ReadonlySet<BypassKey> = bypass): Recipe {
  let out = r;
  for (const g of groups) {
    if (!b.has(g.title)) continue;
    if (out === r) out = { ...r };
    for (const item of g.items) (out as Record<string, number>)[item.key] = SLIDER_DEFAULTS[item.key];
  }
  return out;
}

// The crop with its Transform (the keystone/scale/offset half) at rest when
// that panel is off; the box itself is never switched.
function effectiveCrop(c: CropState, b: ReadonlySet<BypassKey> = bypass): CropState {
  return b.has("transform") ? { ...c, xf: defaultTransform() } : c;
}

// ── state ──

const recipe = reactive<Recipe>(defaultRecipe());
const status = ref<"idle"|"uploading"|"rendering"|"error">("idle");
const errorMessage = ref<string | null>(null);
const isDragging = ref(false);
const fileInput = ref<HTMLInputElement | null>(null);
const folderInput = ref<HTMLInputElement | null>(null);
const canvasRef = ref<HTMLCanvasElement | null>(null);
const timing = ref<number | null>(null);
const dcpCode = ref("");  // empty = auto-detect
// Which colour engine renders camera RGB into the working space. "standard" is
// Adobe's chain through a DCP; "sony" reproduces Imaging Edge from calibration
// the body wrote into the RAW (worker sony/profile.py) and needs no profile
// files — but only Sony RAWs carry it, so the worker falls back on its own.
// Baked into linear.bin, so switching re-decodes like dcpCode.
type ProfileId = "standard" | "sony";
const profileId = ref<ProfileId>("standard");
// The engine the last decode actually used (see loadSource) and, on the Sony
// path, which Creative Look's tone curve it applied.
const activeProfileKind = ref<string | null>(null);
// The Creative Look tweaks the body recorded for this shot, and the ones in
// force. `null` means "as shot" — the panel shows the camera's own numbers and
// keeps following them, which is also where a double-click resets a slider to.
// Both are null until a decode reports a Sony rendering.
const lookAsShot = ref<LookTweaks | null>(null);
const look = ref<LookTweaks | null>(null);
// What the engine will render each tweak over, straight from the profile. Empty
// until a Sony decode reports one, which is also when the panel appears; a
// tweak the worker sent no range for gets no slider, since there would be
// nothing to say about how far it goes.
const lookRanges = ref<Partial<Record<LookTweakKey, [number, number]>>>({});
const lookSliders = computed(() => LOOK_TWEAK_ORDER.flatMap(key => {
  const range = lookRanges.value[key];
  return range ? [{ key, min: range[0], max: range[1] }] : [];
}));
// The Creative Look picker. Every ARW carries the calibration for all of the
// body's looks, not just the one that was selected when the shutter fired, so
// switching is a choice this client gets to make — and it costs no pixels: the
// looks share the body's one hue-segmented matrix, so only the tone curve and
// the chroma terms differ, and both ride in the profile. `null` means "as shot".
// The list comes from the file rather than a constant, so a body shipping looks
// this build has never heard of (FL2, FL3) still fills the picker.
const lookAsShotStyle = ref("");
const availableLooks = ref<string[]>([]);
// Set by the worker when the chosen look is not in this RAW at all — the body
// predates it, so its curve and chroma came from a donor. Its own answer rather
// than one derived here: the worker is what decides where a calibration is read
// from, and only it knows whether the donor was actually used.
const lookBorrowed = ref(false);
// The body's own sharpening, for the panel to report rather than to control:
// it is a camera setting, so nothing here can move it. Both ladder positions
// plus whether the fine half (Spica) is doing anything — the two stages split
// one control, and at the top of the range the split leaves nothing for the
// fine end, which is worth saying rather than showing a stage that is off.
const sharpening = ref<{ level: number; range: number; fine: boolean } | null>(null);
const lookStyle = ref<string | null>(null);
const effectiveLookStyle = computed(() => (bypass.has("look") ? null : lookStyle.value) ?? lookAsShotStyle.value);
const lookStyleEdited = computed(() =>
  !!lookStyle.value && !!lookAsShotStyle.value && lookStyle.value !== lookAsShotStyle.value);
// A type-level floor, not a state the panel can reach: everything that reads
// effectiveLook is gated on lookAsShot. Derived from LOOK_TWEAK_ORDER so the
// key list is written once (as SLIDER_DEFAULTS is, and for the same reason).
const ZERO_LOOK = Object.fromEntries(LOOK_TWEAK_ORDER.map(key => [key, 0])) as LookTweaks;
const effectiveLook = computed<LookTweaks>(() => (bypass.has("look") ? null : look.value) ?? lookAsShot.value ?? ZERO_LOOK);
// One reset for the whole panel: the look and its six tweaks are one setting
// as far as the camera is concerned, and resetting to "as shot" means both.
function resetLook(): void {
  look.value = null;
  lookStyle.value = null;
  droStrength.value = null;
  droLevel.value = DRO_AUTO;
}

function setLookStyle(style: string): void {
  lookStyle.value = style;
}

// ── DRO ──
//
// Sony's Dynamic Range Optimizer, on the same free path as the look: it is one
// gain per pixel, and a scalar gain commutes with the colour matrix, so the
// shader applies it to pixels that are already decoded. 1 is what the camera
// itself did; the ceiling matches the API's clampDroStrength.
const DRO_MAX = 2;
// True for any Sony RAW: Auto needs a curve in the file, but the manual levels
// come from Edit.exe's own presets and so work even on a frame that has none.
const droAvailable = ref(false);
// What the body applied: 1 when it used DRO, 0 when it did not. The reset
// target, and the value in force until someone moves the control.
const droAsShot = ref(0);
const droStrength = ref<number | null>(null);
const effectiveDro = computed(() => droStrength.value ?? droAsShot.value);
// The engine's own encoding: -1 is Auto (this shot's own curve), 0..99 picks one
// of the ten built-in presets. The ladder of offered levels comes from the
// worker rather than being repeated here, so the buttons cannot drift from the
// curves it actually renders.
const DRO_AUTO = -1;
const droLevel = ref(DRO_AUTO);
const droLevels = ref<number[]>([]);
// DRO belongs to the same panel, so the switch puts it back to what the camera
// applied (null / Auto) along with the look and its tweaks.
const renderDro = computed(() => bypass.has("look")
  ? { strength: null as number | null, level: DRO_AUTO }
  : { strength: droStrength.value, level: droLevel.value });
// Off / Auto / a level. Off is a strength of zero whatever the level says,
// which is how the worker resolves the same three states.
const droMode = computed<"off" | "auto" | "level">(() =>
  effectiveDro.value <= 0 ? "off" : droLevel.value < 0 ? "auto" : "level");
const droEdited = computed(() =>
  droLevel.value >= 0
  || (droStrength.value !== null && droStrength.value !== droAsShot.value));

// The panel is "edited" if any of its three parts moved: the look, its tweaks,
// or DRO. One flag, because one reset button clears all three.
const lookEdited = computed(() =>
  lookStyleEdited.value
  || droEdited.value
  || (!!look.value && !!lookAsShot.value
    && LOOK_TWEAK_ORDER.some(key => look.value![key] !== lookAsShot.value![key])));

function setDro(value: number): void {
  droStrength.value = clamp(value, 0, DRO_MAX);
}

// Off keeps the level it was on so switching back does not silently land on
// Auto; the strength is what carries "off", exactly as on the worker side.
// Choosing Auto or a level from off has to restore a strength, and 1 is the
// only defensible one — it is what the camera itself would have applied.
function setDroMode(mode: "off" | "auto" | "level", level?: number): void {
  if (mode === "off") {
    droStrength.value = 0;
  } else {
    if (effectiveDro.value <= 0) droStrength.value = 1;
    droLevel.value = mode === "auto" ? DRO_AUTO : (level ?? droLevels.value[0] ?? 0);
  }
}

// Sony's own menu names, for both the Creative Look picker and the DCP style
// picker. Untranslated in every locale, and shown code-first exactly as the
// camera prints them ("ST Standard"), so the control reads the same as the
// body's menu — the code is what the RAW stores and what a Sony shooter knows
// the look by; the word is the reminder.
const STYLE_NAMES: Record<string, string> = {
  ST: "Standard", PT: "Portrait", LD: "Landscape", VV: "Vivid", VV2: "Vivid 2",
  NT: "Neutral", FL: "Film", IN: "Instant", SH: "Soft High-key",
  BW: "Black & White", SE: "Sepia", FL2: "Film 2", FL3: "Film 3",
};

// A look this build has never heard of still works — it just shows the bare
// code Sony wrote, which is the whole reason the list is read from the file.
function styleLabel(code: string): string {
  return STYLE_NAMES[code] ? `${code} ${STYLE_NAMES[code]}` : code;
}

const lookOptions = computed(() => availableLooks.value.map(code => ({
  value: code,
  label: styleLabel(code) + (code === lookAsShotStyle.value ? t("look.asShotSuffix") : ""),
})));

function setLookTweak(key: LookTweakKey, value: number): void {
  look.value = { ...effectiveLook.value, [key]: value };
}
const usingDcp = computed(() => activeProfileKind.value === "dcp");
// False for already-rendered sources (JPEG/PNG/TIFF), which the worker decodes
// into the same linear ProPhoto working space but which carry no mosaic, no
// camera profile and no embedded preview. Gates the controls that need those.
const isRawSource = ref(true);
// True when this shot brought lens correction splines of its own. Not every RAW
// does — adapted or manual glass writes none — and the Lens panel is nothing
// but a blend of those tables, so this is what says the panel has a job.
const lensCorrAvailable = ref(false);
// Whether Color NR reaches this frame's denoiser, reported by the decode. Not a
// setting and not a constant: a Sony RAW runs the transcription of Sony's own
// filter, which has no such control, while a frame without its noise tags falls
// back to the wavelet, where it works. Reported rather than inferred here so the
// worker stays the one place that knows which denoiser ran — inferring it from
// `activeProfileKind` would guess, and guess wrong on a Sony RAW rendered
// through the DCP path.
const denoiseUsesChroma = ref(true);
// Whether the frame runs Sony's own filter (the one denoiser without a Color
// NR control — that is what the flag reports). Its Auto is nothing more than
// the manual panel at its defaults: amount 50 is Auto's strength to the bit,
// edge and colour 50 are the camera's own values (worker sony/rawnr_simd.py
// manual_strength, sony_repro/notes/static-rawnr.md 7.1). So on these frames
// there is no switch — the three sliders stand, 50 is "as the camera" — and
// the request goes out manual whatever an older session stored. The wavelet
// fallback keeps the switch: there Auto scales its amount by the ISO, which a
// slider position does not.
const sonyDenoiser = computed(() => isRawSource.value && !denoiseUsesChroma.value);
/** The Auto switch as the render sees it: never on a Sony frame. */
const effectiveDenoiseAuto = (d: { auto: boolean } = denoise): boolean => d.auto && !sonyDenoiser.value;
const denoiseAuto = computed(() => effectiveDenoiseAuto());
// Fitted camera-match table (see worker fit_profile.py): pulls the DCP render
// toward the camera's own JPEG. On by default — it is the point of the profile —
// but toggleable to compare against Adobe's uncorrected look. Only meaningful
// when a table exists for this body+style (hasCameraMatch), else the row hides.
const cameraMatch = ref(true);
const hasCameraMatch = ref(false);
// AI RAW denoise. Applied in the worker on the Bayer mosaic before demosaic, so
// changing it re-decodes linear.bin (like dcpCode) rather than re-running the
// WebGL shader. amount is 0..100 (normalised to 0..1 for the API).
// edge and chroma ride Edit.exe's own 0..100 scale with 50 neutral, and go to
// the API unscaled — unlike amount. Edge sets how much fine detail survives
// (the camera's own value at 50); chroma scales the colour-noise threshold.
//
// On by default, in Auto. Off was the wrong default and it showed: a frame
// exported with it off carries the demosaic's own noise straight through, and
// the tone curve's slope in the shadows lifts it into visible horizontal and
// vertical texture -- measured at 1.87 axial/diagonal energy in the 2.0-2.7px
// band against 0.93 with denoising on and 1.23 for the camera's own JPEG
// (sony_repro/tools/aniso_confirm.py, notes/measured-chroma-gap.md 2.14).
// Edit's equivalent stage is not something the user turns on either.
//
// `auto` is Edit's Auto: the worker replaces `amount` with the strength the
// engine ramps to for this shot's ISO -- four tenths up to ISO 400, full from
// ISO 1600. amount stays 100 so that unticking Auto lands on full strength
// rather than on whatever ISO happened to imply.
//
// There is one denoiser, and the goal is that it is Edit's. Which filter runs
// is therefore not a user-facing choice and must not become one: offering a
// "method" picker would let a session persist a setting meant to disappear.
// The worker picks it (denoise.DEFAULT_MODEL), and falls back to the wavelet
// for frames without Sony's noise tags. How faithful the reproduction is
// belongs to the worker and is recorded there -- sony/rawnr_simd.py's module
// docstring -- not copied here, where it goes stale unnoticed.
// Sony's "advanced colour reproduction" — Imaging Edge Edit's 色彩复制 radio.
// Off by default, as in Edit. It was briefly on: whole-frame ΔE00 against the
// camera JPEG favours it slightly (1.66 vs 1.73, 1.98 vs 2.25 on two frames),
// because it wins on neutrals and highlights (+1.3 L* vs +3.6 L* above
// L* 80). But what it does to get there is pull bright saturated colour down
// in luma and chroma — the camera JPEG keeps that colour, its C* > 60 sits
// 6–10% above Edit's own advanced render — and that is the part of a frame
// the eye reads first (a field of sunflowers reads closer with it off).
// Whole-frame CIEDE2000 under-weights exactly those pixels (its chroma term),
// so the mean is not the judge here; camera match carries the neutral-and-
// highlight correction instead, without the chroma cost. One switch, two
// effects, which is how Edit has it: YGamma swaps to its advanced table and
// contrast (worker sony/chroma.py), and ZcTask3DLut then runs between it and
// the YCC return trip (worker sony/lut3d.py).
//
// Render-time, not a decode: the table is static, so this is a uniform and a
// redraw. It still belongs in the snapshot — it is a per-image choice the way
// the Creative Look tweaks are, and undo has to travel with it.
const sonyAdvancedColour = ref(false);
// Camera match, the post chain's last stage: the residual the Sony engine's
// own export still has against the body's JPEG, fitted per body and Creative
// Look (worker sony/profile.py camera_match_table) and applied in CIELAB on
// the finished frame. The same trade as the switch above — a table in
// uniforms, so a redraw — and in the snapshot for the same reason. Offered
// only when the worker has a table for this body (hasSonyCameraMatch): one
// fitted on another body would be a guess, so the row hides instead.
const sonyCameraMatch = ref(true);
const hasSonyCameraMatch = ref(false);
// 50 for every slider: the camera's own position on the Sony filter, and
// Edit's default. (Amount used to start at 100, which on a Sony frame renders
// exactly as 50 — above it the engine changes the filter itself, which the
// transcription cannot follow, so the strength holds at Auto's.)
const defaultDenoise = () => ({
  enabled: true, auto: true, amount: 50, edge: 50, chroma: 50,
});
const denoise = reactive(defaultDenoise());
const denoiseBusy = ref(false);
// Hold-to-compare: while true we draw the unedited original (baseline params +
// identity tone curve) so the before/after is easy to eyeball; release restores
// the live edit. crop/denoise/DCP are baked into linear.bin, so they stay applied.
const showOriginal = ref(false);
// Hold-to-compare against the camera's own JPEG (the preview embedded in the
// RAW). Unlike showOriginal this overlays a real <img> instead of re-rendering:
// the camera JPEG went through the manufacturer's tone pipeline, so it's a
// genuinely different reference from the neutral baseline render.
const showEmbedded = ref(false);
let currentSourceId = "";  // server id of the image currently in the renderer

let webglRenderer: PipelineRenderer | null = null;
const p3Supported = ref(false);
let rafId = 0;
let drawPending = false;

// ── Pan / Zoom state ──
// imageW/imageH are the *displayed output* dims (the crop result in normal mode,
// or the straighten bounding box in the crop editor). srcW/srcH are the decoded
// source texture dims that the crop transform maps from.
const imageW = ref(0);
const imageH = ref(0);
const srcW = ref(0);
const srcH = ref(0);
// Full-resolution source dims (before the preview's half-size/max-size
// downscale), reported by the worker so zoom % can be relative to the original.
const srcFullW = ref(0);
const srcFullH = ref(0);
let resizeObs: ResizeObserver | null = null;

// ── HSL & Color Grading state ──

const HSL_RANGES = [
  { key: "red",     color: "#e04040" },
  { key: "orange",  color: "#e08040" },
  { key: "yellow",  color: "#c0b030" },
  { key: "green",   color: "#40b040" },
  { key: "aqua",    color: "#40a0a0" },
  { key: "blue",    color: "#4060d0" },
  { key: "purple",  color: "#8040c0" },
  { key: "magenta", color: "#c04090" },
] as const;

const hslHue = reactive([0, 0, 0, 0, 0, 0, 0, 0]);
const hslSat = reactive([0, 0, 0, 0, 0, 0, 0, 0]);
const hslLum = reactive([0, 0, 0, 0, 0, 0, 0, 0]);
const hslTab = ref<"hue"|"sat"|"lum">("hue");

const defaultGrading = () => ({
  shH: 0, shS: 0,
  mdH: 0, mdS: 0,
  hlH: 0, hlS: 0,
  blend: 50,
  balance: 0,
});
const grading = reactive(defaultGrading());

const GRADING_BANDS = [
  { band: "sh", hueKey: "shH", satKey: "shS" },
  { band: "md", hueKey: "mdH", satKey: "mdS" },
  { band: "hl", hueKey: "hlH", satKey: "hlS" },
] as const;

// View settings (not part of the per-image recipe): display gamut + EXIF policy.
// exportStripPrivate: exports copy the RAW's full EXIF by default; 1 opts into
// stripping GPS/serials/owner/maker notes for exports meant to be shared.
const viewSettings = reactive({ displayGamut: 0, exportStripPrivate: 0 });

// ── Crop & Straighten ──
//
// Part of the per-image edit (snapshot/history/persistence). The crop editor
// renders the full straightened image with an overlay; committing just switches
// the display back to the cropped output. All geometry lives in crop.ts.
const crop = reactive<CropState>(defaultCrop());
const cropMode = ref(false);

// ── Masks (local adjustments) ──
//
// Part of the per-image edit like the crop; the geometry lives in oriented
// image-norm so it follows the crop (rendering/masks.ts, docs/masking.md).
// maskPreview / selectedMask are view state: which group the black-and-white
// matte previews, never part of a snapshot and never on the export path.
const masks = reactive<MaskGroup[]>([]);
const maskPreview = ref(false);
const selectedMask = ref<string | null>(null);
const cloneMasks = (m: readonly MaskGroup[]): MaskGroup[] => JSON.parse(JSON.stringify(m));
const selectedGroup = computed(() => masks.find(g => g.id === selectedMask.value) ?? null);

const MASK_TYPES: MaskType[] = ["luminance", "color", "linear", "radial", "depth", "brush", "ai"];
const MASK_OPS = ["add", "subtract", "intersect"] as const;
// The local sliders: exposure in EV, the rest on the global sliders' ±100.
type MaskSliderKey = Exclude<keyof MaskAdjust, "contrast" | "blacks">; // the two reserved keys have no slider yet
const MASK_ADJUST_SLIDERS: { key: MaskSliderKey; min: number; max: number; step: number }[] = [
  { key: "exposure", min: -5, max: 5, step: 0.05 },
  ...(["temperature", "tint", "highlights", "shadows", "saturation", "vibrance", "hue", "clarity", "dehaze"] as const)
    .map(key => ({ key, min: -100, max: 100, step: 1 })),
  { key: "tintHue", min: -180, max: 180, step: 1 },
  { key: "tintSat", min: 0, max: 100, step: 1 },
  { key: "moire", min: 0, max: 100, step: 1 },
];
// The cast's hue slider shows the wheel it picks from; the strength slider the
// colour it lands on.
const HUE_TRACK = "linear-gradient(to right, #f0f, #00f, #0ff, #0f0, #ff0, #f00, #f0f)";
// A saturation track: grey up to the full colour of the hue it saturates.
const satTrack = (hue: number) => `linear-gradient(to right, #888, hsl(${gradingHueDeg(hue)}, 100%, 50%))`;
function maskTintTrack(key: MaskSliderKey, adjust: MaskAdjust): string | undefined {
  if (key === "tintHue") return HUE_TRACK;
  if (key === "tintSat") return satTrack(adjust.tintHue);
  return WB_TRACK[key as RecipeKey];
}
// The Add menu: presets first (the common cases), then a bare component of
// each type. Its model never matches an option, so it always reads "Add…".
const maskAddOptions = computed(() => [
  ...(Object.keys(MASK_PRESETS) as MaskPresetName[]).map(k => ({ value: k, label: t(`mask.preset.${k}`) })),
  ...MASK_TYPES.map(k => ({ value: k, label: t(`mask.type.${k}`) })),
]);
const maskTypeOptions = computed(() => MASK_TYPES.map(k => ({ value: k, label: t(`mask.type.${k}`) })));

// A preset group keeps the preset's key as its name and shows it translated;
// anything else is "Mask".
function maskLabel(g: MaskGroup): string {
  return g.name && g.name in MASK_PRESETS ? t(`mask.preset.${g.name as MaskPresetName}`) : g.name ?? t("mask.newGroup");
}
const newMaskId = () => Math.random().toString(36).slice(2, 8);
function addMask(key: string): void {
  if (masks.length >= MASK_GROUPS) return;
  const id = newMaskId();
  masks.push(key in MASK_PRESETS
    ? presetGroup(key as MaskPresetName, id)
    : { id, enabled: true, invert: false, components: [defaultComponent(key as MaskType)], adjust: defaultAdjust() });
  selectedMask.value = id;
}
function removeMask(id: string): void {
  const i = masks.findIndex(g => g.id === id);
  if (i >= 0) masks.splice(i, 1);
  if (selectedMask.value === id) selectedMask.value = masks[Math.min(i, masks.length - 1)]?.id ?? null;
}
function addComponent(type: string): void {
  const g = selectedGroup.value;
  if (g && g.components.length < MASK_COMPS) g.components.push(defaultComponent(type as MaskType));
}
function resetMasks(): void { masks.splice(0); selectedMask.value = null; }

// ── Erase (generative fill) ──
//
// Brushed regions the worker refills with Moebius before the frame reaches the
// GPU (worker erase.py), so the fill takes every later edit like the pixels
// around it. Strokes are per-image edit state in the decode's own frame
// (rendering/erase.ts); a change re-requests the decode, like denoise. The
// brush size and the stroke overlay are view state.
const erase = reactive<EraseStroke[]>([]);
const eraseBrush = ref(Number(localStorage.getItem("llr.eraseBrush")) || 24);
watch(eraseBrush, v => localStorage.setItem("llr.eraseBrush", String(v)));
// How far past the brush a new stroke's fill reaches and how softly it fades
// out, in percent of its radius. View state, stamped onto each stroke as it is
// committed (a fill) or lands (a heal); a committed stroke keeps its own and
// can be retuned from the list.
const eraseGrow = ref(storedPercent("llr.eraseGrow", 15));
const eraseFeather = ref(storedPercent("llr.eraseFeather", 35));
watch(eraseGrow, v => localStorage.setItem("llr.eraseGrow", String(v)));
watch(eraseFeather, v => localStorage.setItem("llr.eraseFeather", String(v)));
function storedPercent(key: string, fallback: number): number {
  const v = Number(localStorage.getItem(key) ?? NaN);
  return Number.isFinite(v) ? Math.min(100, Math.max(0, v)) : fallback;
}
const eraseSoft = () => ({ grow: eraseGrow.value / 100, feather: eraseFeather.value / 100 });
const eraseShowStrokes = ref(false);
const eraseHover = ref<string | null>(null);
const eraseBusy = ref(false);
// Why the last decode's fills did not run (no model, no runtime), from the worker.
const eraseError = ref<string | null>(null);
const eraseStatus = ref<ModelStatus | null>(null);
// Which brush paints: the generative fill, or the healing brush (a nearby patch
// matched and blended in by the worker — no model, near-instant). View state.
const eraseMode = ref<"fill" | "heal">((localStorage.getItem("llr.eraseMode") as "fill" | "heal" | null) ?? "fill");
watch(eraseMode, v => localStorage.setItem("llr.eraseMode", v));
// A generative fill is brushed in as many strokes as it takes and run on
// demand: strokes collect in a draft (view state — not in the edit, history or
// the decode) until "Fill" turns the draft into one region, filled as one. The
// healing brush is near-instant and patches each stroke on its own, so its
// strokes land straight away.
const eraseDraft = shallowRef<EraseStroke | null>(null);
const eraseDraftLines = computed(() => eraseDraft.value ? 1 + (eraseDraft.value.more?.length ?? 0) : 0);
function addEraseStroke(points: [number, number][], radius: number): void {
  if (erase.length >= ERASE_MAX_STROKES || !points.length) return;
  const line = { points: points.slice(0, ERASE_MAX_POINTS), radius: Math.min(radius, 0.5) };
  if (eraseMode.value === "heal") {
    erase.push({ id: newMaskId(), ...line, mode: "heal", ...eraseSoft() });
    return;
  }
  const d = eraseDraft.value;
  if (!d) eraseDraft.value = { id: newMaskId(), ...line };
  else if (eraseDraftLines.value < ERASE_MAX_LINES) eraseDraft.value = { ...d, more: [...(d.more ?? []), line] };
}
function commitEraseDraft(): void {
  const d = eraseDraft.value;
  if (!d || erase.length >= ERASE_MAX_STROKES) return;
  eraseDraft.value = null;
  erase.push({ ...d, ...eraseSoft() });
}
function undoEraseDraftLine(): void {
  const d = eraseDraft.value;
  if (!d) return;
  eraseDraft.value = d.more?.length ? { ...d, more: d.more.slice(0, -1) } : null;
}
function discardEraseDraft(): void { eraseDraft.value = null; }
function removeErase(id: string): void {
  const i = erase.findIndex(s => s.id === id);
  if (i >= 0) erase.splice(i, 1);
}
// Retuning a committed stroke's grow / feather from its row. Every change
// re-runs that fill (and any after it), so a drag is held here and lands once
// the slider rests; the row shows the held value meanwhile.
const eraseOpen = ref<string | null>(null);
const erasePending = reactive<Record<string, { grow?: number; feather?: number }>>({});
let erasePendingTimer: number | undefined;
function eraseParam(s: EraseStroke, key: "grow" | "feather"): number {
  return Math.round((erasePending[s.id]?.[key] ?? s[key] ?? 0) * 100);
}
function setEraseParam(id: string, key: "grow" | "feather", percent: number): void {
  erasePending[id] = { ...erasePending[id], [key]: percent / 100 };
  window.clearTimeout(erasePendingTimer);
  erasePendingTimer = window.setTimeout(flushEraseParams, 450);
}
function flushEraseParams(): void {
  window.clearTimeout(erasePendingTimer);
  for (const [id, held] of Object.entries(erasePending)) {
    const i = erase.findIndex(s => s.id === id);
    // A stroke from before grow/feather takes both at once, from 0: one of
    // them alone would still switch it to the soft edge.
    if (i >= 0) erase[i] = { ...erase[i], grow: held.grow ?? erase[i].grow ?? 0, feather: held.feather ?? erase[i].feather ?? 0 };
    delete erasePending[id];
  }
}
function resetErase(): void { erase.splice(0); }

// ── Relight (added lights) ──
//
// Point lights the shader adds to the scene-linear frame, shaded on normals and
// depth the worker estimates once per decode (rendering/relight.ts, worker
// relight.py). The rig is per-image edit state and a pure redraw; only the
// geometry is fetched, and only when there is a rig to light it with or the
// tab is open.
const relight = reactive<RelightState>(defaultRelight());
const selectedLight = ref<string | null>(null);
// The geometry the preview renderer holds, and which decode it was made for.
let relightGeometry: RelightGeometry | null = null;
let relightGeometryKey = "";
const relightHasGeometry = ref(false);
// View state, like the mask matte: which geometry map replaces the photo while the tab is open.
const relightView = ref<0 | 1 | 2>(0);
watch(relightView, () => scheduleWebGLDraw());
const LIGHT_COLORS = ["#ffd9a8", "#a8c8ff", "#ffffff", "#ff9a7a"];
function addLight(u: number, v: number): void {
  if (relight.lights.length >= RELIGHT_MAX_LIGHTS) return;
  const id = newMaskId();
  relight.lights.push({ id, u, v, lift: 0.4, ev: 1, color: LIGHT_COLORS[relight.lights.length % LIGHT_COLORS.length]! });
  selectedLight.value = id;
}
function removeLight(id: string): void {
  const i = relight.lights.findIndex(l => l.id === id);
  if (i >= 0) relight.lights.splice(i, 1);
  if (selectedLight.value === id) selectedLight.value = relight.lights[0]?.id ?? null;
}
function resetRelight(): void {
  // In place: the editor holds the lights array itself.
  const d = defaultRelight();
  relight.lights.splice(0);
  relight.ambient = d.ambient; relight.wrap = d.wrap; relight.falloff = d.falloff; relight.shadows = d.shadows;
  selectedLight.value = null;
}
const deg = (rad: number) => Math.round((rad * 180) / Math.PI);
const rad = (d: number) => (d * Math.PI) / 180;

// The sub-rectangle of the frame the canvas currently covers (output-frame px);
// null = the whole frame. See updateRenderWindow for why it exists.
const renderWindow = ref<ViewWindow | null>(null);

const {
  zoom, pan, fitScale, viewportRef, isPanning, spaceHeld,
  displayTransform, canvasTransform, zoomPercent, visibleWindow,
  recomputeFit, startPan, doPan, stopPan,
  onWheel, zoomIn, zoomOut, fitView, zoomToFull, onDoubleClick,
} = useViewport({
  imageW, imageH, srcW, srcH, srcFullW, srcFullH, cropMode,
  renderOrigin: renderWindow,
});
const {
  cropAspect, cropBBox, cropOverlayRef,
  currentImageDims, resetCrop,
  lockedRatio, customAspect, selectAspect, setCustomAspect, swapAspect,
  setAngle, rotateCrop, flipCropH, flipCropV,
  cropGuide, setCropGuide, cycleCropGuide, cycleCropGuideVariant, cropGuideShapes,
  isRotating, rotateGridLines, lineTool, setLineTool, straightenLine, readoutAngle,
  setTransform, resetTransform, removeLastGuide, guideLinesView,
  cropBoxRect, ofPerScreen, cropViewBox, cropDimPath, cropOverscan, cropGrips, activeCropHandle,
  onCropHandleDown, onCropOverlayDown, onGuideHandleDown,
} = useCropEditor({
  crop, srcW, srcH, fitScale, zoom,
  onDragEnd: () => flushPendingHistory(),
});

const guideOptions = computed(() => CROP_GUIDES.map(g => ({ value: g, label: t(`guide.${g}` as const) })));

// Gradient handles for the selected mask group, on an overlay that shares the
// crop overlay's placement (normal view only; the crop editor has its own).
const {
  overlayRef: maskOverlayRef, viewBox: maskViewBox, shapes: maskShapes,
  onLinearEndDown, onLinearLineDown, onRadialCentreDown, onRadialAxisDown, onRadialRotateDown,
} = useMaskEditor({
  crop, srcW, srcH, group: selectedGroup, ofPerScreen,
  onDragEnd: () => flushPendingHistory(),
});

// The erase brush: same overlay placement, strokes taken back through the
// lens correction the preview is drawn with (rendering/erase.ts).
// The lens correction the preview is drawn with, for mapping overlay points
// to source pixels and back.
function viewLens() {
  const r = effectiveRecipe(recipe, bypass);
  return lensWarp(lensCorr ? mixLensTable(lensCorr.distortion, (r.lensDistortion ?? 100) / 100) : undefined,
    lensCorr?.caR, lensCorr?.caB, srcW.value, srcH.value);
}
const {
  overlayRef: eraseOverlayRef, viewBox: eraseViewBox, paths: erasePaths, livePath: eraseLivePath,
  cursor: eraseCursor, cursorR: eraseCursorR,
  onPointerDown: onErasePointerDown, onPointerMove: onErasePointerMove, onPointerUp: onErasePointerUp,
  onPointerLeave: onErasePointerLeave,
} = useEraseEditor({
  crop, srcW, srcH, brush: eraseBrush, ofPerScreen,
  // The draft is drawn with the grow / feather it will be committed with.
  strokes: () => (eraseDraft.value ? [...erase, { ...eraseDraft.value, ...eraseSoft() }] : erase),
  lens: viewLens,
  onStroke: addEraseStroke,
});

// ── Brush masks ──
//
// Painting goes into one brush component at a time (activeBrush), through the
// same stroke editor as erase; size, softness, flow and the eraser are view
// state, stamped onto each stroke as it lands.
const activeBrush = ref<{ gid: string; idx: number } | null>(null);
const activeBrushComp = computed(() => {
  const a = activeBrush.value;
  const c = a ? masks.find(g => g.id === a.gid)?.components[a.idx] : undefined;
  return c && c.type === "brush" ? c : null;
});
const brushSize = ref(Number(localStorage.getItem("llr.brushSize")) || 40);
watch(brushSize, v => localStorage.setItem("llr.brushSize", String(v)));
const brushFeather = ref(60);
const brushFlow = ref(100);
const brushErase = ref(false);
watch(selectedMask, () => { activeBrush.value = null; });
function toggleBrush(gid: string, idx: number): void {
  const a = activeBrush.value;
  activeBrush.value = a && a.gid === gid && a.idx === idx ? null : { gid, idx };
}
const {
  overlayRef: brushOverlayRef, viewBox: brushViewBox, livePath: brushLivePath,
  cursor: brushCursor, cursorR: brushCursorR,
  onPointerDown: onBrushPointerDown, onPointerMove: onBrushPointerMove, onPointerUp: onBrushPointerUp,
  onPointerLeave: onBrushPointerLeave,
} = useEraseEditor({
  crop, srcW, srcH, strokes: () => [], brush: brushSize, ofPerScreen,
  lens: viewLens,
  onStroke: (points, radius) => {
    activeBrushComp.value?.strokes.push({
      points: points.slice(0, ERASE_MAX_POINTS), radius: Math.min(radius, 0.5),
      feather: brushFeather.value / 100, flow: brushFlow.value / 100, ...(brushErase.value ? { erase: true } : {}),
    });
  },
});

// The lens blur's focus point: picked on the image, kept in source-norm like a
// light's aim point (useFocusPicker), so it stays on its subject through a crop.
const pickingFocus = ref(false);
const {
  overlayRef: focusOverlayRef, viewBox: focusViewBox, marker: focusMarker, onPointerDown: onFocusPointerDown,
} = useFocusPicker({
  crop, srcW, srcH, picking: pickingFocus,
  focus: () => recipe.blurFocusX >= 0 ? [recipe.blurFocusX, recipe.blurFocusY] : [0.5, 0.5],
  lens: viewLens,
  onPick: (u, v) => { recipe.blurFocusX = u; recipe.blurFocusY = v; pickingFocus.value = false; },
});

const {
  overlayRef: relightOverlayRef, viewBox: relightViewBox, handles: relightHandles,
  onHandleDown: onLightHandleDown, onPointerDown: onRelightPointerDown,
  onPointerMove: onRelightPointerMove, onPointerUp: onRelightPointerUp,
} = useRelightEditor({
  crop, srcW, srcH, lights: relight.lights, selected: selectedLight, ofPerScreen,
  lens: viewLens,
  onAdd: addLight,
  onDragEnd: () => flushPendingHistory(),
});

// On-canvas readout in the crop editor: the angle while rotating, else the
// armed line tool's hint.
const cropReadout = computed(() => {
  if (lineTool.value === "guided") return t("xf.guidedHint");
  if (isRotating.value) return `${readoutAngle.value.toFixed(2)}°`;
  if (lineTool.value === "straighten") return t("crop.straightenHint");
  return "";
});

// Output size tag pinned inside the crop box's bottom-right corner.
const cropSizeLabel = computed(() => {
  const [w, h] = cropOutputSize(crop, srcW.value, srcH.value);
  return `${w} × ${h}`;
});

// The transform sliders, in panel order; each is one SliderRow.
const XF_SLIDERS = [
  { key: "vertical", min: -100, max: 100, reset: 0 },
  { key: "horizontal", min: -100, max: 100, reset: 0 },
  { key: "aspect", min: -100, max: 100, reset: 0 },
  { key: "scale", min: 50, max: 150, reset: 100 },
  { key: "offsetX", min: -100, max: 100, reset: 0 },
  { key: "offsetY", min: -100, max: 100, reset: 0 },
] as const;

const WORKSPACE_BG: [number, number, number] = [0.07, 0.07, 0.08];

function hslValue(i: number): number {
  if (hslTab.value === "hue") return hslHue[i];
  if (hslTab.value === "sat") return hslSat[i];
  return hslLum[i];
}
function setHsl(i: number, v: number): void {
  if (hslTab.value === "hue") hslHue[i] = v;
  else if (hslTab.value === "sat") hslSat[i] = v;
  else hslLum[i] = v;
}
function gradingColor(key: string): string {
  const g = grading as Record<string, number>;
  const h = g[key + "H"] ?? 0;
  const s = g[key + "S"] ?? 0;
  return `hsl(${gradingHueDeg(h)}, ${s}%, 50%)`;
}
function resetHsl(): void {
  for (let i = 0; i < 8; i++) { hslHue[i] = 0; hslSat[i] = 0; hslLum[i] = 0; }
}
function resetGrading(): void {
  grading.shH = 0; grading.shS = 0;
  grading.mdH = 0; grading.mdS = 0;
  grading.hlH = 0; grading.hlS = 0;
  grading.blend = 50;
  grading.balance = 0;
}
function resetHslGrading(): void { resetHsl(); resetGrading(); }

// ── Tone Curve (Lightroom-compatible: parametric + RGB/R/G/B point curves) ──

const {
  toneCurve, curveChannel, curveActive, curveCanvas,
  CURVE_TABS, PARAM_REGIONS, presetNames,
  renderCurveCanvas, setCurveChannel, resetCurve, applyCurvePreset,
  paramValue, setParam,
  onCurveMouseDown, onCurveHover, onCurveLeave, onCurveDoubleClick,
} = useToneCurve({
  onApply: () => applyCurveLUT(),
  onReset: () => { bakeCurveLUT(); drawWebGL(); }, // immediate, no RAF-batching for reset
});

// Which rows/groups hold a non-default value. Drives the brightened row text
// and the accent dot on a group header, so edits are visible without opening
// or reading every panel.
const isEdited = (key: RecipeKey): boolean => recipe[key] !== SLIDER_DEFAULTS[key];
const groupEdited = (group: SliderGroup): boolean => group.items.some(s => isEdited(s.key));
function resetGroup(group: SliderGroup): void {
  for (const spec of group.items) recipe[spec.key] = SLIDER_DEFAULTS[spec.key];
}
const hslEdited = computed(() =>
  hslHue.some(v => v !== 0) || hslSat.some(v => v !== 0) || hslLum.some(v => v !== 0));
const gradingEdited = computed(() => {
  const d = defaultGrading() as Record<string, number>;
  return Object.entries(grading).some(([k, v]) => v !== d[k]);
});

// Basic-panel values currently baked into the GPU curve LUT (Contrast, Blacks
// and Whites are all display-referred stages of the LUT chain, not shader
// uniforms). null = the LUT holds the identity curve (hold-to-compare swapped
// it in).
let bakedBasic: BasicAdjust | null = DEFAULT_BASIC;

// The history step the pointer is resting on, drawn in place of the live edit
// until it leaves (see the history panel below). Never applied to the state.
const historyPreview = shallowRef<Snapshot | null>(null);

function currentBasic(r: Recipe = recipe): BasicAdjust {
  return { contrast: r.contrast, blacks: r.blacks, whites: r.whites };
}

/** Rebake + upload the curve LUT with the live tone curve and Basic values. */
function bakeCurveLUT(): void {
  if (!webglRenderer) return;
  // While hold-to-compare is on, the GPU LUT must stay identity: a rebake from a
  // mid-hold re-decode or reset would otherwise leak Contrast/Blacks/the curve
  // into the 'before' view, with nothing to restore it until the key is released.
  if (showOriginal.value) {
    webglRenderer.uploadCurveLUT(IDENTITY_CURVE_LUT);
    bakedBasic = null;
    return;
  }
  // A hovered history step draws with its own curve and Basic values; bakedBasic
  // stays null so the live ones are rebaked the frame the hover ends.
  const s = historyPreview.value;
  if (s) {
    const b = new Set(s.bypass ?? []);
    webglRenderer.uploadCurveLUT(buildToneCurveLUT(b.has("curve") ? defaultToneCurve() : s.curve, currentBasic(effectiveRecipe(s.recipe, b))));
    bakedBasic = null;
    return;
  }
  const basic = currentBasic(effectiveRecipe(recipe));
  webglRenderer.uploadCurveLUT(buildToneCurveLUT(bypass.has("curve") ? defaultToneCurve() : toneCurve.value, basic));
  bakedBasic = basic;
}

function applyCurveLUT(): void {
  bakeCurveLUT();
  scheduleWebGLDraw();
}

// ── History (undo / redo) ──

type Snapshot = {
  recipe: Recipe;
  hslHue: number[]; hslSat: number[]; hslLum: number[];
  grading: typeof grading;
  curve: ToneCurve;
  crop: CropState;
  aspect?: string;  // crop aspect-lock key; optional: absent in older persisted sessions
  dcp: string;
  profile?: ProfileId;  // colour engine; optional: absent in pre-Sony persisted sessions
  denoise?: typeof denoise;  // optional: absent in pre-denoise persisted sessions
  // Creative Look tweaks; null (or absent, in older sessions) means as shot.
  look?: LookTweaks | null;
  // Which scale `look` is on. Absent means the camera's stops, which is what
  // every session before Edit's panel scale stored (see lookStopsToPanel).
  lookScale?: typeof LOOK_SCALE;
  // Which Creative Look to render, when it is not the body's own. Same "null
  // means as shot" convention, and likewise absent in older sessions.
  lookStyle?: string | null;
  // DRO strength, on the same convention: null is what the camera applied.
  dro?: number | null;
  // Which DRO curve: -1 for the shot's own (Auto), 0..99 for a built-in preset.
  droLevel?: number | null;
  // Sony's advanced colour reproduction (ZcTask3DLut). Absent in older
  // sessions, which rendered with it off, and off is the default again.
  sonyAdvancedColour?: boolean;
  // Camera match (the fitted correction toward the body's JPEG). Absent in
  // older sessions, which rendered without it; a new snapshot starts with it on.
  sonyCameraMatch?: boolean;
  // Local adjustments; absent in sessions that predate them, which is empty.
  masks?: MaskGroup[];
  // Generative erase strokes (rendering/erase.ts); absent before erase existed.
  erase?: EraseStroke[];
  // Added lights (rendering/relight.ts); absent before relight existed.
  relight?: RelightState;
  // Panels switched off (see BypassKey); absent in older sessions, i.e. none.
  bypass?: BypassKey[];
};

let isRestoring = false;
// When true, the dcpCode watcher skips its re-decode — used while we load a
// source explicitly (switching images / restoring) to avoid a double decode.
let suppressDcpReload = false;

// Sony's own engine for Sony's own files: ARW (and the older SRF/SR2) carry the
// calibration it renders from, and the worker falls back to the DCP when a shot
// has none. Anything else has only the DCP, so Adobe is the honest default.
function defaultProfile(name?: string): ProfileId {
  return /\.(arw|srf|sr2)$/i.test(name ?? "") ? "sony" : "standard";
}

function defaultSnapshot(name?: string): Snapshot {
  return {
    recipe: defaultRecipe(),
    hslHue: [0, 0, 0, 0, 0, 0, 0, 0],
    hslSat: [0, 0, 0, 0, 0, 0, 0, 0],
    hslLum: [0, 0, 0, 0, 0, 0, 0, 0],
    grading: defaultGrading(),
    curve: defaultToneCurve(),
    crop: defaultCrop(),
    aspect: DEFAULT_ASPECT,
    dcp: "",
    profile: defaultProfile(name),
    denoise: defaultDenoise(),
    look: null,
    lookScale: LOOK_SCALE,
    lookStyle: null,
    dro: null,
    droLevel: DRO_AUTO,
    sonyAdvancedColour: false,
    sonyCameraMatch: true,
    masks: [],
    erase: [],
    relight: defaultRelight(),
    bypass: [],
  };
}

const {
  history, historyIndex, pendingDirty, canUndo, canRedo,
  scheduleCommit: scheduleHistoryCommit, flushPending: flushPendingHistory,
  undo, redo, jumpTo: jumpHistory, labelOf: historyLabelOf, init: initHistory,
} = useHistory<Snapshot>({
  capture: () => captureSnapshot(),
  apply: (s) => applySnapshot(s),
  suspended: () => isRestoring,
  onCommitted: () => { schedulePersist(); schedulePreview(); },
});

function captureSnapshot(): Snapshot {
  return {
    recipe: { ...recipe },
    hslHue: [...hslHue], hslSat: [...hslSat], hslLum: [...hslLum],
    grading: { ...grading },
    curve: normalizeToneCurve(toneCurve.value),
    crop: cloneCrop(crop),
    aspect: cropAspect.value,
    dcp: dcpCode.value,
    profile: profileId.value,
    denoise: { ...denoise },
    look: look.value ? { ...look.value } : null,
    lookScale: LOOK_SCALE,
    lookStyle: lookStyle.value,
    dro: droStrength.value,
    droLevel: droLevel.value,
    sonyAdvancedColour: sonyAdvancedColour.value,
    sonyCameraMatch: sonyCameraMatch.value,
    masks: cloneMasks(masks),
    erase: cloneErase(erase),
    relight: cloneRelight(relight),
    bypass: [...bypass],
  };
}

// Push a snapshot into the live reactive edit state (no draw scheduling — the
// caller decides whether to redraw or re-decode).
function setEditState(s: Snapshot): void {
  // Layer over defaults: snapshots persisted before a recipe key existed (e.g.
  // the lens corrections) must reset it, not inherit the previous image's value.
  Object.assign(recipe, defaultRecipe(), s.recipe);
  for (let i = 0; i < 8; i++) { hslHue[i] = s.hslHue[i]; hslSat[i] = s.hslSat[i]; hslLum[i] = s.hslLum[i]; }
  Object.assign(grading, s.grading);
  toneCurve.value = normalizeToneCurve(s.curve);
  curveActive.value = -1;
  bypass.clear();
  for (const key of s.bypass ?? []) bypass.add(key);
  Object.assign(crop, s.crop ? cloneCrop(s.crop) : defaultCrop());
  // Older snapshots have no aspect: fall back to "free" so a legacy crop box
  // that doesn't match the new default lock isn't reshaped by the next drag.
  cropAspect.value = s.aspect ?? "free";
  // Spread the defaults underneath rather than only when `denoise` is absent:
  // Object.assign leaves keys the snapshot does not carry at whatever the
  // previously loaded image left them, so a snapshot predating a field would
  // inherit that field from its neighbour instead of from the default. `auto`
  // is the first field to have a predecessor, and off is not its default.
  Object.assign(denoise, { ...defaultDenoise(), ...(s.denoise ?? {}) });
  look.value = s.look ? (s.lookScale === LOOK_SCALE ? { ...s.look } : lookStopsToPanel(s.look)) : null;
  lookStyle.value = s.lookStyle ?? null;
  droStrength.value = s.dro ?? null;
  // Snapshots taken before manual levels existed carry none, and Auto is what
  // they were rendered with.
  droLevel.value = s.droLevel ?? DRO_AUTO;
  // Absent in a snapshot predating the switch, and off is what it rendered as.
  sonyAdvancedColour.value = s.sonyAdvancedColour ?? false;
  // Same rule: a snapshot from before the stage existed was rendered without it.
  sonyCameraMatch.value = s.sonyCameraMatch ?? false;
  masks.splice(0, masks.length, ...cloneMasks(s.masks ?? []).map(g => ({ ...g, adjust: { ...defaultAdjust(), ...g.adjust } })));
  if (selectedMask.value && !masks.some(g => g.id === selectedMask.value)) selectedMask.value = null;
  erase.splice(0, erase.length, ...cloneErase(s.erase ?? []));
  {
    // In place: the editor holds the lights array itself.
    const r = cloneRelight(s.relight);
    relight.lights.splice(0, relight.lights.length, ...r.lights);
    relight.ambient = r.ambient; relight.wrap = r.wrap; relight.falloff = r.falloff; relight.shadows = r.shadows;
    if (selectedLight.value && !relight.lights.some(l => l.id === selectedLight.value)) selectedLight.value = null;
  }
  dcpCode.value = s.dcp;
  profileId.value = s.profile ?? "standard";
  // Rebake with the snapshot's Basic values (bakeCurveLUT also syncs bakedBasic).
  // Uploading a curve-only LUT here would leave a stale bakedBasic: if the
  // snapshot's Contrast/Blacks happen to equal it, drawWebGL's sameBasic check
  // skips the rebake and the GPU keeps rendering without them.
  if (webglRenderer) bakeCurveLUT();
  renderCurveCanvas();
}

function applySnapshot(s: Snapshot): void {
  isRestoring = true;
  setEditState(s); // setting dcpCode here may trigger a re-decode (intended for undo/redo)
  // Full re-render, not just a redraw: the snapshot may carry a different crop,
  // and the crop watcher that would re-render it is suspended while isRestoring.
  scheduleCropRender();
  nextTick(() => { isRestoring = false; });
}

initHistory();

// ── History panel ──
//
// Every entry is a whole snapshot, so a step's caption is read off the diff
// with its predecessor: the sliders that moved (with their new value), or the
// panel that changed. An author tag (the assistant) rides along when known.
const same = (a: unknown, b: unknown): boolean => JSON.stringify(a) === JSON.stringify(b);
function describeStep(prev: Snapshot, next: Snapshot): string {
  const parts: string[] = [];
  for (const key of Object.keys(next.recipe) as RecipeKey[]) {
    if (prev.recipe[key] !== next.recipe[key]) parts.push(`${t(`slider.${key}`)} ${formatSliderValue(key, next.recipe[key])}`);
  }
  if (!same(prev.hslHue, next.hslHue) || !same(prev.hslSat, next.hslSat) || !same(prev.hslLum, next.hslLum)) parts.push(t("panel.hsl"));
  if (!same(prev.grading, next.grading)) parts.push(t("panel.grading"));
  if (!same(prev.curve, next.curve)) parts.push(t("panel.curve"));
  if (!same(prev.crop, next.crop) || prev.aspect !== next.aspect) parts.push(t("panel.crop"));
  if (prev.dcp !== next.dcp || prev.profile !== next.profile) parts.push(t("settings.engine"));
  if (!same(prev.denoise, next.denoise)) parts.push(t("panel.detail"));
  if (!same(prev.look, next.look) || prev.lookStyle !== next.lookStyle || prev.dro !== next.dro || prev.droLevel !== next.droLevel
    || prev.sonyAdvancedColour !== next.sonyAdvancedColour
    || prev.sonyCameraMatch !== next.sonyCameraMatch) parts.push(t("panel.creativeLook"));
  if (!same(prev.masks ?? [], next.masks ?? [])) parts.push(t("panel.masks"));
  if (!same(prev.erase ?? [], next.erase ?? [])) parts.push(t("panel.erase"));
  if (!same(prev.relight ?? defaultRelight(), next.relight ?? defaultRelight())) parts.push(t("panel.relight"));
  if (!parts.length) return t("history.edit");
  return parts.length > 3 ? `${parts.slice(0, 3).join(", ")} +${parts.length - 3}` : parts.join(", ");
}
function formatSliderValue(key: RecipeKey, v: number): string {
  if (key === "temperature") return `${v}K`;
  if (key === "exposure") return `${v > 0 ? "+" : ""}${v.toFixed(2)}`;
  return `${v > 0 ? "+" : ""}${v}`;
}
// Hovering a step for a moment draws it on the canvas — draw parameters and
// curve LUT only, like hold-to-compare: the sliders, history and stored edit
// stay on the live state, and leaving the step puts the live render back. What
// is baked into the decoded pixels (crop, engine, denoise) is not previewed.
const HISTORY_PREVIEW_DELAY_MS = 350;
let historyPreviewTimer = 0;
function hoverHistoryStep(i: number): void {
  clearTimeout(historyPreviewTimer);
  historyPreviewTimer = window.setTimeout(() => {
    historyPreview.value = i === historyIndex.value ? null : history.value[i] ?? null;
  }, HISTORY_PREVIEW_DELAY_MS);
}
function endHistoryPreview(): void {
  clearTimeout(historyPreviewTimer);
  historyPreviewTimer = 0;
  historyPreview.value = null;
}
watch(historyPreview, () => {
  if (!webglRenderer) return;
  bakeCurveLUT();
  scheduleWebGLDraw();
});
// Newest first, the way a photographer reads it back.
const historySteps = computed(() => history.value.map((snap, i) => ({
  index: i,
  label: i === 0 ? t("history.start") : describeStep(history.value[i - 1], snap),
  author: historyLabelOf(i),
})).reverse());

// ── Per-image edits + persistence ──
//
// Each imported source owns an independent edit (snapshot + undo history). The
// live reactive state (recipe/hsl/grading/curve/dcp + history) always mirrors
// the active image; switching images saves the outgoing one here and loads the
// incoming one back.

type ImageEdit = PersistedEdit<Snapshot>;

// Push a stored edit (null = defaults) into the live reactive state.
// Does not decode/draw — the library pairs this with loadSource().
function applyStoredEdit(e: ImageEdit | null): void {
  previewDirty = e != null && !activeSource.value?.previewUrl;
  isRestoring = true;
  suppressDcpReload = true;
  if (e) {
    setEditState(e.snapshot);
    history.value = e.history.map(s => ({ ...s }));
    historyIndex.value = Math.min(Math.max(0, e.historyIndex), history.value.length - 1);
  } else {
    setEditState(defaultSnapshot(activeSource.value?.name));
    history.value = [captureSnapshot()];
    historyIndex.value = 0;
  }
  pendingDirty.value = false;
  nextTick(() => { isRestoring = false; suppressDcpReload = false; });
}

const {
  folders, tree, selectedFolderId, expanded, view: libraryView, folderLoading,
  sortKey, sortDir, groupKey, setSort, setGroup,
  folderPhotos, activeId, activeSource, selectedIds, importProgress,
  photoById, resolveUrl, thumbSrc, markInvalid, clearInvalid,
  persistNow, persistOnUnload: persistForUnload, schedulePersist,
  selectSource, openPhoto, setView,
  selectFolder, toggleExpanded, createFolder, renameFolder, moveFolder, deleteFolder,
  removePhotos, renamePhoto, movePhotos, importFiles, importDropped, importPickedDirectory,
  savePreview, boot, updateEdits, snapshotOf,
} = useCatalog<Snapshot, typeof viewSettings>({
  api: API,
  status, errorMessage, cropMode,
  captureEdit: () => ({ snapshot: captureSnapshot(), history: history.value.slice(), historyIndex: historyIndex.value }),
  loadEdit: (e) => applyStoredEdit(e),
  loadPixels: (id, o) => loadSource(id, o),
  flushPendingHistory: () => flushPendingHistory(),
  // A pending denoise reload belongs to the outgoing image; firing it after the
  // switch would re-decode the new image a second time. A pending preview is
  // the outgoing image's too, and this is the last moment its pixels and its
  // edit are both still live: take it now rather than drop it.
  beforeActivate: () => {
    if (denoiseReloadTimer) { clearTimeout(denoiseReloadTimer); denoiseReloadTimer = 0; }
    flushPreview();
    previewDirty = false;
  },
  onEmptied: () => {
    currentSourceId = "";
    hasLinearData = false;
    renderedId.value = "";
    lensCorr = null;
    lensCorrAvailable.value = false;
    isRawSource.value = true;
    hasCameraMatch.value = false;
    srcW.value = 0;
    srcH.value = 0;
    timing.value = null;
    destroyWebGL({ keepContext: true }); // frees the removed image's GPU texture
    status.value = "idle";
    errorMessage.value = null;
  },
  isRestoring: () => isRestoring,
  // Restore only keys this build still has: stored UI state outlives the
  // settings it was written with (it carried a view-transform choice until the
  // AgX look was dropped), and a blind assign would revive dead state.
  sessionExtras: {
    get: () => ({ ...viewSettings }),
    apply: (v) => {
      for (const k of Object.keys(viewSettings) as (keyof typeof viewSettings)[]) {
        if (typeof v[k] === "number") viewSettings[k] = v[k];
      }
    },
  },
});

// ── Library view: the grid's order, and what its menu can do ──

// The open folder as the grid lays it out: sorted by the picked field, then cut
// into groups (which is also where "is grouping on" is decided, so the grid
// never has to know a group key). Pure and cheap enough to redo on every change
// of the pickers — the catalog's own listing order is what `sortKey: "default"`
// shows.
const library = computed(() => buildSections(folderPhotos.value, sortKey.value, sortDir.value, groupKey.value));

const sortOptions = computed<{ value: SortKey; label: string }[]>(() =>
  SORT_KEYS.map(key => ({ value: key, label: t(`library.sortBy.${key}`) })));
const groupOptions = computed<{ value: GroupKey; label: string }[]>(() =>
  GROUP_KEYS.map(key => ({ value: key, label: t(`library.groupBy.${key}`) })));
const sortControlLabel = computed(() => `${t('library.sort')}: ${sortOptions.value.find(o => o.value === sortKey.value)?.label ?? ''}`);
const groupControlLabel = computed(() => `${t('library.group')}: ${groupOptions.value.find(o => o.value === groupKey.value)?.label ?? ''}`);

// The root is the library itself, and says so in the user's language wherever
// its name is shown.
function folderLabel(folder: { id: number; name: string }): string {
  return folder.id === ROOT_FOLDER_ID ? t("tree.root") : folder.name;
}

const folderCrumbs = computed(() => pathOf(folders.value, selectedFolderId.value).map(folderLabel));

// Where a "move to" can send the selection: every folder in the tree, named by
// its path, minus the one that is open (moving into itself is not a move).
const moveTargets = computed(() => {
  const out: { id: number; label: string }[] = [];
  const walk = (nodes: FolderNode[], prefix: string) => {
    for (const node of nodes) {
      const label = prefix ? `${prefix} / ${folderLabel(node)}` : folderLabel(node);
      if (node.id !== selectedFolderId.value) out.push({ id: node.id, label });
      walk(node.children, label);
    }
  };
  walk(tree.value, "");
  return out;
});

// The tree owns the inline new-folder editor, so the grid's menu asks it to
// start one under the folder that is open rather than inventing a name here.
const folderTree = ref<InstanceType<typeof FolderTree> | null>(null);

// The grid's group navigator (in the sidebar, under the tree): which section is
// at the top of the grid, and the grid itself to scroll when a group is picked.
const photoGrid = ref<InstanceType<typeof PhotoGrid> | null>(null);
const librarySection = ref(-1);

function toggleSortDir(): void { setSort(sortKey.value, sortDir.value === "asc" ? "desc" : "asc"); }
function onGridRename(id: string, name: string): void { void renamePhoto(id, name); }
function onGridMove(ids: string[], folderId: number): void { void movePhotos(ids, folderId); }
function onGridNewFolder(): void { folderTree.value?.startCreate(selectedFolderId.value); }

// Styles this camera actually ships, from the worker. Empty for a body we have
// no profiles for, which hides the picker rather than offering dead options.
const dcpStyles = ref<string[]>([]);
const dcpOptions = computed(() => dcpStyles.value.map(code => ({ value: code, label: styleLabel(code) })));

const engineOptions = computed<{ value: ProfileId; label: string }[]>(() => [
  { value: "standard", label: t("engine.adobe") },
  { value: "sony", label: t("engine.sony") },
]);
const gamutOptions = computed(() => [
  { value: 0, label: "sRGB" },
  { value: 1, label: t("display.p3") },
]);
const exifOptions = computed(() => [
  { value: 0, label: t("exif.full") },
  { value: 1, label: t("exif.private") },
]);

// Mirror the worker's choice into the picker. There is no "auto" entry: the
// style the metadata resolved to is simply the selected one, so the control
// always reads as what is actually applied. Assigning dcpCode here must not
// re-trigger the decode watcher — this *is* the result of that decode.
function applyDcpSelection(selection: ColorProfileMeta["selection"]): void {
  dcpStyles.value = selection?.availableCodes ?? [];
  const matched = selection?.matchedCode ?? "";
  if (matched === dcpCode.value) return;
  suppressDcpReload = true;
  dcpCode.value = matched;
  void nextTick(() => { suppressDcpReload = false; });
  // Auto-detection on a fresh image is part of opening it, not a step of its
  // own: fold it into the starting entry so the history begins at "Open".
  if (history.value.length === 1 && !pendingDirty.value) history.value = [captureSnapshot()];
}

// The Lens group is driven entirely by the per-shot tables in the file's maker
// notes, and both of its sliders only blend those toward identity — so without
// a pair they move nothing at all. Gated on the tables themselves rather than
// on "is a RAW": a RAW shot on adapted glass carries none either.
const visibleGroups = computed(() =>
  groups.filter(g => !g.needsLensCorr || lensCorrAvailable.value));

// ── Edit rail: one group at a time ──

// crop is a tab like the rest, but it drives the viewport's crop editor rather
// than a set of sliders, so cropMode stays the source of truth and the tab
// follows it (the R shortcut and the editor's Done button move both).
const EDIT_TABS: { key: EditTab; icon: Icon }[] = [
  { key: "look", icon: IconAperture },
  { key: "light", icon: IconSun },
  { key: "color", icon: IconPalette },
  { key: "masks", icon: IconDashedCircle },
  { key: "erase", icon: IconEraserSparkle },
  { key: "relight", icon: IconLightbulb },
  { key: "effects", icon: IconCameraLens },
  { key: "detail", icon: IconAsterisk },
  { key: "crop", icon: IconCrop },
  { key: "assistant", icon: IconSparkle },
  { key: "recipes", icon: IconBookmark },
  { key: "history", icon: IconHistory },
  { key: "settings", icon: IconSliders },
];

const editTab = ref<EditTab>((localStorage.getItem("llr.tab") as EditTab | null) ?? "light");

// The history panel's hover preview: anything that changes what the live state
// is — a step taken, another photo, another tab — ends it.
watch([historyIndex, () => activeSource.value?.id, editTab], endHistoryPreview);
// An unfilled erase draft belongs to the photo it was brushed on.
watch(() => activeSource.value?.id, discardEraseDraft);

// Where the rail was before the crop editor took it, so Done lands back on the
// group being edited instead of resetting to Light.
let tabBeforeCrop: EditTab = editTab.value;

// Before an image lands, Settings is the only tab with anything in it; Creative
// Look needs the shot's own as-shot values to reset back to.
// The Creative Look tab is a Sony decode's to offer, and only the decode
// knows — so while one is in flight the tab stays in the rail, disabled,
// rather than popping in a few seconds later (or out, on a re-decode).
const availableTabs = computed(() => {
  const loading = status.value === "uploading" || status.value === "rendering";
  return EDIT_TABS.flatMap(tb => {
    if (!activeSource.value) return tb.key === "settings" ? [{ ...tb, disabled: false }] : [];
    if (tb.key === "look" && !lookAsShot.value) return loading ? [{ ...tb, disabled: true }] : [];
    return [{ ...tb, disabled: false }];
  });
});

const tabGroups = computed(() => visibleGroups.value.filter(g => g.tab === editTab.value));

const curveEdited = computed(() =>
  JSON.stringify(toneCurve.value) !== JSON.stringify(defaultToneCurve()));
const denoiseEdited = computed(() => {
  const d = defaultDenoise() as Record<string, unknown>;
  // The switch means nothing on a Sony frame (sonyDenoiser), so it is not an edit there.
  return Object.entries(denoise).some(([k, v]) => v !== d[k] && !(k === "auto" && sonyDenoiser.value));
});
// The accent dot on a tab: which groups hold a non-default value, so an edit
// buried in a closed tab is still visible.
const tabEdited = computed<Record<EditTab, boolean>>(() => ({
  light: groups.some(g => g.tab === "light" && groupEdited(g)) || curveEdited.value,
  color: groups.some(g => g.tab === "color" && groupEdited(g)) || hslEdited.value || gradingEdited.value,
  masks: masks.length > 0,
  erase: erase.length > 0,
  relight: relightActive(relight),
  effects: groups.some(g => g.tab === "effects" && groupEdited(g)),
  recipes: false,
  detail: groups.some(g => g.tab === "detail" && groupEdited(g)) || denoiseEdited.value,
  look: lookEdited.value,
  crop: !isDefaultCrop(crop),
  assistant: false,
  history: false,
  settings: false,
}));

const anyEdited = computed(() => Object.values(tabEdited.value).some(Boolean));

function selectTab(tab: EditTab): void {
  if (tab === "crop") { enterCropMode(); return; }
  if (cropMode.value) exitCropMode();  // the watch below restores tabBeforeCrop
  editTab.value = tab;
}

watch(cropMode, on => {
  if (on) { if (editTab.value !== "crop") tabBeforeCrop = editTab.value; editTab.value = "crop"; }
  else if (editTab.value === "crop") editTab.value = tabBeforeCrop;
});

watch(editTab, v => {
  if (v !== "crop") localStorage.setItem("llr.tab", v);
  // The curve panel is v-if'd, so its canvas is a fresh element each time the
  // tab opens and has to be redrawn once it's in the DOM.
  if (v === "light") void nextTick(renderCurveCanvas);
});
watch(availableTabs, list => {
  if (list.length && !list.some(tb => tb.key === editTab.value)) editTab.value = list[0].key;
});

// Full-res camera JPEG for the embedded-preview compare. Bound to the overlay
// <img> whenever a source is active, so the browser has it fetched before the
// first hold (thumbSrc may serve a 320px cache — too small to compare against).
// A rendered source's "embedded preview" is just the file itself, so comparing
// against it would show no difference — the mode only means something for RAW.
const embeddedSrc = computed(() =>
  isRawSource.value && activeSource.value?.embeddedUrl ? resolveUrl(activeSource.value.embeddedUrl) : "");

// The camera JPEG is the untouched full frame, so it has to go through the same
// recompose the render did — otherwise the hold jumps to a different framing and
// compares two different pictures. Only the committed view needs this: the
// compare is disabled inside the crop editor.
const embeddedTransform = computed(() => {
  if (!srcW.value || !srcH.value || !imageW.value || !imageH.value) return "";
  const [iw, ih] = imageDims(srcW.value, srcH.value, crop.orientation);
  return cssRecomposeMatrix(
    crop, srcW.value, srcH.value, cropOutputRect(crop, iw, ih), imageW.value, imageH.value);
});
// The overlay's <img>, for the histogram: while the hold shows the camera JPEG
// the scope shows its bins too, binned through the same recompose as the
// overlay so both read the same framing. Null bins (image not decoded yet,
// nothing to compare) leave the render's histogram in place.
const embeddedImgRef = ref<HTMLImageElement | null>(null);
function embeddedHistogramBins() {
  const img = embeddedImgRef.value;
  if (!showEmbedded.value || !img?.complete || !img.naturalWidth) return null;
  if (!srcW.value || !srcH.value || !imageW.value || !imageH.value) return null;
  const [iw, ih] = imageDims(srcW.value, srcH.value, crop.orientation);
  const m = recomposeMatrix(crop, srcW.value, srcH.value, cropOutputRect(crop, iw, ih), imageW.value, imageH.value);
  return binImageThrough(img, srcW.value, srcH.value, m, imageW.value, imageH.value);
}

// Denoise params for the render-linear request. amount is normalised to 0..1;
// disabled (or amount 0) tells the worker to skip inference entirely.
//
// `amount` therefore means two different things depending on where it is read.
// This payload is 0..1 (render-linear, clamped again in protocol.ts). The
// `denoise` state itself, and the Snapshot that persists it, are 0..100 — and
// XMP export reads *that* one, not this, so it writes 0..100 too (cli.py's
// daemon_export). Both ends are consistent today only because export passes
// `settings.denoise` rather than this function's output. Swapping one for the
// other silently changes the number by 100x, so keep them apart.
// edge and chroma are *not* rescaled: 0..100 is the wire scale for those.
function denoisePayload(d: typeof denoise = denoise): DenoisePayload {
  // On a Sony frame the switch is gone and the sliders rule (sonyDenoiser);
  // on the wavelet, Auto is the manual panel at its defaults with every
  // slider greyed out, so the edge value goes out neutral rather than
  // whatever a manual session left. Colour NR is neutralised the same way
  // where it is applied (sonyChromaNrSlider).
  const auto = effectiveDenoiseAuto(d);
  return {
    enabled: d.enabled, auto, amount: d.amount / 100,
    edge: auto ? 50 : d.edge, chroma: d.chroma,
  };
}

// Decode `id`'s linear data and render it into the (reused) WebGL pipeline.
// Returns false if the source can no longer be decoded server-side.
// Concurrent calls can overlap (rapid filmstrip clicks, a dcp/denoise reload
// racing a switch); only the newest call may touch renderer/UI state after an
// await, otherwise the slower decode would land last and show stale pixels.
let loadSeq = 0;
async function loadSource(id: string, opts: { resetView?: boolean } = {}): Promise<boolean> {
  if (!photoById(id)) return false;
  currentSourceId = id;
  const seq = ++loadSeq;
  const stale = () => seq !== loadSeq;
  status.value = "rendering";
  errorMessage.value = null;
  timing.value = null; // stale timing would mask the live status in the footer
  const t0 = performance.now();
  try {
    // look is sent only when it overrides the shot's own settings; without it
    // the worker renders what the body recorded, which is what a fresh import
    // wants and what the panel is then populated from.
    // Full sensor resolution, same as the export path: a capped preview is
    // visibly soft the moment the view is zoomed past fit. The per-frame cost of
    // that does not follow the decode — computePreviewScale sizes the drawing
    // buffer by on-screen device pixels, so a fit view shades the same number of
    // fragments it always did. What it does cost is transfer and VRAM (~140 MB
    // for 24 MP, ~360 MB for 61 MP, as float16).
    const lin = await fetchLinear(decodeBody(id));
    if (stale()) return false;
    if (!lin) { markInvalid(id); return false; }
    const { meta: linMeta, pixels: linearFloat } = lin;

    hasLinearData = true;
    profileCurveLUT = buildProfileLUT(linMeta.colorProfile);
    lookBase = lookCurrent = linMeta.colorProfile;
    if (lookBase?.kind === "sony") void loadToneFamily();
    lensCorr = parseLensCorr(linMeta.colorProfile?.lensCorr);
    // Whether this shot brought correction tables at all, which is what decides
    // if the Lens group is worth offering. Reactive because lensCorr itself is
    // not — it is read by the render path, not by the template.
    lensCorrAvailable.value = lensCorr !== null;
    denoiseUsesChroma.value = linMeta.denoiseUsesChroma;
    eraseError.value = linMeta.erase?.error ?? null;
    isRawSource.value = linMeta.colorProfile?.kind !== "rendered-image";
    // What the worker *actually* rendered with, which is not always what was
    // asked for: "sony" falls back to the DCP path on a RAW without Sony's
    // calibration. The DCP-only controls follow this, not profileId.
    activeProfileKind.value = linMeta.colorProfile?.kind ?? null;
    // Reported by every Sony decode, so the panel shows the shot's own tweaks
    // the moment it appears rather than a row of zeros. Null on the DCP path,
    // which hides the panel — those stages are Sony's, not ours.
    lookAsShot.value = linMeta.colorProfile?.lookAsShot ?? null;
    // The ranges those numbers move over, on the same terms: the engine's, so
    // no slider here can offer a value the worker would clamp back.
    lookRanges.value = linMeta.colorProfile?.lookRanges ?? {};
    // The picker's own two facts. lookAsShotStyle is the reset target and comes
    // from the body; availableLooks is empty on a decode that reported none, in
    // which case the picker hides and the sliders still work.
    lookAsShotStyle.value = linMeta.colorProfile?.lookAsShotStyle
      ?? linMeta.colorProfile?.creativeLook ?? "";
    availableLooks.value = linMeta.colorProfile?.availableLooks ?? [];
    lookBorrowed.value = linMeta.colorProfile?.lookBorrowed === true;
    sharpening.value = readSharpening(linMeta.colorProfile);
    // What the body did with DRO, and whether there is a curve to scale at all.
    // Both are the worker's answer: only it reads the RAW.
    droAvailable.value = linMeta.colorProfile?.droAvailable === true;
    droAsShot.value = linMeta.colorProfile?.droAsShot ?? 0;
    // The offered ladder is the worker's, not ours. Empty simply leaves the
    // level buttons out, which is the right answer for a build that has none.
    droLevels.value = linMeta.colorProfile?.droLevels ?? [];
    applyDcpSelection(linMeta.colorProfile?.selection);
    // Availability is independent of the toggle, so the control stays visible
    // after the user switches the match off (which drops the applied cameraMatch).
    hasCameraMatch.value = linMeta.colorProfile?.cameraMatchAvailable === true;
    srcW.value = linMeta.width;
    srcH.value = linMeta.height;
    srcFullW.value = linMeta.fullWidth ?? linMeta.width;
    srcFullH.value = linMeta.fullHeight ?? linMeta.height;
    if (opts.resetView) { zoom.value = 1; pan.x = 0; pan.y = 0; }

    await nextTick();
    if (stale()) return false;
    if (!canvasRef.value) return false;
    if (!webglRenderer) {
      // WebGL2 missing is a whole-app condition, not a per-image decode error:
      // surface the dedicated unsupported state instead of an error toast.
      try {
        webglRenderer = new PipelineRenderer(canvasRef.value);
      } catch (err) {
        webglUnsupported.value = true;
        throw err;
      }
      p3Supported.value = webglRenderer.p3Supported;
    }
    webglRenderer.uploadImage(linearFloat, linMeta.width, linMeta.height);
    renderedId.value = id;
    // The geometry belongs to this decode's frame (erase fills included): keep
    // it only if it was made for the same one, and fetch it if it is wanted.
    if (relightGeometryKey !== frameKey()) { relightGeometry = null; relightGeometryKey = ""; relightHasGeometry.value = false; }
    webglRenderer.uploadRelightGeometry(relightGeometry);
    void ensureRelightGeometry();
    // uploadImage emptied the mask layers: hand over what belongs to this frame.
    brushDrawn = null;
    if (aiMasks && aiMasks.key !== frameKey()) { aiMasks = null; aiReady.value = false; }
    if (aiMasks) webglRenderer.uploadMaskLayer(AUX_LAYER.ai, aiMasks);
    void ensureAiMasks();
    bakeCurveLUT();
    webglRenderer.uploadProfileCurveLUT(profileCurveLUT);
    webglRenderer.uploadDcpTables(parseDcpTables(linMeta.colorProfile));
    applySonyAdvancedColour();
    hasSonyCameraMatch.value = parseCameraMatch(linMeta.colorProfile?.profileCameraMatch) !== null;
    applySonyCameraMatch();
    // Apply the current crop/straighten (sets output dims, fit, draws, histogram).
    applyCropRender();
    clearInvalid(id);
    status.value = "idle";
    timing.value = Math.round(performance.now() - t0);
    if (previewDirty) armPreviewTimer();
    return true;
  } catch (err) {
    if (stale()) return false; // a newer load owns status/errorMessage now
    status.value = "error";
    errorMessage.value = err instanceof Error ? err.message : String(err);
    return false;
  }
}

let denoiseReloadTimer = 0; // debounce for the denoise watcher below

// A moved Creative Look slider needs no pixels: the tweaks reshape the tone
// curve, the chroma terms and Clarity's gain that the shader applies, and the
// decoded frame is already on the GPU. Nor, usually, does it need the worker:
// the profile the last decode or look switch brought carries the look's own
// calibration (lookCalibration), and rebuildLookProfile is the worker's own
// construction over it — so a drag is a rebuild on this thread and a redraw,
// one frame behind the finger like the Basic sliders. The worker is asked
// only for what the browser cannot do from that block: another look (another
// calibration), a manual DRO preset it does not hold, a profile from an older
// worker, or the family asset not having landed yet.
//
// `lookBase` is that last worker-built profile; the local rebuild never
// replaces it, so every rebuild starts from the same inputs.
let lookBase: ColorProfileMeta | null = null;

function rebuildLookLocally(): ColorProfileMeta | null {
  const family = toneFamilyLoaded();
  if (!lookBase || !family || !lookAsShot.value) return null;
  // Another look is another calibration, which only the worker can read.
  if (effectiveLookStyle.value !== lookBase.creativeLook) return null;
  return rebuildLookProfile(lookBase, effectiveLook.value, renderDro.value, family);
}

// The tail both paths share: the profile onto the renderer and a redraw. The
// camera-match table is per look and Fade state, so it is re-read here — but
// whether there is one at all can only change with the body. `lookCurrent`
// is what is on screen, for a redraw that changes nothing about the look
// (a Colour NR move, which buildProfileLUT reads for Marble).
let lookCurrent: ColorProfileMeta | null = null;
function installLookProfile(profile: ColorProfileMeta): void {
  if (!webglRenderer) return;
  lookCurrent = profile;
  hasSonyCameraMatch.value = parseCameraMatch(profile.profileCameraMatch) !== null;
  profileCurveLUT = buildProfileLUT(profile);
  webglRenderer.uploadProfileCurveLUT(profileCurveLUT);
  scheduleWebGLDraw();
}

// The profile for where the controls are now: rebuilt here when that can be
// done, else asked of the worker. Resolves when it is on screen. A local
// answer retires any request still out for an earlier position, which must
// not land on top of it.
function refreshLook(): Promise<void> {
  const local = rebuildLookLocally();
  if (!local) return reloadLookProfile();
  lookProfileSeq++;
  installLookProfile(local);
  return Promise.resolve();
}

// The request path. Sequenced, not debounced: the request is cheap and a drag
// should track. Its answer becomes the new base, and what goes on screen is a
// local rebuild over that base for wherever the sliders are *now* — the
// request carried the positions at the time it left.
let lookProfileSeq = 0;
async function reloadLookProfile(): Promise<void> {
  if (!currentSourceId || !lookAsShot.value) return;
  const seq = ++lookProfileSeq;
  try {
    const profile = await fetchLookProfile(
      currentSourceId, effectiveLook.value, bypass.has("look") ? undefined : lookStyle.value ?? undefined,
      renderDro.value.strength ?? undefined, renderDro.value.level);
    // A newer slider position (or a different image) owns the renderer now.
    if (seq !== lookProfileSeq || !profile || !webglRenderer) return;
    lookBase = profile;
    lookBorrowed.value = profile.lookBorrowed === true;
    sharpening.value = readSharpening(profile);
    installLookProfile(rebuildLookLocally() ?? profile);
  } catch (err) {
    if (seq !== lookProfileSeq) return;
    status.value = "error";
    errorMessage.value = err instanceof Error ? err.message : String(err);
  }
}

// ── WebGL ──

// Live reactive state by default; pass a Snapshot to derive the params from a
// frozen edit instead (export). viewSettings stays live either way — it is
// view-only state and not part of a per-image snapshot.
//
// `matte` is the mask group drawn as a black-and-white weight instead of the
// photo: undefined follows the Masks panel's live overlay (view-only, so a
// snapshot never carries it), null draws none (the assistant's captures), a
// group id draws that one (view_mask).
// `ctx` stands in for the open photo's own facts — its lens tables and size —
// when the snapshot is another photo's (a background preview render).
function buildPipelineParams(
  s?: Snapshot, opts: { matte?: string | null; ctx?: { lensCorr: LensCorr | null; srcW: number; srcH: number } } = {},
): Partial<EditParams> {
  const lensCorr = opts.ctx ? opts.ctx.lensCorr : lensCorrLiveGet();
  const sw = opts.ctx ? opts.ctx.srcW : srcW.value, sh = opts.ctx ? opts.ctx.srcH : srcH.value;
  // Switched-off panels render at their defaults; a snapshot carries its own
  // switches, the live state its live ones.
  const b: ReadonlySet<BypassKey> = s ? new Set(s.bypass ?? []) : bypass;
  const r = effectiveRecipe(s?.recipe ?? recipe, b);
  const zero = () => [0, 0, 0, 0, 0, 0, 0, 0];
  const [hue, sat, lum] = b.has("hsl") ? [zero(), zero(), zero()] : s ? [s.hslHue, s.hslSat, s.hslLum] : [hslHue, hslSat, hslLum];
  const g = b.has("grading") ? defaultGrading() : (s?.grading ?? grading);
  // Per-shot lens tables with the slider amounts mixed in. The renderer derives
  // the fill scale from these, so easing the slider eases the scale with it.
  const lensDist = lensCorr ? mixLensTable(lensCorr.distortion, (r.lensDistortion ?? 100) / 100) : [...LENS_IDENTITY];
  const lensVig = lensCorr ? mixLensTable(lensCorr.vignetting, (r.lensVignetting ?? 100) / 100) : [...LENS_IDENTITY];
  // Lateral CA has no slider: the body's switch decides (the worker sends the
  // tables only when it is on), as in Edit, where it is part of the same
  // geometric stage as the distortion. A switched-off panel renders at its
  // defaults, and the default is the camera's own correction, so it stays.
  const lensCa = lensCorr?.caR && lensCorr.caB ? { lensCaR: lensCorr.caR, lensCaB: lensCorr.caB } : {};
  return {
    lensDist, lensVig, ...lensCa,
    exposure: r.exposure,
    saturation: 1 + r.saturation / 100,
    highlights: r.highlights / 100,
    shadows: r.shadows / 100,
    vibrance: 1 + r.vibrance / 100,
    clarity: r.clarity,
    dehaze: r.dehaze,
    temperature: r.temperature,
    tint: r.tint,
    hslH: hue.map(v => v / 100),
    hslS: sat.map(v => v / 100),
    hslL: lum.map(v => v / 100),
    gradShTint: gradingTint(g.shH, g.shS / 100),
    gradMdTint: gradingTint(g.mdH, g.mdS / 100),
    gradHlTint: gradingTint(g.hlH, g.hlS / 100),
    gradBlend: g.blend / 100,
    gradBalance: g.balance / 100,
    displayGamut: viewSettings.displayGamut,
    // Not read off the snapshot: the match is a global profile setting, like the
    // display gamut, not a per-image edit that undo should travel with.
    cameraMatch: cameraMatch.value ? 1 : 0,
    nrLuminance: r.nrLuminance ?? 0,
    nrDetail: r.nrDetail ?? 50,
    sharpAmount: (r.sharpAmount ?? 0) / 100, sharpRadius: r.sharpRadius ?? 1,
    sharpDetail: (r.sharpDetail ?? 25) / 100, sharpMasking: (r.sharpMasking ?? 0) / 100,
    defringePurple: (r.defringePurple ?? 0) / 100, defringeGreen: (r.defringeGreen ?? 0) / 100,
    lensBlurAmount: (r.blurAmount ?? 0) / 100, lensBlurRange: (r.blurRange ?? 20) / 100,
    // Texcoord, y up, like every source-frame sampler.
    lensBlurFocus: (r.blurFocusX ?? -1) >= 0 ? [r.blurFocusX, 1 - r.blurFocusY] : [-1, -1],
    fogAmount: (r.fogAmount ?? 0) / 100, fogStart: (r.fogStart ?? 30) / 100,
    vigAmount: (r.vigAmount ?? 0) / 100, vigMid: (r.vigMidpoint ?? 50) / 100,
    vigFeather: (r.vigFeather ?? 50) / 100, vigRound: (r.vigRoundness ?? 0) / 100,
    grainAmount: (r.grainAmount ?? 0) / 100, grainSize: 0.75 + ((r.grainSize ?? 25) / 100) * 3,
    grainRough: (r.grainRoughness ?? 50) / 100,
    ...packRelight(s ? (s.relight ?? null) : relight),
    relightView: !s && editTab.value === "relight" ? relightView.value : 0,
    ...packMasks(b.has("masks") ? [] : (s?.masks ?? masks), effectiveCrop(s?.crop ?? crop, b), sw, sh,
      { temperature: r.temperature, tint: r.tint },
      opts.matte !== undefined ? opts.matte : (!s && maskPreview.value ? selectedMask.value : null)),
  };
}

// ── Camera profile tone curve (the camera's display rendering, applied in the view transform) ──

let profileCurveLUT: ProfileCurve = null;

// Per-image lens correction tables (canonical 16-knot grid), parsed from the
// decode response in loadSource. null = the RAW carries no correction data.
let lensCorr: LensCorr | null = null;
// buildPipelineParams' alias for it (its own `lensCorr` may be another photo's).
const lensCorrLiveGet = () => lensCorr;

function buildProfileLUT(cp: ColorProfileMeta | null | undefined): ProfileCurve {
  const pts = cp?.profileToneCurve;
  if (!pts || pts.length < 2) return null;
  // A per-channel curve is basis-dependent, and the basis belongs to the profile:
  // Sony's MainGamma runs on the body's own near-Rec.709 primaries, a DCP's curve
  // in the ProPhoto working space. The shader rotates accordingly.
  // Sony's RGB2YCC follows the curve immediately and in the same basis, so it
  // travels with it — that keeps preview and export on one path.
  const cross = cp?.profileChromaCross, gain = cp?.profileChromaGain;
  return {
    lut: curveToLUT(pts.map(([x, y]) => ({ x, y }))),
    srgbBasis: cp?.kind === "sony",
    chroma: cross?.length === 4 && gain?.length === 4
      ? {
          cross, gain,
          // Fade 0 — every shot that never touched the slider — is pivot 0 and
          // contrast 1, which is also the right fallback for an older response.
          lumaPivot: cp?.profileLumaPivot ?? 0,
          lumaContrast: cp?.profileLumaContrast ?? 1,
          // YGamma's table, which the same stage indexes Y through first. It is
          // per-look, so it arrives again on every profile rebuild; null for an
          // older response, which renders as the pivot/contrast line alone.
          lumaLut: cp?.profileLumaLut ?? null,
          // ...and the pair "advanced colour reproduction" swaps in for those
          // two. Both travel so the switch stays a redraw; null for an older
          // response, which leaves the switch as the 3-D LUT alone.
          lumaLutAdvanced: cp?.profileLumaLutAdvanced ?? null,
          lumaContrastAdvanced: cp?.profileLumaContrastAdvanced ?? null,
          // Edit's 黑色/白色 pair, the identity on every camera-shot frame and
          // for an older response.
          lumaBlack: cp?.profileLumaBlack ?? 0,
          lumaScale: cp?.profileLumaScale ?? 1,
          saturation: cp?.profileChromaSaturation ?? 1,
          // Edit's 色相, in degrees; 0 (and an older response) skips the stage.
          hue: cp?.profileChromaHue ?? 0,
          // ChromaSuppres, which runs inside the same section. Null both for an
          // older response and for a file whose four SR2 tags could not be
          // read; either way the shader leaves the chroma alone.
          suppress: cp?.profileChromaSuppres ?? null,
          sepia: cp?.profileSepia ?? null,
        }
      : null,
    // DRO. Absent whenever there is nothing to apply — the worker sends no
    // table at strength zero, so this is null both for a shot without DRO and
    // for one where it has been turned off.
    dro: cp?.profileDroGain?.length
      ? {
          lut: cp.profileDroGain,
          logCeiling: cp.droLogCeiling ?? 1,
          lumaWhite: cp.droLumaWhite ?? 1,
          // The bilateral grid, when the worker could build one. Its presence
          // switches the shader from indexing the curve by each pixel to
          // indexing it by the local mean, which is what DRO actually is.
          grid: cp.profileDroGrid ?? null,
          gridLumaWhite: cp.droGridLumaWhite ?? cp.droLumaWhite ?? 1,
        }
      : null,
    // Clarity, likewise absent when there is nothing to do — the worker sends a
    // zero gain for a shot that never touched the setting.
    clarity: cp?.profileClarity?.gain ? cp.profileClarity : null,
    // Sharpening, on the same terms. It runs just before Clarity and shares its
    // compose pass. Zero means there was no readable setting to reproduce, not
    // that the camera had sharpening off — it has no such position.
    sharpen: cp?.profileSharpness?.amount ? cp.profileSharpness : null,
    // Spica, between the two. Sony splits one control across it and sharpening
    // with complementary weights, so a shot can have this on with sharpening
    // barely doing anything, or the reverse — each is gated on its own amount.
    spica: cp?.profileSpica?.amount ? cp.profileSpica : null,
    // Above amount 50 Edit adds a median pass on luma (ZcTaskYNR) that the RAW
    // stage cannot express — captured at export, 50 runs it 0 times and 75/100
    // once per tile (highiso-denoise-gap.md 3). Its mix is (amount - 50) * 2
    // percent, so the default and everything below it leave the chain alone.
    // Sony frames only: the wavelet's amount is a decode blend, not this.
    ynr: sonyDenoiser.value && denoise.enabled ? Math.max(0, (denoise.amount - 50) * 2) : 0,
    // Marble's other half, the chroma cleanup — on for the same reason the three
    // above are, that the engine runs it and reproducing the engine means
    // running it. Unlike them it has no per-shot amount to gate on: the worker
    // sends a calibration for every Sony shot, and the stage's own strength is
    // the ISO and the slider, which sony-marble.ts resolves.
    //
    // The largest single correction in the chain: llr's colour-difference noise
    // measured 6.59x Edit's without it (measured-chroma-gap.md 2.11).
    //
    // 2026-09-10: it is not unconditional. Captured at export, Marble leaves the
    // colour differences alone with Noise Reduction off and removes their fine
    // band with it on Auto (2.23), so the gate is the NR switch. Any change to
    // `denoise` re-fetches the linear data and rebuilds this LUT, which is what
    // keeps the two in step. The panel's colour-NR value is Edit's own 0..10
    // control at ten times the scale (2.24.2), and that position is what
    // reaches the stage — it moves both the thresholds and the blend.
    marble: cp?.profileMarble && denoise.enabled
      ? { ...cp.profileMarble, slider: sonyChromaNrSlider(denoise.chroma, denoiseAuto.value) }
      : null,
    // BSNR_Y, the luma NR of an M/S-size (YCbCr) frame — the one the worker
    // cannot run, because the engine runs it after sharpening on the
    // tone-mapped Y, which only exists in the shader. Gated like Marble on the
    // NR switch (captured: with NR off the engine never enters the stage), and
    // driven by the same Amount and Edge sliders as the RAW stage would be;
    // the block is only ever sent for such a frame.
    lumaNr: cp?.profileLumaNr && denoise.enabled
      ? { ...cp.profileLumaNr, amount: denoise.amount, edge: denoiseAuto.value ? 50 : denoise.edge }
      : null,
    // Camera match, after Marble. The table alone travels here; whether it runs
    // is the switch, pushed at the renderer by applySonyCameraMatch. Null for a
    // body the fit never saw and for an older response.
    cameraMatch: parseCameraMatch(cp?.profileCameraMatch),
  };
}

/**
 * What the panel says about the body's sharpening, or null when there is
 * nothing to say — an unreadable SharpnessRange, which is the only thing that
 * turns the coarse stage off. `range` of -1 never reaches here for that reason.
 */
function readSharpening(cp: ColorProfileMeta | null | undefined) {
  const sharpen = cp?.profileSharpness;
  if (!sharpen?.amount || sharpen.range === undefined || sharpen.level === undefined) return null;
  return {
    level: sharpen.level,
    range: sharpen.range,
    fine: !!cp?.profileSpica?.amount,
  };
}

// ── Histogram ──

// Whether the renderer holds decoded pixels (histogram guard). The decoded
// pixel array itself lives on the GPU after upload — keeping a JS reference
// here would pin ~50 MB per image for nothing.
let hasLinearData = false;
// Which source's pixels the GPU holds. A switch shows the camera JPEG in place
// of the outgoing frame until the decode lands; a same-source re-decode (dcp,
// denoise) keeps the frame on screen instead.
const renderedId = ref("");

// In the crop editor the canvas renders a padded straighten bbox whose
// out-of-image fill would be binned as real pixels — hand the histogram the
// tight crop box instead (it re-renders offscreen with its own transform).
function cropHistogramView(): { width: number; height: number; texXform: Float32Array } {
  const [iw, ih] = currentImageDims();
  const rect = cropOutputRect(crop, iw, ih);
  const [ow, oh] = cropOutputSize(crop, srcW.value, srcH.value);
  return { width: ow, height: oh, texXform: buildCropTransform(crop, srcW.value, srcH.value, rect) };
}

// Histogram updates are throttled and always deferred off the synchronous
// draw/decode path: the read-back stalls the main thread, and at 60fps it would
// recompute far more often than anyone can read. ~11 Hz with a trailing update
// keeps it responsive without taxing slider drags or inflating decode timing.
const histogram = useHistogram({
  renderer: () => webglRenderer,
  ready: () => hasLinearData && !!imageW.value && !!imageH.value,
  view: () => (cropMode.value ? cropHistogramView() : undefined),
  bins: embeddedHistogramBins,
});
const histoCanvasRef = histogram.canvasRef;
const scheduleHistogram = histogram.schedule;
// The camera-JPEG hold is an overlay, not a draw, so no draw reschedules the
// scope for it: do it here, both ways (the release brings the render's back).
watch(showEmbedded, () => scheduleHistogram());

/**
 * Push the advanced-colour switch at the renderer and repaint once it has the
 * table. The first `true` fetches public/sony-lut3d.bin, so the redraw is
 * deferred rather than immediate — and guarded on the renderer still being the
 * one that asked, since a source switch can replace it while the fetch is out.
 * A failed fetch resolves too, leaving the switch inert with one warning.
 */
function applySonyAdvancedColour(): void {
  const renderer = webglRenderer;
  if (!renderer) return;
  void renderer.setSonyAdvancedColour(sonyAdvancedColour.value).then(() => {
    if (webglRenderer === renderer) scheduleWebGLDraw();
  });
}

/**
 * Push the camera-match switch at the renderer. Synchronous, unlike the one
 * above — the table came with the profile — so the caller schedules the draw.
 */
function applySonyCameraMatch(): void {
  webglRenderer?.setSonyCameraMatch(sonyCameraMatch.value);
}

function scheduleWebGLDraw(): void {
  if (drawPending) return;
  drawPending = true;
  rafId = requestAnimationFrame(() => { drawPending = false; drawWebGL(); scheduleHistogram(); });
}

// Edit-free baseline for hold-to-compare: keep view-only settings (display
// gamut) but drop every per-image adjustment. The matching identity tone curve is
// swapped in by the showOriginal watcher (the curve lives in a GPU LUT, not params).
const IDENTITY_CURVE_LUT = buildToneCurveLUT(defaultToneCurve());
function baselineParams(): Partial<EditParams> {
  // Camera match survives the hold for the same reason the gamut does: it is
  // part of how this camera is rendered, not an edit being compared against.
  return { displayGamut: viewSettings.displayGamut, cameraMatch: cameraMatch.value ? 1 : 0 };
}

// On-screen device-pixel footprint of the preview, as a fraction of the image's
// logical (decoded-preview) resolution. The canvas is rendered at this scale and
// CSS-upscaled to fit, so the GPU shades ~one fragment per visible device pixel
// instead of the full decoded frame on every edit. Capped at 1 (never supersample
// past the decoded source); the guard keeps full res until the fit is measured.
function computePreviewScale(): number {
  const displayScale = fitScale.value * zoom.value; // decoded-preview px → screen CSS px
  if (!displayScale || !Number.isFinite(displayScale)) return 1;
  const dpr = window.devicePixelRatio || 1;
  return Math.min(1, displayScale * dpr);
}

// The canvas's CSS box: the render window when there is one, the whole frame
// otherwise. Its transform carries the matching origin offset.
const canvasBoxStyle = computed(() => {
  const w = renderWindow.value;
  return {
    transform: canvasTransform.value,
    width: `${w ? w.w : imageW.value}px`,
    height: `${w ? w.h : imageH.value}px`,
  };
});

// How far beyond the viewport the render window reaches, as a fraction of the
// visible size on each side. Pans within it are pure CSS transform, exactly as
// they were before the window existed; the cost is shading that much extra.
const WINDOW_SLACK = 0.25;
// Rebuild once the window is this many times wider/taller than it needs to be.
// Without it the window would only ever grow: zooming in shrinks the visible
// region monotonically, every smaller region is still contained by the old
// window, and it would sit at whatever size the first zoom step produced. Must
// exceed 1 + 2*WINDOW_SLACK or a freshly built window would re-trigger at once.
const WINDOW_SHRINK = 2;

/**
 * Keep the render window covering what the viewport can see, and report whether
 * it moved (i.e. whether a redraw is owed).
 *
 * Zoomed in, the canvas covers only the visible part of the frame instead of all
 * of it. previewScale cannot do this on its own: it is capped at 1 so as never
 * to supersample the source, which at 1:1 means a drawing buffer the size of the
 * whole frame — 33 MP of fragments for the ~1 MP a viewport can show. Frame cost
 * is very nearly linear in fragment count, so this is that ratio, saved.
 *
 * Returns false for a pan that stays inside the current window: those pixels are
 * already on the canvas and CSS moves it, which is what keeps panning smooth.
 */
function updateRenderWindow(): boolean {
  const cur = renderWindow.value;
  const visible = visibleWindow(0);
  if (!visible) {
    if (!cur) return false;
    renderWindow.value = null;
    return true;
  }
  const covered = cur
    && cur.x <= visible.x && cur.y <= visible.y
    && cur.x + cur.w >= visible.x + visible.w
    && cur.y + cur.h >= visible.y + visible.h;
  const oversized = cur
    && (cur.w > visible.w * WINDOW_SHRINK || cur.h > visible.h * WINDOW_SHRINK);
  if (covered && !oversized) return false;
  renderWindow.value = visibleWindow(WINDOW_SLACK);
  return true;
}

function drawWebGL(): void {
  if (!webglRenderer) return;
  // Contrast/Blacks/Whites all live in the curve LUT bake, not shader uniforms.
  // Draws are rAF-coalesced (scheduleWebGLDraw), so this rebakes at most once
  // per frame during a slider drag (sub-millisecond on the CPU).
  if (!showOriginal.value && !historyPreview.value
    && (bakedBasic === null || !sameBasic(bakedBasic, currentBasic(effectiveRecipe(recipe))))) {
    bakeCurveLUT();
  }
  updateRenderWindow();
  webglRenderer.setViewWindow(renderWindow.value);
  webglRenderer.setPreviewScale(computePreviewScale());
  if (showOriginal.value) { webglRenderer.draw(baselineParams()); return; }
  if (historyPreview.value) { webglRenderer.draw(buildPipelineParams(historyPreview.value)); return; }
  const params = buildPipelineParams();
  syncBrushLayer(params);
  webglRenderer.draw(params);
}

function startCompare(): void { if (activeSource.value && !cropMode.value) showOriginal.value = true; }
function endCompare(): void { showOriginal.value = false; }
function startCompareEmbedded(): void {
  if (activeSource.value && !cropMode.value && embeddedSrc.value) showEmbedded.value = true;
}
function endCompareEmbedded(): void { showEmbedded.value = false; }

// ── WebGL context loss ──
//
// A GPU reset, mobile tab backgrounding, or context-slot eviction kills every
// GL object. preventDefault() opts into the browser's restorable path; on
// restore the renderer is rebuilt from scratch and the active image reloaded
// (deleting the dead handles via release() is a safe no-op on a lost context).
const webglUnsupported = ref(false);

function onContextLost(e: Event): void {
  e.preventDefault();
  destroyWebGL({ keepContext: true });
  status.value = "error";
  errorMessage.value = t("error.contextLost");
}

function onContextRestored(): void {
  errorMessage.value = null;
  status.value = "idle";
  if (currentSourceId) void loadSource(currentSourceId, { resetView: false });
}

// keepContext: release GL objects but keep the canvas's context usable, so the
// persistent preview canvas can host a new renderer later (a canvas whose
// context was lost via destroy() can never get another one).
function destroyWebGL(opts: { keepContext?: boolean } = {}): void {
  if (rafId) { cancelAnimationFrame(rafId); rafId = 0; }
  histogram.cancel();
  drawPending = false;
  if (webglRenderer) {
    if (opts.keepContext) webglRenderer.release();
    else webglRenderer.destroy();
    webglRenderer = null;
  }
}

// ── Crop rendering ──
//
// Normal view: render the crop box region (cropped output dims). Crop editor:
// render the full straightened image's bounding box so the user sees beyond the
// crop, with the overlay drawn on top.

function renderNormal(): void {
  if (!webglRenderer || !srcW.value || !srcH.value) return;
  const [iw, ih] = currentImageDims();
  const c = effectiveCrop(crop);
  const rect = cropOutputRect(c, iw, ih);
  const [ow, oh] = cropOutputSize(c, srcW.value, srcH.value);
  webglRenderer.setOutput(ow, oh, buildCropTransform(c, srcW.value, srcH.value, rect), WORKSPACE_BG);
  imageW.value = ow;
  imageH.value = oh;
  recomputeFit();
  // The frame just changed size, so any window from the previous one is stated
  // in coordinates that no longer mean the same thing. drawWebGL rebuilds it.
  renderWindow.value = null;
  drawWebGL();
  scheduleHistogram();
}

// The bbox renders at preview resolution like the committed view: previewScale
// and the render window keep the drawing buffer at viewport size, so zooming in
// stays crisp without a size cap of its own.
function renderCropEditor(): void {
  if (!webglRenderer || !srcW.value || !srcH.value) return;
  const [iw, ih] = currentImageDims();
  const bbox = straightenedBBox(crop, iw, ih);
  Object.assign(cropBBox, bbox);
  const cw = Math.max(1, Math.round(bbox.w));
  const ch = Math.max(1, Math.round(bbox.h));
  webglRenderer.setOutput(cw, ch, buildCropTransform(crop, srcW.value, srcH.value, bbox), WORKSPACE_BG);
  imageW.value = cw;
  imageH.value = ch;
  recomputeFit();
  renderWindow.value = null;   // same reason as renderNormal
  drawWebGL();
  scheduleHistogram();
}

function applyCropRender(): void {
  if (cropMode.value) renderCropEditor(); else renderNormal();
}

function enterCropMode(): void {
  if (!activeSource.value || cropMode.value) return;
  flushPendingHistory();
  cropMode.value = true;
  // A compare hold can't be released once the crop editor owns the keys/view.
  showOriginal.value = false;
  showEmbedded.value = false;
  zoom.value = 1; pan.x = 0; pan.y = 0;
  // Untouched image with an aspect lock (e.g. the 4:3 default): propose the
  // largest centered box of that ratio, so the lock and the box agree.
  if (isDefaultCrop(crop)) {
    const ratio = lockedRatio.value;
    if (ratio != null) Object.assign(crop, applyAspectRatio(crop, ratio, srcW.value, srcH.value));
  }
  nextTick(renderCropEditor);
}

function exitCropMode(): void {
  if (!cropMode.value) return;
  flushPendingHistory();
  cropMode.value = false;
  lineTool.value = null;
  zoom.value = 1; pan.x = 0; pan.y = 0;
  nextTick(renderNormal);
}

function toggleCropMode(): void {
  if (cropMode.value) exitCropMode(); else enterCropMode();
}

function onKeyDown(e: KeyboardEvent): void {
  const ae = document.activeElement as HTMLElement | null;
  const inEditableText = !!ae && (ae.tagName === "TEXTAREA" ||
    (ae.tagName === "INPUT" && !["range", "checkbox", "radio", "button", "submit"].includes((ae as HTMLInputElement).type)));

  // Undo / redo — work regardless of whether an image is loaded
  if ((e.ctrlKey || e.metaKey) && !inEditableText) {
    const k = e.key.toLowerCase();
    if (k === "z" && !e.shiftKey && eraseDraft.value && editTab.value === "erase") { e.preventDefault(); undoEraseDraftLine(); return; }
    if (k === "z") { e.preventDefault(); if (e.shiftKey) redo(); else undo(); return; }
    if (k === "y") { e.preventDefault(); redo(); return; }
    // Lightroom's copy / paste settings.
    // In the library they act on the grid: copy from the one selected photo,
    // paste onto every selected one. Alt+Shift+C asks what to copy.
    if (e.shiftKey && k === "c") {
      e.preventDefault();
      const from = libraryView.value === "library" && selectedIds.size === 1 ? [...selectedIds][0]! : null;
      if (e.altKey) openCopyDialog(from); else void copyRecipe(from);
      return;
    }
    if (e.shiftKey && k === "v") {
      e.preventDefault();
      if (libraryView.value === "library" && selectedIds.size) void pasteToPhotos([...selectedIds]);
      else void pasteRecipe();
      return;
    }
  }

  // Space held turns drags into pans wherever a tool owns the pointer. A focused
  // button keeps Space as its activation key.
  if (!inEditableText && e.key === " " && activeSource.value && ae?.tagName !== "BUTTON") {
    e.preventDefault(); spaceHeld.value = true; return;
  }

  // G / E switch between the library grid and the develop view (Lightroom's
  // own keys). Only when the grid does not own the key itself.
  if (!inEditableText && !e.ctrlKey && !e.metaKey && !e.altKey && !cropMode.value) {
    if (e.key === "g" || e.key === "G") { e.preventDefault(); setView("library"); return; }
    if ((e.key === "e" || e.key === "E") && activeSource.value) { e.preventDefault(); setView("develop"); return; }
  }

  // Crop tool: R toggles, Esc / Enter commit & exit, X swaps orientation,
  // O cycles the guide overlay, Shift+O mirrors it (Lightroom-style).
  if (!inEditableText && activeSource.value && !e.ctrlKey && !e.metaKey && !e.altKey && libraryView.value === "develop") {
    if (e.key === "r" || e.key === "R") { e.preventDefault(); toggleCropMode(); return; }
    if (cropMode.value && lineTool.value && e.key === "Escape") { e.preventDefault(); lineTool.value = null; return; }
    if (cropMode.value && (e.key === "Delete" || e.key === "Backspace") && crop.xf.guides.length) { e.preventDefault(); removeLastGuide(); return; }
    if (cropMode.value && (e.key === "Escape" || e.key === "Enter")) { e.preventDefault(); exitCropMode(); return; }
    if (cropMode.value && (e.key === "x" || e.key === "X")) { e.preventDefault(); swapAspect(); return; }
    if (cropMode.value && e.key === "O") { e.preventDefault(); cycleCropGuideVariant(); return; }
    if (cropMode.value && e.key === "o") { e.preventDefault(); cycleCropGuide(); return; }
  }

  // Erase: Enter fills what the draft has brushed, Esc drops it.
  if (!inEditableText && eraseDraft.value && editTab.value === "erase" && libraryView.value === "develop" && !cropMode.value) {
    if (e.key === "Enter") { e.preventDefault(); commitEraseDraft(); return; }
    if (e.key === "Escape") { e.preventDefault(); discardEraseDraft(); return; }
  }

  // Backslash holds the "before" view; release (onKeyUp) restores the edit.
  if (!inEditableText && e.key === "\\" && activeSource.value && !cropMode.value) {
    e.preventDefault();
    showOriginal.value = true; // watcher guards against redundant redraws on repeat
    return;
  }

  // Shift+Backslash ("|") holds the camera-JPEG view (the RAW's embedded preview).
  if (!inEditableText && e.key === "|" && activeSource.value && !cropMode.value) {
    e.preventDefault();
    if (embeddedSrc.value) showEmbedded.value = true;
    return;
  }

  if (!imageW.value || !imageH.value) return;
  if (e.ctrlKey || e.metaKey) {
    switch (e.key) {
      case '0': e.preventDefault(); fitView(); break;
      case '1': e.preventDefault(); zoomToFull(); break;
      case '=': case '+': e.preventDefault(); zoomIn(); break;
      case '-': e.preventDefault(); zoomOut(); break;
    }
  }
}

function onKeyUp(e: KeyboardEvent): void {
  if (e.key === " ") spaceHeld.value = false;
  if (e.key === "\\") showOriginal.value = false; // release the hold-to-compare view
  // Releasing Shift before the key makes the keyup report "\" instead of "|",
  // so either key ends the camera-JPEG hold.
  if (e.key === "\\" || e.key === "|") showEmbedded.value = false;
}

// Alt-Tab (or Cmd+backslash) mid-hold sends the keyup to the newly focused
// window, so onKeyUp never fires and the 'before' view would stick on forever.
function onWindowBlur(): void {
  spaceHeld.value = false;
  showOriginal.value = false;
  showEmbedded.value = false;
}

// ── upload ──

// Auto-redraw on edit. Suppressed during restore/switch so we don't flash the
// previous image with the new params before loadSource() uploads the pixels.
// Hold-to-compare swaps the tone-curve LUT (a GPU texture, not a draw param) for
// identity while previewing the original, restoring the live curve on release.
watch(showOriginal, () => {
  // bakeCurveLUT owns the rule: it swaps in identity while showOriginal is on
  // and restores the live curve when it clears, so the watcher only has to bake.
  if (!webglRenderer) return;
  bakeCurveLUT();
  scheduleWebGLDraw();
});

// One deep watcher per object, doing draw + history + persist together: a
// second deep watcher over the same objects would re-traverse them on every
// slider input for no benefit (history/persist scheduling self-guards on
// isRestoring and is debounced).
watch([recipe, hslHue, hslSat, hslLum, grading, masks, relight, () => [...bypass]], () => {
  if (!isRestoring) scheduleWebGLDraw();
  scheduleHistoryCommit();
  schedulePersist();
  schedulePreview();
}, { deep: true });
// The switches that reach something other than a draw parameter: the curve
// LUT bake (the tone group's Basic terms rebake on their own, drawWebGL
// compares them per frame) and the output geometry.
watch(() => bypass.has("curve"), () => { if (webglRenderer && !isRestoring) bakeCurveLUT(); });
watch(() => bypass.has("transform"), () => { if (!isRestoring) scheduleCropRender(); });
// The overlay is a draw parameter, not an edit: redraw, no history.
watch([maskPreview, selectedMask], () => scheduleWebGLDraw());
watch(viewSettings, () => { scheduleWebGLDraw(); schedulePersist(); }, { deep: true });

// Zoom/fit only move CSS pixels; the drawing buffer is rendered at the on-screen
// scale, so re-rasterise when it changes to stay crisp (zoom in) or shed fragments
// (zoom out / resize). rAF-batched, so wheel and resize bursts collapse to one draw.
watch([zoom, fitScale], () => { if (webglRenderer) scheduleWebGLDraw(); });

// Panning is a CSS transform and normally costs no redraw at all. Zoomed in the
// canvas only covers the visible part of the frame (updateRenderWindow), so a
// pan that reaches the edge of that window has to re-render — but only then,
// which is what the window's slack is for.
watch([() => pan.x, () => pan.y], () => {
  if (!webglRenderer) return;
  if (updateRenderWindow()) scheduleWebGLDraw();
});

// Crop changes resize the output, so they re-render (not just redraw) the editor
// or the committed view. rAF-coalesced like scheduleWebGLDraw: crop drags emit
// mousemove faster than the display refreshes, and each render is a full
// setOutput + pipeline draw.
let cropRenderPending = false;
function scheduleCropRender(): void {
  if (cropRenderPending) return;
  cropRenderPending = true;
  requestAnimationFrame(() => { cropRenderPending = false; applyCropRender(); });
}
watch(crop, () => {
  if (!isRestoring) scheduleCropRender();
  scheduleHistoryCommit();
  schedulePersist();
  schedulePreview();
}, { deep: true });

// History/persist for the edit state not covered above (redraws handled by
// their own paths: curve LUT bake, dcp/denoise re-decode; aspect is snapshot
// state but changes no pixels by itself).
watch([toneCurve, dcpCode, profileId, denoise, cropAspect, look, lookStyle, droStrength, droLevel, sonyAdvancedColour, sonyCameraMatch],
  () => { scheduleHistoryCommit(); schedulePersist(); schedulePreview(); }, { deep: true });

// Sony's advanced colour reproduction. The same trade the camera-match toggle
// makes: the table is static and lives in a uniform's texture, so the switch
// costs a redraw and never a RAW round-trip.
watch(sonyAdvancedColour, () => {
  if (!currentSourceId) return;
  applySonyAdvancedColour();
});

// Camera match: the table is already in the renderer's uniforms, so the
// switch is a flag and a redraw.
watch(sonyCameraMatch, () => {
  if (!currentSourceId) return;
  applySonyCameraMatch();
  scheduleWebGLDraw();
});

// The Creative Look: style, sliders and DRO. Not a re-decode: reloadLookProfile
// swaps the profile LUT under the pixels already on the GPU. Suppressed only
// while a source load is in flight (that request carries the same tweaks
// itself) — undo/redo must go through here, exactly as it does for dcpCode.
// The promise is kept so the assistant can await the render it caused.
let lookReload: Promise<void> = Promise.resolve();
watch([look, lookStyle, droStrength, droLevel, () => bypass.has("look")], () => {
  if (!suppressDcpReload) lookReload = refreshLook();
}, { deep: true });

// Re-decode when the user changes the DCP style or the colour engine (keeps the
// current view). Suppressed while a source load is already handling the decode.
watch([dcpCode, profileId], async () => {
  if (suppressDcpReload || !currentSourceId) return;
  await loadSource(currentSourceId, { resetView: false });
});

// The camera-match table is a HueSatMap, and every HueSatMap now travels to the
// shader rather than being baked into linear.bin — so this is a redraw, not a
// re-decode. It used to cost a full RAW round-trip.
watch(cameraMatch, () => {
  if (!currentSourceId) return;
  scheduleWebGLDraw();
});

// Denoise is baked into linear.bin, so changes re-decode like dcpCode. Debounced
// because amount is a slider (the first decode runs inference; later ones hit the
// worker's cache and only re-blend). The amount slider is hidden while disabled,
// so a change here always alters the effective output.
let denoiseReload: Promise<unknown> = Promise.resolve();
function reloadDenoise(): Promise<unknown> {
  denoiseReloadTimer = 0;
  denoiseBusy.value = true;
  return denoiseReload = loadSource(currentSourceId, { resetView: false }).finally(() => { denoiseBusy.value = false; });
}
function scheduleDenoiseReload(): void {
  if (suppressDcpReload || !currentSourceId) return;
  if (denoiseReloadTimer) clearTimeout(denoiseReloadTimer);
  denoiseReloadTimer = window.setTimeout(reloadDenoise, 250);
}
// Every control but Colour NR reaches the decode; Colour NR does only where
// the frame's denoiser takes it (the worker keys it out of its cache the same
// way). Any change at all is also a redraw of the profile as it stands: on a
// Sony frame Colour NR drives Marble in the shader, which buildProfileLUT
// reads, and the switch gates it. The flag is read in the callback, not
// tracked: a source switch changes it and must not re-decode on its own.
watch([() => denoise.enabled, () => denoise.auto, () => denoise.amount, () => denoise.edge], scheduleDenoiseReload);
watch(() => denoise.chroma, () => { if (denoiseUsesChroma.value) scheduleDenoiseReload(); });
watch(denoise, () => {
  if (!suppressDcpReload && currentSourceId && lookCurrent) installLookProfile(lookCurrent);
}, { deep: true });

// Erase is baked into the decode too (the worker fills before the frame leaves),
// so a stroke added, removed or undone re-requests it. Not debounced: a stroke
// arrives whole on pointer-up. Fills the worker already made are cached, so
// only the new one costs inference.
watch(() => JSON.stringify(erase), () => {
  scheduleHistoryCommit();
  schedulePersist();
  schedulePreview();
  if (suppressDcpReload || !currentSourceId) return;
  eraseBusy.value = true;
  void loadSource(currentSourceId, { resetView: false }).finally(() => { eraseBusy.value = false; });
});

// Whether this machine can erase at all, asked when the tab opens (the worker
// may have gained its model since) — and why not, which is what the panel says.
// A missing model is fetched right away (once per failure: a failed download
// waits for the retry button), and polled until it lands; strokes that were
// waiting on it are then filled by reloading the decode.
let erasePoll: number | undefined;
function setEraseStatus(st: ModelStatus): void {
  const was = eraseStatus.value;
  eraseStatus.value = st;
  window.clearTimeout(erasePoll);
  if (st.reason === "downloading") erasePoll = window.setTimeout(() => void refreshEraseStatus(), 1000);
  if (st.available && was && !was.available && erase.length && currentSourceId) {
    eraseBusy.value = true;
    void loadSource(currentSourceId, { resetView: false }).finally(() => { eraseBusy.value = false; });
  }
}
async function refreshEraseStatus(download = false): Promise<void> {
  try {
    let st = await fetchModelStatus("erase", download);
    if (st.reason === "models-missing" && !st.detail && !download) st = await fetchModelStatus("erase", true);
    setEraseStatus(st);
  } catch { /* the panel keeps its last word; the next tab visit asks again */ }
}
watch(editTab, v => { if (v === "erase") void refreshEraseStatus(); }, { immediate: true });
onBeforeUnmount(() => window.clearTimeout(erasePoll));
const fmtMB = (n: number) => `${Math.round(n / 1e6)} MB`;
// ── Relight geometry ──
//
// One fetch per decode (the worker caches it beside the source too), asked for
// only when it would be used: the tab is open or the edit has a rig. The body
// is loadSource's, so the worker estimates on the very frame on screen.
//
// The full-resolution decode the preview shows (see loadSource): the relight
// geometry and the AI mattes are estimated on exactly this frame.
function decodeBody(id: string): Record<string, unknown> {
  return {
    sourceId: id, halfSize: false, maxSize: 0, profileId: profileId.value, dcpCode: dcpCode.value,
    denoise: denoisePayload(), look: bypass.has("look") ? undefined : look.value ?? undefined,
    style: bypass.has("look") ? undefined : lookStyle.value ?? undefined,
    dro: renderDro.value.strength ?? undefined, droLevel: renderDro.value.level, erase: eraseWire(erase),
  };
}
// The decode an analysis belongs to: the source and its erase fills.
function frameKey(): string | null {
  return currentSourceId && webglRenderer ? `${currentSourceId}|${JSON.stringify(eraseWire(erase))}` : null;
}
watch(editTab, v => {
  void ensureRelightGeometry();
  if (relightView.value) scheduleWebGLDraw();
  if (v !== "effects") pickingFocus.value = false;
});
// Everything that reads the scene's geometry: the rig, depth masks, lens blur
// and fog — plus the two tabs where it is about to be wanted.
function snapshotNeedsGeometry(s: { relight?: RelightState; recipe: Recipe; masks?: MaskGroup[] }): boolean {
  return (!!s.relight && relightActive(s.relight)) || (s.recipe.blurAmount ?? 0) > 0 || (s.recipe.fogAmount ?? 0) !== 0
    || (s.masks ?? []).some(g => g.enabled && g.components.some(c => c.type === "depth"));
}
function geometryWanted(): boolean {
  return editTab.value === "relight" || editTab.value === "effects"
    || snapshotNeedsGeometry({ relight, recipe: effectiveRecipe(recipe), masks: bypass.has("masks") ? [] : masks });
}
const {
  busy: relightBusy, error: relightError, status: relightStatus, notice: relightNotice, ensure: ensureRelightGeometry,
} = useWorkerAnalysis<RelightGeometry>({
  model: "relight", key: frameKey, wanted: geometryWanted,
  has: key => relightGeometryKey === key && !!relightGeometry,
  fetch: () => fetchRelightGeometry(decodeBody(currentSourceId!)),
  apply: (key, geo) => {
    relightGeometry = geo;
    relightGeometryKey = key;
    relightHasGeometry.value = true;
    webglRenderer?.uploadRelightGeometry(geo);
    scheduleWebGLDraw();
  },
});
const selectedLightObj = computed(() => relight.lights.find(l => l.id === selectedLight.value) ?? null);

// ── AI mask mattes ──
//
// Fetched like the geometry, once per decode and only when a mask reads them
// (worker ai_masks.py); handed to the renderer's aux array as a layer.
type AiMattes = { data: Uint8Array; w: number; h: number };
let aiMasks: (AiMattes & { key: string }) | null = null;
const aiReady = ref(false);
function aiWanted(): boolean {
  return !bypass.has("masks") && masks.some(g => g.enabled && g.components.some(c => c.type === "ai"));
}
const { notice: aiAnalysisNotice, ensure: ensureAiMasks } = useWorkerAnalysis<AiMattes>({
  model: "ai", key: frameKey, wanted: aiWanted,
  has: key => aiMasks?.key === key,
  fetch: () => fetchAiMasks(decodeBody(currentSourceId!)),
  apply: (key, res) => {
    aiMasks = { key, ...res };
    aiReady.value = true;
    webglRenderer?.uploadMaskLayer(AUX_LAYER.ai, res);
    scheduleWebGLDraw();
  },
});
const aiNotice = computed(() => aiAnalysisNotice.value ?? (aiReady.value ? null : t("ai.analyzing")));

// The brush layer: rasterised from the packed brush components whenever they
// (or the image) change, at the aux array's size.
let brushDrawn: { w: number; h: number; brushes: BrushStroke[][] } | null = null;
function syncBrushLayer(p: Partial<EditParams> & { maskBrushes?: BrushStroke[][] }): void {
  if (!webglRenderer) return;
  const dims = webglRenderer.auxDims();
  const brushes = p.maskBrushes ?? [];
  if (!dims) return;
  const d = brushDrawn;
  if (d && d.w === dims[0] && d.h === dims[1] && sameBrushes(d.brushes, brushes)) return;
  brushDrawn = { w: dims[0], h: dims[1], brushes: brushes.map(s => s.slice()) };
  webglRenderer.uploadMaskLayer(AUX_LAYER.brush, brushes.length
    ? { data: rasterBrushes(brushes, dims[0], dims[1]), w: dims[0], h: dims[1] } : null);
}

const eraseDownloading = computed(() => eraseStatus.value?.reason === "downloading");
const eraseNotice = computed(() => {
  const st = eraseStatus.value;
  if (st?.reason === "downloading") {
    const total = st.total ?? 0, got = st.received ?? 0;
    return t("erase.downloading", { pct: total ? Math.floor((100 * got) / total) : 0, got: fmtMB(got), total: fmtMB(total) });
  }
  if (st?.reason === "models-missing" && st.detail) return t("erase.downloadFailed", { detail: st.detail });
  if (eraseError.value) return t("erase.failed", { detail: eraseError.value });
  if (!st || st.available) return null;
  if (st.reason === "models-missing") return t("erase.missingModels", { dir: st.modelDir ?? "" });
  if (st.reason === "runtime-missing") return t("erase.missingRuntime");
  return t("erase.loadFailed", { detail: st.detail ?? "" });
});

// Flush the latest edit on tab close. Only a keepalive request survives the
// unload, so also flush whenever the tab goes hidden — that fires earlier and
// more reliably than beforeunload (mobile tab switches, window close).
function persistOnUnload(): void { persistForUnload(); }
function persistOnHidden(): void { if (document.visibilityState === "hidden") persistNow(); }

onBeforeUnmount(() => {
  window.removeEventListener('keydown', onKeyDown);
  window.removeEventListener('keyup', onKeyUp);
  window.removeEventListener('blur', onWindowBlur);
  window.removeEventListener('beforeunload', persistOnUnload);
  document.removeEventListener('visibilitychange', persistOnHidden);
  canvasRef.value?.removeEventListener('webglcontextlost', onContextLost);
  canvasRef.value?.removeEventListener('webglcontextrestored', onContextRestored);
  resizeObs?.disconnect();
  histogram.dispose();
  destroyWebGL();
});

onMounted(async () => {
  window.addEventListener('keydown', onKeyDown);
  window.addEventListener('keyup', onKeyUp);
  window.addEventListener('blur', onWindowBlur);
  window.addEventListener('beforeunload', persistOnUnload);
  document.addEventListener('visibilitychange', persistOnHidden);
  canvasRef.value?.addEventListener('webglcontextlost', onContextLost);
  canvasRef.value?.addEventListener('webglcontextrestored', onContextRestored);
  resizeObs = new ResizeObserver(() => recomputeFit());
  if (viewportRef.value) resizeObs.observe(viewportRef.value);

  // Load the catalog (adopting a pre-catalog IndexedDB library first, if this
  // browser has one) and reopen where the last session left off; a fresh
  // library starts at the dropzone.
  await boot();
});

// The hidden pickers import into the folder that is open in the tree.
function pickFiles(): void { fileInput.value?.click(); }
function pickFolder(): void { folderInput.value?.click(); }

async function onFileChange(e: Event): Promise<void> {
  const t = e.target as HTMLInputElement;
  if (!t.files) return;
  await importFiles(Array.from(t.files).map(file => ({ file, folderId: selectedFolderId.value })));
  t.value = "";
}

async function onFolderChange(e: Event): Promise<void> {
  const t = e.target as HTMLInputElement;
  if (!t.files) return;
  await importPickedDirectory(Array.from(t.files), selectedFolderId.value);
  t.value = "";
}

// A drag that starts inside the page is never an import, even when it carries
// "Files": the browser packs a dragged <img> (the stand-in JPEG while a photo
// decodes, say) as a file, and dropping it would upload the picture back into
// the library. dragstart only fires for drags born in this document, so it
// marks them; dragend (fired even after a drop elsewhere) clears the mark.
let internalDrag = false;
function onDocDragStart(): void { internalDrag = true; }
function onDocDragEnd(): void { internalDrag = false; }
document.addEventListener("dragstart", onDocDragStart);
document.addEventListener("dragend", onDocDragEnd);
onBeforeUnmount(() => {
  document.removeEventListener("dragstart", onDocDragStart);
  document.removeEventListener("dragend", onDocDragEnd);
});

// A drag only means "import" when it actually carries files from outside the
// page. Dragging a filmstrip thumbnail — or any text/link — fires dragover on
// the shell too, and without this gate the full-screen import overlay flashes
// on every such drag.
function onDragOver(e: DragEvent): void {
  e.preventDefault();
  if (!internalDrag && e.dataTransfer?.types.includes("Files")) isDragging.value = true;
}

// dragleave bubbles from every child the pointer crosses on its way across the
// shell; only a null relatedTarget means the drag really left the window.
function onDragLeave(e: DragEvent): void {
  if (!e.relatedTarget) isDragging.value = false;
}

// A drop anywhere on the shell imports into the open folder; drops on a tree
// row are handled (and stopped) there. A photo dragged out of the grid or
// filmstrip and let go on the stage is not an import — nor anything.
async function onDrop(e: DragEvent): Promise<void> {
  e.preventDefault();
  isDragging.value = false;
  const dt = e.dataTransfer;
  if (!dt || internalDrag || dt.types.includes("application/x-llr-photos") || dt.types.includes("application/x-llr-folder")) return;
  if (!dt.types.includes("Files")) return;
  await importDropped(dt, selectedFolderId.value);
}

// A drop the tree took (it stops propagation, so the shell's own drop
// handler never clears the overlay).
function onTreeDrop(dt: DataTransfer, folderId: number): void {
  isDragging.value = false;
  if (internalDrag) return;
  void importDropped(dt, folderId);
}

// Removal asks first when it is more than one photo: a Delete on a multi-select
// in the grid should not silently take a whole shoot out of the library.
async function removePhotosConfirmed(ids: string[]): Promise<void> {
  if (ids.length > 1 && !window.confirm(t("grid.removeConfirm", { n: ids.length }))) return;
  await removePhotos(ids);
}

function resetRecipe(): void {
  Object.assign(recipe, defaultRecipe());
  resetHslGrading();
  resetCurve();
  masks.splice(0);
  erase.splice(0);
  resetRelight();
}

// ── Assistant ──
//
// The chat tab. The agent loop itself runs on the API (apps/api/src/agent.ts);
// what lives here is the model's view of the edit and the tools it calls, run
// against the same reactive state the sliders drive — so every change it makes
// redraws, lands in history and persists exactly like a hand edit.

const SLIDER_SPECS = groups.flatMap(g => g.items);
const GRADING_NAMES = { shadows: "sh", midtones: "md", highlights: "hl" } as const;

function requireImage(): void {
  if (!activeSource.value || !hasLinearData) throw new Error("No image is loaded");
}

function describeEdit(): unknown {
  const [iw, ih] = currentImageDims();
  return {
    image: { width: srcFullW.value, height: srcFullH.value, orientedWidth: iw, orientedHeight: ih, name: activeSource.value?.name },
    sliders: Object.fromEntries(visibleGroups.value.flatMap(g => g.items).map(sp =>
      [sp.key, { value: recipe[sp.key], min: sp.min, max: sp.max, default: SLIDER_DEFAULTS[sp.key] }])),
    lensBlurFocus: recipe.blurFocusX >= 0 ? (() => {
      const [x, y] = strokeToView(recipe.blurFocusX, recipe.blurFocusY, crop, viewLens());
      return { x: +x.toFixed(3), y: +y.toFixed(3) };
    })() : "centre",
    hsl: Object.fromEntries(HSL_RANGES.map((r, i) => [r.key, { hue: hslHue[i], sat: hslSat[i], lum: hslLum[i] }])),
    grading: {
      ...Object.fromEntries(Object.entries(GRADING_NAMES).map(([name, p]) => [name, { hue: grading[`${p}H`], sat: grading[`${p}S`] }])),
      blend: grading.blend, balance: grading.balance,
    },
    curve: toneCurve.value,
    crop: { cx: crop.cx, cy: crop.cy, w: crop.w, h: crop.h, angle: crop.angle, orientation: crop.orientation, flipH: crop.flipH, flipV: crop.flipV, aspect: cropAspect.value },
    // In the schema's units: hues in degrees, radial feather 0..100.
    masks: masks.map(g => ({
      ...g,
      components: g.components.map(c =>
        c.type === "color" ? { ...c, hue: deg(c.hue), hueWidth: deg(c.hueWidth) }
        : c.type === "radial" ? { ...c, feather: Math.round(c.feather * 100) }
        : c),
    })),
    // Sony renders only: the look, its tweaks on the panel scale, and DRO.
    // Null says the engine has no such stage rather than that it is off.
    look: lookAsShot.value ? {
      style: effectiveLookStyle.value, asShotStyle: lookAsShotStyle.value, available: availableLooks.value,
      tweaks: Object.fromEntries(lookSliders.value.map(sp =>
        [sp.key, { value: effectiveLook.value[sp.key], min: sp.min, max: sp.max, asShot: lookAsShot.value![sp.key] }])),
      advancedColour: sonyAdvancedColour.value,
      // Null when the worker has no fitted table for this body: the switch
      // is not offered, so there is nothing to report or to set.
      cameraMatch: hasSonyCameraMatch.value ? sonyCameraMatch.value : null,
      dro: droAvailable.value ? {
        mode: droMode.value, level: droLevel.value < 0 ? null : droLevels.value.indexOf(droLevel.value) + 1,
        levels: droLevels.value.length, strength: effectiveDro.value, asShotStrength: droAsShot.value, maxStrength: DRO_MAX,
      } : null,
    } : null,
    denoise: isRawSource.value ? { ...denoise } : null,
  };
}

// Render the whole (cropped) frame at a modest size — the live edit, or a
// frozen Snapshot (the "before" of a compare) without touching reactive state
// or history. Borrows the preview renderer for one draw: window off, scale set
// from the target size, the snapshot's own curve LUT uploaded; then bakedBasic
// is dropped so the next frame rebakes the live LUT and puts the view back.
function renderFrame(s: Snapshot | null, maxEdge: number, matte?: string): PipelineRenderer {
  requireImage();
  if (!webglRenderer) throw new Error("WebGL renderer unavailable");
  const b: ReadonlySet<BypassKey> = s ? new Set(s.bypass ?? []) : bypass;
  webglRenderer.uploadCurveLUT(buildToneCurveLUT(
    b.has("curve") ? defaultToneCurve() : (s?.curve ?? toneCurve.value),
    currentBasic(effectiveRecipe(s?.recipe ?? recipe, b))));
  webglRenderer.setViewWindow(null);
  webglRenderer.setPreviewScale(maxEdge / Math.max(imageW.value, imageH.value));
  webglRenderer.draw(buildPipelineParams(s ?? undefined, { matte: matte ?? null }));
  bakedBasic = null;
  scheduleWebGLDraw();
  return webglRenderer;
}

async function captureFrame(s: Snapshot | null, maxEdge: number, matte?: string): Promise<Blob> {
  return renderFrame(s, maxEdge, matte).toBlob("image/jpeg", 0.85);
}

// ── Edited preview ──
// Once an edit settles, a ~1024px rendering of it is stored as the photo's
// preview: the filmstrip and the grid show it instead of the camera's
// thumbnail, and opening the photo shows it while the RAW decodes.
const PREVIEW_EDGE = 1024;
const PREVIEW_SETTLE_MS = 1000;
let previewDirty = false;
let previewTimer = 0;

function armPreviewTimer(): void {
  clearTimeout(previewTimer);
  previewTimer = window.setTimeout(flushPreview, PREVIEW_SETTLE_MS);
}

function schedulePreview(): void {
  if (isRestoring) return;
  previewDirty = true;
  armPreviewTimer();
}

// Renders and reads the pixels synchronously (only the JPEG encode and the
// upload are async), so beforeActivate can call it while the renderer still
// holds the outgoing photo.
function flushPreview(): void {
  clearTimeout(previewTimer);
  previewTimer = 0;
  const id = activeSource.value?.id;
  if (!previewDirty || !id || !webglRenderer || !hasLinearData) return;
  // The pixels must be this photo's and the frame its final crop, not the
  // crop editor's straighten box; otherwise wait for things to settle.
  if (renderedId.value !== id || status.value !== "idle" || cropMode.value) {
    armPreviewTimer();
    return;
  }
  const [ow, oh] = cropOutputSize(effectiveCrop(crop), srcW.value, srcH.value);
  if (imageW.value !== ow || imageH.value !== oh) renderNormal(); // a crop render still queued
  previewDirty = false;
  captureFrame(null, PREVIEW_EDGE).then(
    jpeg => savePreview(id, jpeg),
    err => console.warn("failed to render the preview:", err));
}

async function blobToBase64(blob: Blob): Promise<string> {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  let bin = "";
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}

// Before/after side by side on one canvas, labels burnt in, the way a person
// would flick hold-to-compare — the model gets both halves in one look.
function compareFrames(before: Snapshot, halfEdge = 512): Promise<Blob> {
  return sideBySide(captureFrame(before, halfEdge), captureFrame(null, halfEdge), ["before", "after"]);
}

// The photo next to one mask's matte (white = the adjustment applies in
// full), so the model can check a selection before it trusts it.
function matteFrames(maskId: string, halfEdge = 512): Promise<Blob> {
  return sideBySide(captureFrame(null, halfEdge), captureFrame(null, halfEdge, maskId), ["photo", "mask"]);
}

async function sideBySide(left: Promise<Blob>, right: Promise<Blob>, [leftLabel, rightLabel]: readonly [string, string]): Promise<Blob> {
  const [a, b] = await Promise.all([left, right].map(p => p.then(createImageBitmap)));
  const gap = 4;
  const cvs = document.createElement("canvas");
  cvs.width = a.width + gap + b.width;
  cvs.height = Math.max(a.height, b.height);
  const ctx = cvs.getContext("2d");
  if (!ctx) throw new Error("2D context unavailable");
  ctx.fillStyle = "#808080";
  ctx.fillRect(0, 0, cvs.width, cvs.height);
  ctx.drawImage(a, 0, 0);
  ctx.drawImage(b, a.width + gap, 0);
  ctx.font = "bold 16px sans-serif";
  ctx.textBaseline = "top";
  for (const [label, x] of [[leftLabel, 0], [rightLabel, a.width + gap]] as const) {
    const w = ctx.measureText(label).width + 12;
    ctx.fillStyle = "rgba(0,0,0,0.6)";
    ctx.fillRect(x, 0, w, 24);
    ctx.fillStyle = "#fff";
    ctx.fillText(label, x + 6, 4);
  }
  return new Promise<Blob>((res, rej) => cvs.toBlob(b => (b ? res(b) : rej(new Error("toBlob failed"))), "image/jpeg", 0.85));
}

// The edit as flat "path → value" pairs, so two snapshots diff line by line
// (exposure 0 → 0.4) instead of the model re-reading the whole state.
function flattenEdit(s: Snapshot): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const sp of SLIDER_SPECS) out[sp.key] = s.recipe[sp.key];
  HSL_RANGES.forEach((r, i) => { out[`hsl.${r.key}.hue`] = s.hslHue[i]; out[`hsl.${r.key}.sat`] = s.hslSat[i]; out[`hsl.${r.key}.lum`] = s.hslLum[i]; });
  for (const [name, p] of Object.entries(GRADING_NAMES)) { out[`grading.${name}.hue`] = s.grading[`${p}H`]; out[`grading.${name}.sat`] = s.grading[`${p}S`]; }
  out["grading.blend"] = s.grading.blend; out["grading.balance"] = s.grading.balance;
  for (const k of ["highlights", "lights", "darks", "shadows"] as const) out[`curve.parametric.${k}`] = s.curve.parametric[k];
  for (const k of ["rgb", "red", "green", "blue"] as const) out[`curve.${k}`] = JSON.stringify(s.curve[k]);
  for (const k of ["cx", "cy", "w", "h", "angle", "orientation", "flipH", "flipV"] as const) out[`crop.${k}`] = s.crop[k];
  out["crop.aspect"] = s.aspect;
  out.masks = JSON.stringify(s.masks ?? []);
  out["look.style"] = s.lookStyle ?? lookAsShotStyle.value;
  for (const k of LOOK_TWEAK_ORDER) out[`look.${k}`] = (s.look ?? lookAsShot.value)?.[k];
  out["look.advancedColour"] = s.sonyAdvancedColour ?? false;
  out["look.cameraMatch"] = s.sonyCameraMatch ?? false;
  out["dro.strength"] = s.dro ?? droAsShot.value; out["dro.level"] = s.droLevel ?? DRO_AUTO;
  for (const k of Object.keys(defaultDenoise()) as (keyof typeof denoise)[]) out[`denoise.${k}`] = s.denoise?.[k];
  return out;
}
function diffEdit(before: Snapshot, after: Snapshot): Record<string, { from: unknown; to: unknown }> {
  const a = flattenEdit(before), b = flattenEdit(after);
  const changed: Record<string, { from: unknown; to: unknown }> = {};
  for (const k of Object.keys(b)) if (a[k] !== b[k]) changed[k] = { from: a[k], to: b[k] };
  return changed;
}

// What the photo looked like when the current turn started, and just before
// the last set_edit: the two "before"s compare can be asked for. Neither is
// reactive state or history — they are the model's memory, not the user's.
let turnBaseline: Snapshot | null = null;
let editBaseline: Snapshot | null = null;

async function measureFrame(): Promise<unknown> {
  const renderer = renderFrame(null, 256);
  const { w, h, data } = renderer.readFrame();
  const m = measureHistogram(await renderer.readHistogram());
  const hint = measureHint(m);
  return { ...m, ...measurePixels(data, w, h), ...(hint ? { hint } : {}) };
}

const num = (min: number, max: number, description?: string) => ({ type: "number", minimum: min, maximum: max, ...(description ? { description } : {}) });
const HSL_BAND_SCHEMA = { type: "object", properties: { hue: num(-100, 100), sat: num(-100, 100), lum: num(-100, 100) } };
const GRADING_BAND_SCHEMA = { type: "object", properties: { hue: num(-180, 180, "sRGB hue: 0 red, 30 orange, 60 yellow, 120 green, 180 cyan/teal, -120 blue, -60 magenta"), sat: num(0, 100, "strength; 0 = no tint") } };
const POINTS_SCHEMA = { type: "array", description: "Point curve, 2+ points with x,y in 0..1 sorted by x (identity is [{x:0,y:0},{x:1,y:1}])", items: { type: "object", properties: { x: num(0, 1), y: num(0, 1) }, required: ["x", "y"] } };
const SET_EDIT_SCHEMA = {
  type: "object",
  properties: {
    reset: { type: "boolean", description: "Reset every adjustment and the crop to defaults before applying the rest" },
    sliders: {
      type: "object", description: "Every slider, absolute values (Lightroom semantics). Omitted keys keep their value.",
      properties: Object.fromEntries(SLIDER_SPECS.map(sp => [sp.key, num(sp.min, sp.max)])),
    },
    lensBlurFocus: {
      type: "object", description: "Where lens blur focuses, in fractions of the oriented, uncropped image (x right, y down); null-like values are ignored.",
      properties: { x: num(0, 1), y: num(0, 1) },
    },
    hsl: { type: "object", description: "Per-colour HSL, each band {hue,sat,lum} in -100..100", properties: Object.fromEntries(HSL_RANGES.map(r => [r.key, HSL_BAND_SCHEMA])) },
    grading: { type: "object", description: "Colour grading (split toning): a tint per tonal band. blend 0..100 = how far the shadow and highlight tints overlap into the midtones; balance -100..100 shifts the crossover towards shadows (negative) or highlights (positive).", properties: { shadows: GRADING_BAND_SCHEMA, midtones: GRADING_BAND_SCHEMA, highlights: GRADING_BAND_SCHEMA, blend: num(0, 100), balance: num(-100, 100) } },
    curve: {
      type: "object", description: "Tone curve: parametric regions and/or point curves (each channel replaces the whole curve)",
      properties: {
        parametric: { type: "object", properties: { highlights: num(-100, 100), lights: num(-100, 100), darks: num(-100, 100), shadows: num(-100, 100) } },
        rgb: POINTS_SCHEMA, red: POINTS_SCHEMA, green: POINTS_SCHEMA, blue: POINTS_SCHEMA,
      },
    },
    crop: {
      type: "object", description: "Crop & straighten. cx,cy,w,h are fractions of the oriented image (full frame: 0.5,0.5,1,1).",
      properties: {
        cx: num(0, 1), cy: num(0, 1), w: num(0.05, 1), h: num(0.05, 1),
        angle: num(-45, 45, "straighten angle in degrees"),
        orientation: { type: "integer", enum: [0, 90, 180, 270], description: "90° rotation of the whole image" },
        flipH: { type: "boolean" }, flipV: { type: "boolean" },
        aspect: { type: "string", description: "'free', 'orig', or 'W:H' such as '3:2', '16:9', '1:1' — fits the largest box of that ratio at cx,cy" },
      },
    },
    masks: {
      type: "array", description: "Local adjustments. Replaces the whole mask list (send [] to clear). Start each mask from a preset, or give components; adjust values are deltas added to the global sliders where the mask applies.",
      items: { type: "object", properties: {
        preset: { type: "string", enum: Object.keys(MASK_PRESETS).filter(k => k !== "brush") },
        name: { type: "string" }, invert: { type: "boolean" },
        components: {
          type: "array", description: "Combined in order: luminance/color select by tone or hue, depth by distance (lo/hi on 0 = nearest .. 100 = farthest), ai by what the region is (kind), linear/radial by position in fractions of the oriented image.",
          items: { type: "object", properties: {
            type: { type: "string", enum: MASK_TYPES.filter(k => k !== "brush") }, op: { type: "string", enum: MASK_OPS }, invert: { type: "boolean" },
            kind: { type: "string", enum: AI_KINDS, description: "ai components: what to select" },
            lo: num(0, 100), hi: num(0, 100), feather: num(0, 100),
            hue: num(-180, 180, "degrees"), hueWidth: num(5, 120, "degrees"),
            x0: num(0, 1), y0: num(0, 1), x1: num(0, 1), y1: num(0, 1),
            cx: num(0, 1), cy: num(0, 1), rx: num(0.02, 1), ry: num(0.02, 1), angle: num(-180, 180),
          } },
        },
        adjust: { type: "object", properties: Object.fromEntries(MASK_ADJUST_SLIDERS.map(sp => [sp.key, num(sp.min, sp.max)])) },
      } },
    },
    look: {
      type: "object", description: "Sony Creative Look — only when get_edit reports a look (Sony engine). style: a code from look.available. tweaks: absolute values on the camera's panel scale, ranges in get_edit. dro: Sony's Dynamic Range Optimizer (local shadow lift / highlight hold, like the camera JPEG).",
      properties: {
        style: { type: "string" },
        tweaks: { type: "object", properties: Object.fromEntries(LOOK_TWEAK_ORDER.map(k => [k, num(-100, 100)])) },
        advancedColour: { type: "boolean", description: "Imaging Edge's advanced colour reproduction (3-D LUT), how the camera renders its own JPEG" },
        cameraMatch: { type: "boolean", description: "Camera match: a small per-body, per-look correction (a few L*, a few % chroma, a degree or two of hue) fitted against the camera's own JPEGs. Only when get_edit reports it non-null" },
        dro: { type: "object", properties: {
          mode: { type: "string", enum: ["off", "auto", "level"], description: "auto = the curve the camera chose; level = one of the built-in curves" },
          level: { type: "integer", minimum: 1, description: "1..levels, with mode 'level'" },
          strength: num(0, DRO_MAX, "auto only; 1 = what the camera applied"),
        } },
      },
    },
    denoise: {
      type: "object", description: "RAW-domain noise reduction (re-decodes, ~seconds). amount/edge/chroma are on Imaging Edge's 0..100 scale, 50 = as the camera (amounts above 50 render as 50 on a Sony RAW). auto only matters on non-Sony RAWs, where it makes the strength follow the shot's ISO instead of amount.",
      properties: { enabled: { type: "boolean" }, auto: { type: "boolean" }, amount: num(0, 100), edge: num(0, 100), chroma: num(0, 100) },
    },
  },
};

function aspectKeyFor(spec: string): string | null {
  if (spec === "free" || spec === "orig") return spec;
  const m = /^(\d+(?:\.\d+)?):(\d+(?:\.\d+)?)$/.exec(spec.trim());
  if (!m) return null;
  const [w, h] = [Number(m[1]), Number(m[2])];
  const preset = ASPECT_PRESETS.find(a => a.ratio && Math.abs(a.ratio - Math.max(w, h) / Math.min(w, h)) < 1e-6);
  return preset ? preset.key : `custom:${w}:${h}`;
}

const numOr = (v: unknown, fallback: number, min: number, max: number) => typeof v === "number" && Number.isFinite(v) ? clamp(v, min, max) : fallback;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function applyAssistantEdit(args: any): Promise<void> {
  requireImage();
  if (args.reset) { resetRecipe(); resetCrop(); resetLook(); }
  for (const sp of SLIDER_SPECS) recipe[sp.key] = numOr(args.sliders?.[sp.key], recipe[sp.key], sp.min, sp.max);
  if (typeof args.lensBlurFocus?.x === "number" && typeof args.lensBlurFocus?.y === "number") {
    // Oriented image-norm -> the source-norm point the picker would store.
    const [u, v] = viewToStroke(clamp(args.lensBlurFocus.x, 0, 1), clamp(args.lensBlurFocus.y, 0, 1), crop, viewLens());
    recipe.blurFocusX = clamp(u, 0, 1); recipe.blurFocusY = clamp(v, 0, 1);
  }
  HSL_RANGES.forEach((r, i) => {
    const band = args.hsl?.[r.key];
    if (!band) return;
    hslHue[i] = numOr(band.hue, hslHue[i], -100, 100);
    hslSat[i] = numOr(band.sat, hslSat[i], -100, 100);
    hslLum[i] = numOr(band.lum, hslLum[i], -100, 100);
  });
  if (args.grading) {
    for (const [name, p] of Object.entries(GRADING_NAMES)) {
      grading[`${p}H`] = numOr(args.grading[name]?.hue, grading[`${p}H`], -180, 180);
      grading[`${p}S`] = numOr(args.grading[name]?.sat, grading[`${p}S`], 0, 100);
    }
    grading.blend = numOr(args.grading.blend, grading.blend, 0, 100);
    grading.balance = numOr(args.grading.balance, grading.balance, -100, 100);
  }
  if (args.curve) {
    const cur = toneCurve.value;
    const pm = args.curve.parametric ?? {};
    toneCurve.value = normalizeToneCurve({
      rgb: args.curve.rgb ?? cur.rgb, red: args.curve.red ?? cur.red, green: args.curve.green ?? cur.green, blue: args.curve.blue ?? cur.blue,
      parametric: {
        ...cur.parametric,
        highlights: numOr(pm.highlights, cur.parametric.highlights, -100, 100),
        lights: numOr(pm.lights, cur.parametric.lights, -100, 100),
        darks: numOr(pm.darks, cur.parametric.darks, -100, 100),
        shadows: numOr(pm.shadows, cur.parametric.shadows, -100, 100),
      },
    });
    applyCurveLUT();
  }
  if (args.crop) {
    const c = args.crop;
    const next: CropState = {
      ...crop,
      cx: numOr(c.cx, crop.cx, 0, 1), cy: numOr(c.cy, crop.cy, 0, 1),
      w: numOr(c.w, crop.w, 0.05, 1), h: numOr(c.h, crop.h, 0.05, 1),
      angle: numOr(c.angle, crop.angle, -45, 45),
      orientation: [0, 90, 180, 270].includes(c.orientation) ? c.orientation : crop.orientation,
      flipH: typeof c.flipH === "boolean" ? c.flipH : crop.flipH,
      flipV: typeof c.flipV === "boolean" ? c.flipV : crop.flipV,
    };
    Object.assign(crop, constrainCrop(next, srcW.value, srcH.value));
    const key = typeof c.aspect === "string" ? aspectKeyFor(c.aspect) : null;
    if (key) selectAspect(key);
  }
  if (Array.isArray(args.masks)) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    masks.splice(0, masks.length, ...args.masks.slice(0, MASK_GROUPS).flatMap((m: any) => {
      const id = newMaskId();
      const g: MaskGroup = m?.preset in MASK_PRESETS
        ? presetGroup(m.preset as MaskPresetName, id)
        : { id, enabled: true, invert: false, components: [], adjust: defaultAdjust() };
      if (typeof m?.name === "string") g.name = m.name;
      if (typeof m?.invert === "boolean") g.invert = m.invert;
      if (Array.isArray(m?.components)) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        g.components = m.components.slice(0, MASK_COMPS).flatMap((c: any): MaskComponent[] => {
          // A brush needs strokes the assistant cannot paint.
          if (!MASK_TYPES.includes(c?.type) || c.type === "brush") return [];
          const d = defaultComponent(c.type as MaskType);
          d.op = MASK_OPS.includes(c.op) ? c.op : d.op;
          d.invert = typeof c.invert === "boolean" ? c.invert : d.invert;
          if (d.type === "luminance" || d.type === "depth") {
            d.lo = numOr(c.lo, d.lo, 0, 100); d.hi = numOr(c.hi, d.hi, 0, 100);
            d.featherLo = d.featherHi = numOr(c.feather, d.featherLo, 0, 100);
          } else if (d.type === "color") {
            d.hue = rad(numOr(c.hue, deg(d.hue), -180, 180)); d.hueWidth = rad(numOr(c.hueWidth, deg(d.hueWidth), 5, 120));
          } else if (d.type === "linear") {
            d.x0 = numOr(c.x0, d.x0, 0, 1); d.y0 = numOr(c.y0, d.y0, 0, 1); d.x1 = numOr(c.x1, d.x1, 0, 1); d.y1 = numOr(c.y1, d.y1, 0, 1);
          } else if (d.type === "ai") {
            d.kind = AI_KINDS.includes(c.kind) ? c.kind : d.kind;
          } else if (d.type === "radial") {
            d.cx = numOr(c.cx, d.cx, 0, 1); d.cy = numOr(c.cy, d.cy, 0, 1); d.rx = numOr(c.rx, d.rx, 0.02, 1); d.ry = numOr(c.ry, d.ry, 0.02, 1);
            d.angle = numOr(c.angle, d.angle, -180, 180); d.feather = numOr(c.feather, d.feather * 100, 0, 100) / 100;
          }
          return [d];
        });
      }
      for (const sp of MASK_ADJUST_SLIDERS) g.adjust[sp.key] = numOr(m?.adjust?.[sp.key], g.adjust[sp.key], sp.min, sp.max);
      return g.components.length ? [g] : [];
    }));
    selectedMask.value = masks[masks.length - 1]?.id ?? null;
  }
  if (args.look && lookAsShot.value) {
    const L = args.look;
    if (typeof L.style === "string" && availableLooks.value.includes(L.style)) setLookStyle(L.style);
    if (L.tweaks) {
      const next = { ...effectiveLook.value };
      for (const sp of lookSliders.value) next[sp.key] = numOr(L.tweaks[sp.key], next[sp.key], sp.min, sp.max);
      look.value = next;
    }
    if (typeof L.advancedColour === "boolean") sonyAdvancedColour.value = L.advancedColour;
    if (typeof L.cameraMatch === "boolean" && hasSonyCameraMatch.value) sonyCameraMatch.value = L.cameraMatch;
    if (L.dro && droAvailable.value) {
      if (["off", "auto", "level"].includes(L.dro.mode)) {
        setDroMode(L.dro.mode, droLevels.value[Math.trunc(numOr(L.dro.level, 1, 1, droLevels.value.length)) - 1]);
      }
      if (typeof L.dro.strength === "number") setDro(L.dro.strength);
    }
  }
  if (args.denoise && isRawSource.value) {
    const d = args.denoise;
    if (typeof d.enabled === "boolean") denoise.enabled = d.enabled;
    if (typeof d.auto === "boolean") denoise.auto = d.auto;
    denoise.amount = numOr(d.amount, denoise.amount, 0, 100);
    denoise.edge = numOr(d.edge, denoise.edge, 0, 100);
    denoise.chroma = numOr(d.chroma, denoise.chroma, 0, 100);
  }
  // The watchers above have now issued whatever reload the edit needs; the
  // model's next compare must see it landed. The denoise debounce is for a
  // dragged slider, not for one call — skip it.
  await nextTick();
  if (denoiseReloadTimer) { clearTimeout(denoiseReloadTimer); void reloadDenoise(); }
  await Promise.all([lookReload, denoiseReload]);
}

const textContent = (v: unknown): ToolContent[] => [{ type: "text", text: JSON.stringify(v) }];
const imageContent = async (blob: Promise<Blob>): Promise<ToolContent[]> => [{ type: "image", data: await blobToBase64(await blob), mimeType: "image/jpeg" }];
const assistantTools: Record<string, AssistantTool> = {
  view_image: {
    role: "inspect",
    description: "Render the photo with the current edit and return it as a JPEG (long edge ~768px). This is for the first look; prefer compare after set_edit.",
    parameters: { type: "object", properties: {} },
    run: () => imageContent(captureFrame(null, 768)),
  },
  compare: {
    role: "inspect",
    description: "Before/after side by side (two ~512px halves, labelled). Call it after set_edit to judge the change: too much, too little, anything clipped? `against` picks the before: the edit when this turn started (default) or the edit just before your last set_edit.",
    parameters: { type: "object", properties: { against: { type: "string", enum: ["turn_start", "previous_edit"] } } },
    run: (args) => {
      const before = (args?.against === "previous_edit" ? editBaseline : turnBaseline) ?? captureSnapshot();
      return imageContent(compareFrames(before));
    },
  },
  // No role: seeing the matte is not seeing the result, so the API's
  // "you changed the edit but did not look" nudge still counts a compare owed.
  view_mask: {
    description: "The photo next to one mask's matte (white = selected in full, black = untouched). Call it after adding or changing a mask to check the selection covers what you meant — the sky and not the white wall, the face and not the hand — before judging its adjustments with compare. `index` is the mask's position in get_edit's list (0-based; default: the last one).",
    parameters: { type: "object", properties: { index: { type: "integer", minimum: 0 } } },
    run: (args) => {
      requireImage();
      if (!masks.length) throw new Error("no masks");
      const g = masks[Math.trunc(numOr(args?.index, masks.length - 1, 0, masks.length - 1))];
      return imageContent(matteFrames(g.id));
    },
  },
  measure: {
    role: "inspect",
    description: "Numbers about the current render, display-encoded 0..255: luminance percentiles and mean, clipped shadow/highlight percentages with the railed channels, mean luminance of the top/middle/bottom thirds, mean chroma, and a hint when something trips a threshold.",
    parameters: { type: "object", properties: {} },
    run: async () => textContent(await measureFrame()),
  },
  get_edit: {
    description: "The current edit: every slider with its range and default, HSL, colour grading, tone curve, crop, masks, the Sony Creative Look / DRO when the shot renders through the Sony engine, denoise, and the image dimensions.",
    parameters: { type: "object", properties: {} },
    run: () => { requireImage(); return textContent(describeEdit()); },
  },
  set_edit: {
    role: "mutate",
    description: "Apply adjustments. Every field is optional and absolute; omitted fields are left as they are. Returns only what changed, as {field: {from, to}}.",
    parameters: SET_EDIT_SCHEMA,
    run: async (args) => {
      requireImage();
      // One history step per call, tagged as the assistant's: flush whatever the
      // user was mid-way through first, then commit this edit on its own once
      // the watchers have seen it.
      flushPendingHistory();
      editBaseline = captureSnapshot();
      await applyAssistantEdit(args);
      await nextTick();
      flushPendingHistory(t("history.assistant"));
      const changed = diffEdit(editBaseline, captureSnapshot());
      return textContent(Object.keys(changed).length ? { changed } : { changed: {}, note: "nothing changed" });
    },
  },
};

function assistantSystemPrompt(): string {
  return [
    "You are the editing assistant inside LLR, a RAW photo editor with Lightroom-style controls. The user has a photo open; you edit it by calling tools. Every change shows up live and can be undone, so act rather than ask when the request is clear enough to try.",
    "",
    "How to work: see the photo before you change it (view_image, and get_edit for the current values), and see the result before you finish (compare; measure when clipping or levels matter). An edit you have not looked at is not done. Group related controls into one set_edit and judge them together; take another round only when compare shows the intent missed — too little, too much, or a side effect. A small, precise ask (\"a bit warmer\") usually needs one round; a whole look may need a few.",
    "",
    "Strength (Lightroom semantics): exposure ±0.3 EV is a visible step, ±1 EV dramatic. On -100..100 sliders ±10 is subtle, ±30 clear, ±60 strong, beyond that an effect. Temperature ±300 K subtle, ±1000 K obviously warm or cool; tint negative = green, positive = magenta. Start subtle-to-visible and go further only when compare shows too little.",
    "",
    "Looks and styles live in colour grading, the tone curve and HSL, not in Basic. Cinematic: teal (hue −160..180) shadows with orange (25..35) highlights; film: warm shadows and cool highlights; faded: lift the curve's black point; punch: an S curve. Grading saturation 10–15 is subtle, 25–35 a clear look, above 50 a colour cast. Basic then sets the brightness and contrast the look sits on. Vignette (vig*) and grain (grain*) are finishing touches: vignette −15..−35 and grain 15–35 read as natural, more reads as an effect.",
    "",
    "Global first, masks last: get the whole picture right before touching a region — exposure, white balance, tone, then the look. Most photos need no mask at all. Reach for one only when a specific region still reads wrong after the global balance and fixing it globally would visibly harm the rest (a sky still blown out, a face still in shadow, a distracting bright edge). Keep it to one or two masks per photo, with modest adjustments (exposure ±0.3–0.7 EV, other sliders within ±30) so the region still belongs to the frame. Pick the selection by what the region is: the AI presets for the main subject, the sky (grey skies included) and people; the depth presets (foreground, background) or a depth range for near versus far; luminance or colour ranges for tones and hues; linear and radial gradients for position. Components combine (e.g. people ∩ highlights = lit faces). Adjust values are deltas on top of the global sliders. view_mask a new selection before trusting it — AI and depth mattes need a moment to compute the first time and are empty until then.",
    "",
    "Depth effects use the photo's estimated geometry: blurAmount is lens blur (the focus point defaults to the frame centre — set lensBlurFocus on the subject, and blurRange for how deep the sharp zone is); fogAmount adds haze with distance, negative clears distant haze. Detail: sharpAmount 40–70 is normal output sharpening (sharpMasking 50+ keeps skin and sky smooth); defringe only when purple or green edges are actually visible.",
    "",
    "Crops: think about composition (subject placement, horizon, edge distractions) and straighten with angle. Keep the original aspect ratio ('orig') unless the user asks otherwise.",
    "",
    "look (Sony shots only): the camera's own rendering. Pick a style for a wholesale change of character (VV vivid, PT portrait skin, FL film) and prefer its tweaks over Basic when the user asks for the camera's look. DRO already lifts shadows on many frames; check it before adding shadows or exposure.",
    "",
    `Answer briefly in the user's language (UI locale: ${locale.value}): what you changed and why, not every value.`,
  ].join("\n");
}

const {
  entries: chatEntries, busy: chatBusy, models: chatModels, selected: chatModel,
  catalog: chatCatalog, providers: chatProviders,
  send: sendChat, abort: abortChat, reset: resetChat,
} = useAssistant({
  tools: () => assistantTools, systemPrompt: assistantSystemPrompt, scope: () => activeId.value,
  onTurnStart: () => { turnBaseline = editBaseline = activeSource.value && hasLinearData ? captureSnapshot() : null; },
});
const chatModelOptions = computed(() => chatModels.value.map(m => ({
  value: modelKey(m), label: m.id, disabled: chatProviders.value !== null && !chatProviders.value.includes(m.provider),
})));
// The thinking level rides on the selected model's entry, so it persists with
// the list and each model remembers its own.
const chatThinking = computed({
  get: () => chatModels.value.find(m => modelKey(m) === chatModel.value)?.thinking ?? "off",
  set: thinking => { chatModels.value = chatModels.value.map(m => modelKey(m) === chatModel.value ? { ...m, thinking } : m); },
});
const chatThinkingOptions = computed(() => THINKING_LEVELS.map(v => ({ value: v, label: t(`chat.thinking.${v}`) })));
const CHAT_CHIPS = ["chat.chip.1", "chat.chip.2", "chat.chip.3"] as const;
const modelSettingsOpen = ref(false);
const chatDraft = ref("");
const chatLogRef = ref<HTMLElement | null>(null);
function submitChat(): void {
  const text = chatDraft.value;
  chatDraft.value = "";
  void sendChat(text);
}
// Enter sends, Shift+Enter breaks a line — except the Enter that commits an
// IME composition, which must not send the half-typed text. `keyCode 229` is
// the legacy IME marker some browsers set without isComposing.
function onChatEnter(e: KeyboardEvent): void {
  if (e.shiftKey || e.isComposing || e.keyCode === 229) return;
  e.preventDefault();
  submitChat();
}
function usageLine(u: TurnUsage): string {
  const k = (n: number) => n >= 1000 ? `${(n / 1000).toFixed(1)}k` : String(n);
  const cost = u.cost >= 0.001 ? `$${u.cost.toFixed(3)}` : u.cost > 0 ? "<$0.001" : "$0";
  return t("chat.usage", { input: k(u.input), output: k(u.output), cached: u.cacheRead ? t("chat.usage.cached", { n: k(u.cacheRead) }) : "", cost });
}
// The thinking row: live until the block closes, then labelled with what it took.
type Thinking = { thinking: string; thinkingMs?: number; streaming: boolean };
const thinkingActive = (e: Thinking): boolean => e.streaming && e.thinkingMs === undefined;
function thinkingLabel(e: Thinking): string {
  if (thinkingActive(e)) return t("chat.reasoning.active");
  const ms = e.thinkingMs ?? 0;
  return t("chat.reasoning.done", { s: ms < 60_000 ? `${Math.max(1, Math.round(ms / 1000))}s` : `${Math.floor(ms / 60_000)}m${Math.round((ms % 60_000) / 1000)}s` });
}
// What stands in for the reasoning while folded: where it has got to while it
// streams, what it set out to do once it is done.
function thinkingLine(e: Thinking): string {
  const lines = e.thinking.split("\n").map(l => l.trim()).filter(Boolean);
  return (thinkingActive(e) ? lines.at(-1) : lines[0]) ?? "";
}
// Keep the newest message in view as the reply streams in.
watch(chatEntries, () => { void nextTick(() => { const el = chatLogRef.value; if (el) el.scrollTop = el.scrollHeight; }); }, { deep: true });
// The icon says what kind of thing the call is before the name is read; the
// state's icon replaces it when the state is the thing worth noticing.
const TOOL_ICONS: Record<string, ChatIconName> = { view_image: "eye", get_edit: "list", set_edit: "adjust", compare: "columns", measure: "chart" };
function toolIcon(e: { name: string; done: boolean; error?: string }): ChatIconName {
  return !e.done ? "loader" : e.error ? "alert" : TOOL_ICONS[e.name] ?? "tool";
}
const toolMeta = (e: { done: boolean; error?: string }): string => !e.done ? t("chat.tool.running") : e.error ?? "";
function toolSummary(entry: { name: string; args: unknown }): string {
  if (entry.name !== "set_edit" || !entry.args || typeof entry.args !== "object") return "";
  return Object.keys(entry.args as object).join(", ");
}
// What the model saw or did, from the tool's own result: the picture it was
// sent, the fields set_edit changed, the numbers measure reported.
function toolDetail(entry: { name: string; result?: ToolContent[] }): { image?: string; lines?: string[]; rows?: [string, string][] } | null {
  const first = entry.result?.[0];
  if (!first) return null;
  if (first.type === "image") return { image: `data:${first.mimeType};base64,${first.data}` };
  let parsed: Record<string, unknown>;
  try { parsed = JSON.parse(first.text); } catch { return null; }
  // Signed like the slider readouts (+0.4), except crop fractions and
  // Kelvin-scale values, where a plus sign would only read as noise.
  const fmt = (v: unknown, key = "crop."): string =>
    v == null ? "—"
    : typeof v === "number" ? (v > 0 && Math.abs(v) <= 100 && !key.startsWith("crop.") ? "+" : "") + String(Math.round(v * 1000) / 1000)
    : typeof v === "string" && v.length > 60 ? `${v.slice(0, 57)}…` : String(v);
  if (entry.name === "set_edit") {
    const changed = Object.entries((parsed.changed ?? {}) as Record<string, { from: unknown; to: unknown }>);
    return { lines: changed.length ? changed.map(([k, d]) => `${k} ${fmt(d.from, k)} → ${fmt(d.to, k)}`) : [String(parsed.note ?? "")] };
  }
  if (entry.name === "measure") {
    const rows: [string, string][] = [];
    const walk = (v: unknown, prefix: string) => {
      if (v && typeof v === "object") for (const [k, x] of Object.entries(v)) walk(x, prefix ? `${prefix}.${k}` : k);
      else rows.push([prefix, fmt(v)]);
    };
    walk(parsed, "");
    return { rows };
  }
  return null;
}

// ── Recipes ──
//
// Copy / paste and a saved list of the transferable part of an edit
// (rendering/recipes.ts says what transfers). Copy also puts the JSON on the
// system clipboard, so a recipe can cross tabs or be pasted into a note.

const savedRecipes = ref<SavedRecipe[]>(loadSavedRecipes());
const recipeName = ref("");
const recipeClipboard = shallowRef<RecipeData | null>(null);
// Which sections a copy takes: the dialog's ticks, remembered per browser,
// and what the quick copy (Ctrl+Shift+C) uses without asking.
const copySections = ref<RecipeSection[]>(loadCopySections());
// The Copy Settings dialog: open, and which photo it copies from (null = the open one).
const copyDialog = ref<{ from: string | null } | null>(null);
const copyNotice = ref<string | null>(null);
let copyNoticeTimer = 0;
function flashCopyNotice(msg: string): void {
  copyNotice.value = msg;
  window.clearTimeout(copyNoticeTimer);
  copyNoticeTimer = window.setTimeout(() => { copyNotice.value = null; }, 2600);
}

async function snapshotFor(id: string | null): Promise<Snapshot | null> {
  if (!id || id === activeSource.value?.id) return activeSource.value ? captureSnapshot() : null;
  const photo = photoById(id);
  return (await snapshotOf(id)) ?? (photo ? defaultSnapshot(photo.name) : null);
}

async function copyRecipe(from: string | null = null, sections: readonly RecipeSection[] = copySections.value): Promise<void> {
  const s = await snapshotFor(from);
  if (!s) return;
  recipeClipboard.value = extractRecipe(s, sections);
  void navigator.clipboard?.writeText(serializeRecipe(recipeClipboard.value)).catch(() => {});
  flashCopyNotice(t("recipe.copied", { n: sections.length }));
}

function openCopyDialog(from: string | null = null): void {
  copyDialog.value = { from };
}
async function confirmCopy(): Promise<void> {
  const from = copyDialog.value?.from ?? null;
  storeCopySections(copySections.value);
  copyDialog.value = null;
  await copyRecipe(from);
}
function toggleCopySection(s: RecipeSection): void {
  const on = new Set(copySections.value);
  if (on.has(s)) on.delete(s); else on.add(s);
  copySections.value = RECIPE_SECTIONS.filter(x => on.has(x));
}

// The newer of the in-app copy and the system clipboard: a recipe copied in
// another tab arrives through the latter.
async function clipboardRecipe(): Promise<RecipeData | null> {
  const text = await navigator.clipboard?.readText().catch(() => "") ?? "";
  return parseRecipe(text) ?? recipeClipboard.value;
}

async function pasteRecipe(): Promise<void> {
  if (!activeSource.value) return;
  const r = await clipboardRecipe();
  if (r) await applyRecipeStep(r, t("recipe.pasted"));
}

/**
 * Paste onto photos chosen in the grid. The open photo takes it as a live
 * history step; the rest have their stored edits rewritten, then get their
 * edited previews re-rendered in the background, one by one.
 */
async function pasteToPhotos(ids: readonly string[]): Promise<void> {
  const r = await clipboardRecipe();
  if (!r || !ids.length) return;
  if (activeSource.value && ids.includes(activeSource.value.id)) await applyRecipeStep(r, t("recipe.pasted"));
  const changed = await updateEdits(ids, p => defaultSnapshot(p.name), cur => applyRecipe(cur, r));
  flashCopyNotice(t("recipe.pastedTo", { n: changed.length + (activeSource.value && ids.includes(activeSource.value.id) ? 1 : 0) }));
  queuePreviewRefresh(changed);
}

// ── Background preview refresh ──
//
// A photo whose edit changed without being opened still shows its old edited
// preview; this re-renders it the way an export would, at preview size and
// from a half-size decode (kept out of the worker's caches), one at a time.
const previewQueue: string[] = [];
const previewProgress = ref<{ done: number; total: number } | null>(null);
let previewRunning = false;
function queuePreviewRefresh(ids: readonly string[]): void {
  for (const id of ids) if (!previewQueue.includes(id)) previewQueue.push(id);
  previewProgress.value = { done: previewProgress.value?.done ?? 0, total: (previewProgress.value?.done ?? 0) + previewQueue.length };
  if (!previewRunning) void runPreviewQueue();
}
async function runPreviewQueue(): Promise<void> {
  previewRunning = true;
  try {
    while (previewQueue.length) {
      const id = previewQueue.shift()!;
      try {
        const s = await snapshotFor(id);
        if (s) await savePreview(id, await renderSnapshot(id, s, PREVIEW_EDGE));
      } catch (err) {
        console.warn(`[preview] ${id} failed:`, err);
      }
      if (previewProgress.value) previewProgress.value = { ...previewProgress.value, done: previewProgress.value.done + 1 };
    }
  } finally {
    previewRunning = false;
    previewProgress.value = null;
  }
}

/** Render a photo's snapshot off-screen at `maxEdge` (another photo than the open one). */
async function renderSnapshot(id: string, settings: Snapshot, maxEdge: number): Promise<Blob> {
  const off = new Set(settings.bypass ?? []);
  const body = {
    sourceId: id, halfSize: true, maxSize: 2048, purpose: "export",
    profileId: settings.profile ?? "standard", dcpCode: settings.dcp, denoise: denoisePayload(settings.denoise),
    look: off.has("look") ? undefined : settings.look ?? undefined,
    style: off.has("look") ? undefined : settings.lookStyle ?? undefined,
    dro: off.has("look") ? undefined : settings.dro ?? undefined, erase: eraseWire(settings.erase ?? []),
  };
  const masksOn = off.has("masks") ? [] : settings.masks ?? [];
  const [geo, ai] = await Promise.all([
    snapshotNeedsGeometry({ ...settings, recipe: effectiveRecipe(settings.recipe, off), masks: masksOn })
      ? fetchRelightGeometry(body).catch(() => null) : null,
    masksOn.some(g => g.enabled && g.components.some(c => c.type === "ai"))
      ? fetchAiMasks(body).catch(() => null) : null,
  ]);
  const plan = buildPlan(id, settings, {
    params: (meta) => buildPipelineParams(settings, {
      matte: null, ctx: { lensCorr: parseLensCorr(meta.colorProfile?.lensCorr), srcW: meta.width, srcH: meta.height },
    }),
    relightGeometry: geo, ai,
  });
  return renderPlan({ ...plan, decode: { halfSize: true, maxSize: 2048 } }, { maxEdge, quality: 0.85 });
}

// One history step, like the assistant's edits.
async function applyRecipeStep(r: RecipeData, label: string): Promise<void> {
  flushPendingHistory();
  setEditState(applyRecipe(captureSnapshot(), r));
  await nextTick();
  flushPendingHistory(label);
}

function saveRecipe(): void {
  if (!activeSource.value) return;
  const name = recipeName.value.trim() || t("recipe.untitled", { n: savedRecipes.value.length + 1 });
  savedRecipes.value = [...savedRecipes.value.filter(r => r.name !== name), { name, data: extractRecipe(captureSnapshot()) }];
  storeSavedRecipes(savedRecipes.value);
  recipeName.value = "";
}

function deleteRecipe(i: number): void {
  savedRecipes.value = savedRecipes.value.filter((_, j) => j !== i);
  storeSavedRecipes(savedRecipes.value);
}

// ── Export ──

function exportFilename(): string {
  const name = activeSource.value?.name ?? "export";
  return `${name.replace(/\.[^.]+$/, "")}.jpg`;
}

// Freeze the edit state into an export plan: the full-res decode takes seconds
// and the filmstrip stays clickable, so everything past an await must read from
// this one snapshot — deriving it all from `settings` also guarantees the
// rendered pixels and the embedded XMP cannot drift apart. The fetch/render/
// embed/download mechanics live in useExport.
function buildExportPlan(): ExportPlan | null {
  if (!currentSourceId || !activeSource.value) return null;
  const settings = captureSnapshot();
  return buildPlan(currentSourceId, settings, {
    params: buildPipelineParams(settings),
    relightGeometry: relightGeometry, ai: aiMasks,
  });
}

// The plan for `settings` on photo `id`: the export's, and the background
// preview's (which brings its own params builder and per-photo analyses).
function buildPlan(
  id: string, settings: Snapshot,
  extra: { params: ExportPlan["params"]; relightGeometry: RelightGeometry | null; ai: { data: Uint8Array; w: number; h: number } | null },
): ExportPlan {
  const off = new Set(settings.bypass ?? []);
  const cropSnap = effectiveCrop(settings.crop, off);
  return {
    sourceId: id,
    filename: id === currentSourceId ? exportFilename() : `${(photoById(id)?.name ?? "export").replace(/\.[^.]+$/, "")}.jpg`,
    settings,
    stripPrivate: viewSettings.exportStripPrivate === 1,
    dcpCode: settings.dcp,
    profileId: settings.profile ?? "standard",
    denoise: denoisePayload(settings.denoise),
    erase: eraseWire(settings.erase ?? []),
    prepare: (r, params) => {
      const p = params as Partial<EditParams> & { maskBrushes?: BrushStroke[][]; maskUsesAi?: boolean };
      const dims = r.auxDims();
      if (dims && p.maskBrushes?.length) {
        r.uploadMaskLayer(AUX_LAYER.brush, { data: rasterBrushes(p.maskBrushes, dims[0], dims[1]), w: dims[0], h: dims[1] });
      }
      if (p.maskUsesAi && extra.ai) r.uploadMaskLayer(AUX_LAYER.ai, extra.ai);
    },
    relightGeometry: snapshotNeedsGeometry({ ...settings, recipe: effectiveRecipe(settings.recipe, off), masks: off.has("masks") ? [] : settings.masks }) ? extra.relightGeometry : null,
    // Absent means as shot, same as everywhere else — the full-res decode then
    // rebuilds the profile the preview was showing (plan.profileLUT).
    look: off.has("look") ? undefined : settings.look ?? undefined,
    lookStyle: off.has("look") ? undefined : settings.lookStyle ?? undefined,
    dro: off.has("look") ? undefined : settings.dro ?? undefined,
    sonyAdvancedColour: settings.sonyAdvancedColour ?? false,
    sonyCameraMatch: settings.sonyCameraMatch ?? false,
    params: extra.params,
    curveLUT: buildToneCurveLUT(off.has("curve") ? defaultToneCurve() : settings.curve,
      currentBasic(effectiveRecipe(settings.recipe, off))),
    profileLUT: (meta) => buildProfileLUT(meta.colorProfile),
    output: (meta) => {
      const [iw, ih] = imageDims(meta.width, meta.height, cropSnap.orientation);
      const rect = cropOutputRect(cropSnap, iw, ih);
      // Snap the output dims to the locked aspect so e.g. a 4:3 crop exports at
      // an exact 4:3 pixel size instead of each axis rounding independently.
      const fraction = resolveAspectFraction(settings.aspect ?? "free", meta.width, meta.height, cropSnap);
      const [width, height] = cropOutputSizeForAspect(cropSnap, meta.width, meta.height, fraction);
      return { width, height, texXform: buildCropTransform(cropSnap, meta.width, meta.height, rect) };
    },
    background: WORKSPACE_BG,
  };
}

const { exporting, exportImage } = useExport({ status, errorMessage, plan: buildExportPlan });

// White balance reads as a colour axis, not an amount: an accent fill growing
// from the left would say "this is set" on a slider sitting at its default.
// Neutral is placed where the default value puts the thumb (6500K -> 45%).
const WB_TRACK: Partial<Record<RecipeKey, string>> = {
  temperature: "linear-gradient(to right, #3f7dff, #f2ead9 45%, #ffb648)",
  tint: "linear-gradient(to right, #4fc26a, #d8d8d8 50%, #d264d8)",
};

// Lightroom-style scroll-to-nudge: scrolling over the *selected* range slider
// steps the value by one `step` (Shift ×10) instead of scrolling the panel.
// Applied via event delegation on the settings rail so every slider — base, HSL,
// grading, denoise, crop angle — gets it without per-input wiring.
//
// Hover alone must not be enough: the rail is a tall scrolling column of sliders,
// so a plain wheel gesture aimed at the panel would land on whatever slider
// happened to be under the pointer and silently edit the photo. Two guards:
// the slider has to hold focus (a click selects it), and ownership is decided
// once per gesture — a scroll that starts on the panel keeps scrolling the panel
// even as sliders slide beneath the pointer.
const WHEEL_GESTURE_GAP_MS = 200;

type WheelAdjustHandlers = {
  onWheel: (e: WheelEvent) => void;
  onPointerDown: (e: PointerEvent) => void;
};

const rangeUnder = (e: Event): HTMLInputElement | null =>
  ((e.target as HTMLElement | null)?.closest?.('input[type="range"]') ?? null) as HTMLInputElement | null;

const vWheelAdjust = {
  mounted(el: HTMLElement) {
    let gestureEnd = 0;
    let owner: HTMLInputElement | null = null;
    // Selecting by click is the other half of the rule, so it lives here too —
    // and a mousedown does not focus a range input in Safari, so the UA cannot
    // be trusted to do it.
    const onPointerDown = (e: PointerEvent) => rangeUnder(e)?.focus();
    const onWheel = (e: WheelEvent) => {
      const input = rangeUnder(e);
      const selected = !!input && !input.disabled && document.activeElement === input;
      if (e.timeStamp > gestureEnd) owner = selected ? input : null;
      gestureEnd = e.timeStamp + WHEEL_GESTURE_GAP_MS;
      if (!owner || owner !== input) return; // let the rail scroll
      e.preventDefault();
      const step = Number(owner.step) || 1;
      const min = Number(owner.min);
      const max = Number(owner.max);
      const cur = Number(owner.value);
      const mult = e.shiftKey ? 10 : 1;
      const dir = e.deltaY < 0 ? 1 : -1; // scroll up → increase
      let next = clamp(cur + dir * step * mult, min, max);
      const decimals = (String(step).split(".")[1] || "").length;
      if (decimals) next = Number(next.toFixed(decimals));
      if (next === cur) return;
      owner.value = String(next);
      owner.dispatchEvent(new Event("input", { bubbles: true }));
      owner.dispatchEvent(new Event("change", { bubbles: true }));
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    el.addEventListener("pointerdown", onPointerDown);
    (el as unknown as { _wheelAdjust?: WheelAdjustHandlers })._wheelAdjust = { onWheel, onPointerDown };
  },
  unmounted(el: HTMLElement) {
    const h = (el as unknown as { _wheelAdjust?: WheelAdjustHandlers })._wheelAdjust;
    if (!h) return;
    el.removeEventListener("wheel", h.onWheel);
    el.removeEventListener("pointerdown", h.onPointerDown);
  },
};
</script>

<template>
  <div class="app" :class="{ 'is-drag': isDragging, 'no-filmstrip': libraryView === 'library' || !folderPhotos.length, 'view-library': libraryView === 'library' }"
    @dragover="onDragOver"
    @dragleave="onDragLeave"
    @drop="onDrop">
    <header class="topbar">
      <div class="brand">
        <span class="brand-mark" aria-hidden="true" />
        <span class="brand-name">LLR</span>
      </div>
      <div class="view-switch" role="tablist">
        <button type="button" class="view-tab" role="tab" :class="{ 'is-on': libraryView === 'library' }"
          :aria-selected="libraryView === 'library'" @click="setView('library')">{{ t('view.library') }}</button>
        <button type="button" class="view-tab" role="tab" :class="{ 'is-on': libraryView === 'develop' }"
          :aria-selected="libraryView === 'develop'" :disabled="!activeSource" @click="setView('develop')">{{ t('view.develop') }}</button>
      </div>
      <div class="topbar-actions">
        <button class="icon-btn" :disabled="!canUndo" @click="undo" :title="t('action.undo')" :aria-label="t('aria.undo')">
          <JIcon :icon="IconUndo" />
        </button>
        <button class="icon-btn" :disabled="!canRedo" @click="redo" :title="t('action.redo')" :aria-label="t('aria.redo')">
          <JIcon :icon="IconRedo" />
        </button>
        <button class="icon-btn" :class="{ 'is-on': showOriginal }" :disabled="!activeSource || cropMode"
          @mousedown="startCompare" @mouseup="endCompare" @mouseleave="endCompare"
          @touchstart.prevent="startCompare" @touchend.prevent="endCompare" @touchcancel="endCompare"
          :title="t('action.compareOriginal')" :aria-label="t('aria.compareOriginal')">
          <JIcon :icon="IconCompare" />
        </button>
        <button class="icon-btn" :disabled="!anyEdited" @click="resetRecipe"
          :title="t('action.resetAll')" :aria-label="t('action.resetAll')">
          <JIcon :icon="IconReset" />
        </button>
        <button class="icon-btn" :class="{ 'is-on': showEmbedded }" :disabled="!activeSource || cropMode || !embeddedSrc"
          @mousedown="startCompareEmbedded" @mouseup="endCompareEmbedded" @mouseleave="endCompareEmbedded"
          @touchstart.prevent="startCompareEmbedded" @touchend.prevent="endCompareEmbedded" @touchcancel="endCompareEmbedded"
          :title="t('action.compareJpeg')" :aria-label="t('aria.compareJpeg')">
          <JIcon :icon="IconCamera" />
        </button>
      </div>
      <div class="meta-summary">
        <template v-if="activeSource">
          <span>{{ activeSource.name }}</span>
          <span class="meta-empty">{{ formatBytes(activeSource.size) }}</span>
        </template>
        <span v-else class="meta-empty">{{ t('meta.noImage') }}</span>
      </div>
      <button class="export-btn" type="button" :disabled="!activeSource || exporting" @click="exportImage">
        <JIcon v-if="!exporting" :icon="IconDownload" />
        <span class="export-spinner" v-else aria-hidden="true" />
        <span>{{ exporting ? t('action.exporting') : t('action.export') }}</span>
      </button>
    </header>

    <FolderTree class="left" ref="folderTree" :folders="folders" :tree="tree" :expanded="expanded" :selected-id="selectedFolderId"
      :busy="!!importProgress"
      @select="selectFolder" @toggle="toggleExpanded"
      @create="(parentId, name) => createFolder(parentId, name)" @rename="renameFolder" @delete="deleteFolder"
      @move-photos="movePhotos" @move-folder="moveFolder"
      @drop-files="onTreeDrop" @import-files="pickFiles" @import-folder="pickFolder">
      <GroupNav v-if="libraryView === 'library' && library.grouped && folderPhotos.length"
        :title="groupOptions.find(o => o.value === groupKey)?.label ?? t('library.group')"
        :sections="library.sections" :current="librarySection" @jump="(i) => photoGrid?.scrollToSection(i)" />
    </FolderTree>

    <main class="center">
      <!-- The grid and the stage swap by v-show, not v-if: the canvas and its
           WebGL context stay alive across the toggle. -->
      <!-- The library's own bar: where the grid is, and how it is ordered. It
           takes the top of the stage, so .photo-grid starts below it. -->
      <div class="library-bar" v-show="libraryView === 'library'">
        <span class="library-path" :title="folderCrumbs.join(' / ')">{{ folderCrumbs.join(' / ') }}</span>
        <span class="library-count">{{ t('library.count', { n: folderPhotos.length }) }}</span>
        <span class="library-gap" />
        <div class="library-tools" role="group" :aria-label="t('view.library')">
          <SelectMenu icon="sort" :model-value="sortKey" :options="sortOptions"
            :title="sortControlLabel" :aria-label="sortControlLabel" @update:model-value="setSort" />
          <button class="icon-btn library-dir" type="button" :title="sortDir === 'asc' ? t('library.asc') : t('library.desc')"
            :aria-label="sortDir === 'asc' ? t('library.asc') : t('library.desc')" @click="toggleSortDir">
            <JIcon :icon="sortDir === 'asc' ? IconSortAscending : IconSortDescending" />
          </button>
          <SelectMenu icon="group" :model-value="groupKey" :options="groupOptions"
            :title="groupControlLabel" :aria-label="groupControlLabel" @update:model-value="setGroup" />
        </div>
      </div>
      <PhotoGrid ref="photoGrid" v-show="libraryView === 'library'" :sections="library.sections" :grouped="library.grouped" :active-id="activeId"
        :selected-ids="selectedIds" :loading="folderLoading" :thumb-src="thumbSrc" :is-invalid="(id) => activeSource?.id === id && !!activeSource.invalid"
        :move-targets="moveTargets" :can-paste="!!recipeClipboard"
        @copy-settings="openCopyDialog" @paste-settings="pasteToPhotos"
        @open="openPhoto" @remove="removePhotosConfirmed" @rename="onGridRename" @move="onGridMove"
        @new-folder="onGridNewFolder" @import-files="pickFiles" @section="(i) => librarySection = i" />
      <div class="viewport" ref="viewportRef" v-show="libraryView === 'develop'"
        @wheel="onWheel"
        @mousedown="startPan"
        @mousemove="doPan"
        @mouseup="stopPan"
        @mouseleave="stopPan"
        @dblclick="onDoubleClick"
        :class="{ 'is-grabbing': isPanning, 'is-grab': spaceHeld && !isPanning }">
        <div class="dropzone" v-show="!activeSource && status !== 'uploading'" @click="pickFiles">
          <div class="dropzone-inner">
            <JIcon class="dropzone-icon" :icon="IconImage" weight="light" />
            <p class="dropzone-title">{{ t('dropzone.title') }}</p>
            <p class="dropzone-sub">{{ t('dropzone.sub') }}</p>
            <p class="dropzone-hint">{{ IMPORT_FORMAT_HINT }}</p>
          </div>
        </div>
        <div v-show="status === 'uploading' && !activeSource" class="preview-loading">
          <span class="spinner spinner-lg" aria-hidden="true" />
          <span>{{ t('status.importing') }}</span>
        </div>
        <!-- Sized and placed by the render window, which zoomed in covers only
             the visible part of the frame; the compare overlays below stay
             full-frame and so keep displayTransform. -->
        <canvas v-show="webglRenderer != null && activeSource && !activeSource.invalid" ref="canvasRef" class="preview" :style="canvasBoxStyle" />
        <!-- The camera JPEG stands in while a *different* source decodes: the
             fit view is a plain contain, so it lands where the frame will. -->
        <img v-if="activeSource && !activeSource.invalid && status === 'rendering' && renderedId !== activeSource.id"
          class="preview-placeholder" draggable="false" :src="activeSource.previewUrl || !activeSource.embeddedUrl ? thumbSrc(activeSource) : resolveUrl(activeSource.embeddedUrl)" :alt="t('aria.preview')" />
        <!-- Camera-JPEG compare: opaque overlay in the canvas's exact box, with
             the full-frame JPEG placed inside it through the edit's own crop /
             straighten / flip so both sides show the same framing. The src stays
             bound while a source is active so the JPEG is already fetched when
             the hold starts. -->
        <div v-show="showEmbedded && webglRenderer != null && activeSource && !activeSource.invalid"
          class="preview compare-embedded"
          :style="{ transform: displayTransform, width: imageW + 'px', height: imageH + 'px' }">
          <img ref="embeddedImgRef" draggable="false" :style="{ transform: embeddedTransform, width: srcW + 'px', height: srcH + 'px' }"
            :src="embeddedSrc || undefined" :alt="t('aria.cameraJpeg')" />
        </div>
        <div v-show="activeSource && (status === 'rendering' || status === 'uploading')"
          class="viewport-busy" aria-live="polite">
          <span class="spinner" aria-hidden="true" />
          <span>{{ status === 'uploading' ? t('status.importing') : t('status.decoding') }}</span>
        </div>
        <!-- Space passes the pointer through to the viewport so drags pan. -->
        <svg v-show="cropMode && webglRenderer != null" ref="cropOverlayRef" class="crop-overlay"
          :class="{ 'is-passthrough': spaceHeld, 'is-straighten': lineTool != null }"
          :style="{ transform: displayTransform, width: imageW + 'px', height: imageH + 'px' }"
          :viewBox="cropViewBox" preserveAspectRatio="none"
          @mousedown="onCropOverlayDown">
          <!-- transparent catchers: anywhere outside the box rotates (the rect
               far exceeds the bbox so it covers the viewport at any zoom/pan;
               overflow is visible and the viewport clips), inside moves. -->
          <rect class="crop-catch crop-catch-rotate" :x="cropOverscan.x" :y="cropOverscan.y"
            :width="cropOverscan.w" :height="cropOverscan.h" />
          <rect class="crop-catch" :x="cropBoxRect.x" :y="cropBoxRect.y" :width="cropBoxRect.w" :height="cropBoxRect.h" />
          <!-- dim outside the crop -->
          <path class="crop-dim" :d="cropDimPath" fill-rule="evenodd" />
          <!-- guide overlay (O cycles, Shift+O mirrors) -->
          <g class="crop-grid" :stroke-width="1 * ofPerScreen">
            <line v-for="(l, i) in cropGuideShapes.lines" :key="'g'+i" :x1="l[0]" :y1="l[1]" :x2="l[2]" :y2="l[3]" />
            <path v-for="(d, i) in cropGuideShapes.paths" :key="'p'+i" :d="d" />
          </g>
          <!-- fine alignment grid while the angle is being dragged -->
          <g class="crop-grid crop-grid-fine" :stroke-width="1 * ofPerScreen">
            <line v-for="(l, i) in rotateGridLines" :key="'r'+i" :x1="l[0]" :y1="l[1]" :x2="l[2]" :y2="l[3]" />
          </g>
          <!-- guided-upright lines, ends draggable -->
          <g class="crop-upright">
            <template v-for="(g, i) in guideLinesView" :key="'ug' + i">
              <line :x1="g.x1" :y1="g.y1" :x2="g.x2" :y2="g.y2" :stroke-width="1.5 * ofPerScreen" />
              <circle :cx="g.x1" :cy="g.y1" :r="5 * ofPerScreen" @mousedown="onGuideHandleDown($event, i, 0)" />
              <circle :cx="g.x2" :cy="g.y2" :r="5 * ofPerScreen" @mousedown="onGuideHandleDown($event, i, 1)" />
            </template>
          </g>
          <!-- the line tools' line -->
          <line v-if="straightenLine.active" class="crop-straighten-line"
            :x1="straightenLine.x1" :y1="straightenLine.y1" :x2="straightenLine.x2" :y2="straightenLine.y2"
            :stroke-width="1.5 * ofPerScreen" />
          <!-- crop edges: two horizontals and two verticals running out past
               the viewport rather than a closed frame; each line is its edge's
               grip, the crossings are the corner grips. -->
          <g :class="{ 'is-dragging': activeCropHandle != null }">
            <template v-for="e in cropGrips.edges" :key="e.key">
              <line class="crop-edge" :class="{ 'is-hot': e.hot }"
                :x1="e.line.x1" :y1="e.line.y1" :x2="e.line.x2" :y2="e.line.y2" :stroke-width="1 * ofPerScreen" />
              <rect class="crop-grip" :class="{ 'is-hot': e.hot }" :x="e.bar.x" :y="e.bar.y" :width="e.bar.w" :height="e.bar.h" />
              <line class="crop-edge-hit" :x1="e.line.x1" :y1="e.line.y1" :x2="e.line.x2" :y2="e.line.y2"
                :stroke-width="12 * ofPerScreen" :style="{ cursor: e.cursor }" @mousedown="onCropHandleDown($event, e.key)" />
            </template>
            <template v-for="c in cropGrips.corners" :key="c.key">
              <rect class="crop-grip crop-grip-corner" :class="{ 'is-hot': c.hot }"
                :x="c.mark.x" :y="c.mark.y" :width="c.mark.w" :height="c.mark.h" :stroke-width="1 * ofPerScreen" />
              <rect class="crop-grip-hit" :x="c.hit.x" :y="c.hit.y" :width="c.hit.w" :height="c.hit.h"
                :style="{ cursor: c.cursor }" @mousedown="onCropHandleDown($event, c.key)" />
            </template>
          </g>
          <text class="crop-size" :x="cropBoxRect.x + cropBoxRect.w - 8 * ofPerScreen"
            :y="cropBoxRect.y + cropBoxRect.h - 8 * ofPerScreen"
            :font-size="11 * ofPerScreen" :stroke-width="3 * ofPerScreen">{{ cropSizeLabel }}</text>
        </svg>
        <div v-if="cropMode && cropReadout" class="crop-readout">{{ cropReadout }}</div>
        <!-- Mask gradient handles (useMaskEditor): same box as the crop
             overlay, viewBox = the committed crop window. Only the handles take
             the pointer; the rest passes through to the viewport. -->
        <svg v-show="editTab === 'masks' && !cropMode && webglRenderer != null && maskShapes.length" ref="maskOverlayRef"
          class="crop-overlay mask-overlay" :class="{ 'is-passthrough': spaceHeld }"
          :style="{ transform: displayTransform, width: imageW + 'px', height: imageH + 'px' }"
          :viewBox="maskViewBox" preserveAspectRatio="none">
          <template v-for="sh in maskShapes" :key="sh.index">
            <g v-if="sh.kind === 'linear'" class="mask-linear">
              <line class="mask-ref" :x1="sh.ref0[0][0]" :y1="sh.ref0[0][1]" :x2="sh.ref0[1][0]" :y2="sh.ref0[1][1]" />
              <line class="mask-ref" :x1="sh.ref1[0][0]" :y1="sh.ref1[0][1]" :x2="sh.ref1[1][0]" :y2="sh.ref1[1][1]" />
              <line class="mask-axis" :x1="sh.p0[0]" :y1="sh.p0[1]" :x2="sh.p1[0]" :y2="sh.p1[1]"
                :stroke-width="10 * ofPerScreen" @mousedown="onLinearLineDown($event, sh.index)" />
              <circle class="mask-handle" :cx="sh.p0[0]" :cy="sh.p0[1]" :r="6 * ofPerScreen" @mousedown="onLinearEndDown($event, sh.index, 0)" />
              <circle class="mask-handle mask-handle-end" :cx="sh.p1[0]" :cy="sh.p1[1]" :r="6 * ofPerScreen" @mousedown="onLinearEndDown($event, sh.index, 1)" />
            </g>
            <g v-else class="mask-radial">
              <polygon class="mask-ref" :points="sh.inner" />
              <polygon class="mask-outline" :points="sh.outline" />
              <rect v-for="(a, k) in sh.axes" :key="k" class="mask-handle mask-handle-sq"
                :x="a[0] - 5 * ofPerScreen" :y="a[1] - 5 * ofPerScreen" :width="10 * ofPerScreen" :height="10 * ofPerScreen"
                @mousedown="onRadialAxisDown($event, sh.index, k as 0 | 1 | 2 | 3)" />
              <circle class="mask-handle mask-handle-rotate" :cx="sh.rotate[0]" :cy="sh.rotate[1]" :r="5 * ofPerScreen"
                @mousedown="onRadialRotateDown($event, sh.index)" />
              <circle class="mask-handle" :cx="sh.centre[0]" :cy="sh.centre[1]" :r="6 * ofPerScreen" @mousedown="onRadialCentreDown($event, sh.index)" />
            </g>
          </template>
        </svg>
        <!-- Erase brush (useEraseEditor): same box as the crop overlay. The
             whole image takes the pointer while the tab is open; Space hands it
             back to the viewport for panning. Stored strokes are drawn only on
             request (or the one hovered in the list) — over a fill they would
             hide exactly what the user wants to look at. -->
        <svg v-show="editTab === 'erase' && !cropMode && webglRenderer != null" ref="eraseOverlayRef"
          class="crop-overlay erase-overlay" :class="{ 'is-passthrough': spaceHeld }"
          :style="{ transform: displayTransform, width: imageW + 'px', height: imageH + 'px' }"
          :viewBox="eraseViewBox" preserveAspectRatio="none"
          @pointerdown="onErasePointerDown" @pointermove="onErasePointerMove" @pointerup="onErasePointerUp"
          @pointerleave="onErasePointerLeave">
          <!-- The draft's lines in one translucent group, so where they
               overlap reads as one region, not as a darker seam. -->
          <!-- Under each: how far the fill may reach once grown and feathered. -->
          <g v-if="eraseDraft" class="erase-reach-layer">
            <path v-for="p in erasePaths.filter(p => p.id === eraseDraft?.id)" :key="p.key" class="erase-stroke is-draft"
              :d="p.d" :stroke-width="p.reachWidth" />
          </g>
          <g v-if="eraseDraft" class="erase-draft-layer">
            <path v-for="p in erasePaths.filter(p => p.id === eraseDraft?.id)" :key="p.key" class="erase-stroke is-draft"
              :d="p.d" :stroke-width="p.width" />
          </g>
          <template v-for="p in erasePaths" :key="p.key">
            <template v-if="p.id !== eraseDraft?.id && (eraseShowStrokes || eraseHover === p.id)">
              <path v-if="eraseHover === p.id" class="erase-stroke is-reach" :d="p.d" :stroke-width="p.reachWidth" />
              <path class="erase-stroke" :class="{ 'is-hover': eraseHover === p.id }" :d="p.d" :stroke-width="p.width" />
            </template>
          </template>
          <path v-if="eraseLivePath" class="erase-stroke is-live" :d="eraseLivePath" :stroke-width="2 * eraseCursorR" />
          <circle v-if="eraseCursor" class="erase-cursor" :cx="eraseCursor.x" :cy="eraseCursor.y" :r="eraseCursorR" />
        </svg>
        <!-- Brush mask painter: the erase brush's editor, painting into the
             active brush component (activeBrush) instead. -->
        <svg v-show="editTab === 'masks' && activeBrushComp && !cropMode && webglRenderer != null" ref="brushOverlayRef"
          class="crop-overlay erase-overlay" :class="{ 'is-passthrough': spaceHeld }"
          :style="{ transform: displayTransform, width: imageW + 'px', height: imageH + 'px' }"
          :viewBox="brushViewBox" preserveAspectRatio="none"
          @pointerdown="onBrushPointerDown" @pointermove="onBrushPointerMove" @pointerup="onBrushPointerUp"
          @pointerleave="onBrushPointerLeave">
          <path v-if="brushLivePath" class="erase-stroke brush-live" :class="{ 'is-erasing': brushErase }" :d="brushLivePath" :stroke-width="2 * brushCursorR" />
          <circle v-if="brushCursor" class="erase-cursor" :cx="brushCursor.x" :cy="brushCursor.y" :r="brushCursorR" />
        </svg>
        <!-- Relight rig (useRelightEditor): a click on the image adds a light
             aimed there, a handle drags it. Same box as the crop overlay. -->
        <svg v-show="editTab === 'relight' && !cropMode && webglRenderer != null" ref="relightOverlayRef"
          class="crop-overlay relight-overlay" :class="{ 'is-passthrough': spaceHeld }"
          :style="{ transform: displayTransform, width: imageW + 'px', height: imageH + 'px' }"
          :viewBox="relightViewBox" preserveAspectRatio="none"
          @pointerdown="onRelightPointerDown" @pointermove="onRelightPointerMove" @pointerup="onRelightPointerUp">
          <g v-for="(h, i) in relightHandles" :key="h.id">
            <circle class="relight-handle" :class="{ 'is-selected': selectedLight === h.id, 'is-behind': h.behind }"
              :cx="h.x" :cy="h.y" :r="9 * ofPerScreen" :style="{ fill: h.color }"
              @pointerdown="onLightHandleDown($event, h.id)" />
            <text class="relight-label" :x="h.x" :y="h.y + 3.5 * ofPerScreen" :font-size="10 * ofPerScreen">{{ i + 1 }}</text>
          </g>
        </svg>
        <!-- Lens blur focus (useFocusPicker): the point shown while the
             Effects tab is open; while picking, a click on the image sets it. -->
        <svg v-show="editTab === 'effects' && !cropMode && webglRenderer != null && (pickingFocus || recipe.blurAmount > 0)" ref="focusOverlayRef"
          class="crop-overlay focus-overlay" :class="{ 'is-picking': pickingFocus, 'is-passthrough': spaceHeld }"
          :style="{ transform: displayTransform, width: imageW + 'px', height: imageH + 'px' }"
          :viewBox="focusViewBox" preserveAspectRatio="none" @pointerdown="onFocusPointerDown">
          <g v-if="focusMarker" class="focus-marker">
            <circle :cx="focusMarker.x" :cy="focusMarker.y" :r="14 * ofPerScreen" />
            <line :x1="focusMarker.x - 22 * ofPerScreen" :y1="focusMarker.y" :x2="focusMarker.x - 8 * ofPerScreen" :y2="focusMarker.y" />
            <line :x1="focusMarker.x + 8 * ofPerScreen" :y1="focusMarker.y" :x2="focusMarker.x + 22 * ofPerScreen" :y2="focusMarker.y" />
            <line :x1="focusMarker.x" :y1="focusMarker.y - 22 * ofPerScreen" :x2="focusMarker.x" :y2="focusMarker.y - 8 * ofPerScreen" />
            <line :x1="focusMarker.x" :y1="focusMarker.y + 8 * ofPerScreen" :x2="focusMarker.x" :y2="focusMarker.y + 22 * ofPerScreen" />
          </g>
        </svg>
        <img v-show="activeSource && !activeSource.invalid && !webglRenderer && status !== 'rendering'" class="preview" draggable="false" :style="{ transform: displayTransform }" :src="activeSource ? resolveUrl(activeSource.embeddedUrl) : ''" :alt="t('aria.preview')" />
        <div v-if="activeSource?.invalid" class="invalid-state">
          <img v-if="activeSource && thumbSrc(activeSource)" draggable="false" :src="thumbSrc(activeSource)" :alt="activeSource.name" />
          <p class="invalid-title">{{ t('invalid.missingTitle') }}</p>
          <p class="invalid-sub">{{ t('invalid.missingSub') }}</p>
        </div>
        <div v-if="webglUnsupported" class="invalid-state">
          <p class="invalid-title">{{ t('invalid.webglTitle') }}</p>
          <p class="invalid-sub">{{ t('invalid.webglSub') }}</p>
        </div>
      </div>

      <footer class="status" v-show="activeSource || libraryView === 'library'">
        <div class="status-left">
          <div class="status-cell" v-if="libraryView === 'develop'">
            <span class="status-label">{{ t('status.label') }}</span>
            <span class="status-value" :data-state="status">{{ timing ? t('status.decodedIn', { ms: timing }) : status }}</span>
          </div>
          <div class="status-cell" v-else-if="selectedIds.size">
            <span class="status-value">{{ t('grid.selected', { n: selectedIds.size }) }}</span>
          </div>
          <div class="status-cell" v-if="importProgress">
            <span class="spinner" aria-hidden="true" />
            <span class="status-value">{{ t('status.importProgress', { done: importProgress.done, total: importProgress.total }) }}</span>
          </div>
        </div>
        <div class="status-right">
          <div class="status-cell zoom-cell" v-if="activeSource && libraryView === 'develop'">
            <button class="zoom-btn" @click="zoomOut" :disabled="zoom <= 0.1" :title="t('zoom.out')" :aria-label="t('zoom.out')"><JIcon :icon="IconMinus" /></button>
            <span class="zoom-percent">{{ zoomPercent }}%</span>
            <button class="zoom-btn" @click="zoomIn" :disabled="zoom >= 50" :title="t('zoom.in')" :aria-label="t('zoom.in')"><JIcon :icon="IconPlus" /></button>
            <button class="zoom-btn" @click="fitView" :title="t('zoom.fit')" :aria-label="t('zoom.fit')"><JIcon :icon="IconFitToScreen" /></button>
          </div>
        </div>
      </footer>
    </main>

    <aside class="rail">
      <div class="rail-body" v-wheel-adjust>
      <canvas ref="histoCanvasRef" class="histogram" v-show="activeSource" />
      <!-- The chat fills the rail on its own: its log scrolls and its composer
           stays put, which the shared panel scroller cannot give it. -->
      <section class="rail-panels chat" v-if="editTab === 'assistant'">
        <header class="panel-head chat-head">
          <span>{{ t('panel.assistant') }}</span>
          <button class="icon-btn chat-gear" type="button" :title="t('models.title')" :aria-label="t('models.title')" @click="modelSettingsOpen = true">
            <JIcon :icon="IconSettings" />
          </button>
          <button class="icon-btn chat-gear" type="button" :disabled="!chatEntries.length || chatBusy" :title="t('chat.clear')" :aria-label="t('chat.clear')" @click="resetChat"><JIcon :icon="IconBroom" /></button>
        </header>
        <ModelSettings :open="modelSettingsOpen" :models="chatModels" :catalog="chatCatalog"
          @update:models="v => chatModels = v" @close="modelSettingsOpen = false" />
        <div class="chat-log" ref="chatLogRef">
          <div class="chat-empty" v-if="!chatEntries.length">
            <ChatIcon class="chat-empty-icon" name="chat" />
            <p class="chat-empty-title">{{ t('chat.empty.title') }}</p>
            <p>{{ t('chat.empty') }}</p>
            <!-- Chips fill the box rather than send: the send key stays where the words become the user's own. -->
            <div class="chat-chips">
              <button v-for="k in CHAT_CHIPS" :key="k" type="button" class="chat-chip" @click="chatDraft = t(k)">{{ t(k) }}</button>
            </div>
          </div>
          <template v-for="(entry, i) in chatEntries" :key="i">
            <!-- Steered: the user talking over a run — a note at the margin, not a bubble. -->
            <div v-if="entry.kind === 'user'" class="chat-msg chat-user" :class="{ 'is-steered': entry.steered }" :title="entry.steered ? t('chat.steered') : undefined">
              <ChatIcon v-if="entry.steered" class="chat-steer-icon" name="steer" />{{ entry.text }}
            </div>
            <div v-else-if="entry.kind === 'assistant'" class="chat-msg chat-assistant" :class="{ 'is-error': entry.error }">
              <!-- Reasoning folds to one line above the reply: the tail while it
                   streams, the opening line once it has settled. -->
              <details v-if="entry.thinking" class="chat-row chat-thinking" :class="{ 'is-running': thinkingActive(entry) }">
                <summary class="chat-row-line">
                  <ChatIcon class="chat-row-icon" :name="thinkingActive(entry) ? 'loader' : 'bulb'" />
                  <span class="chat-row-label">{{ thinkingLabel(entry) }}</span>
                  <span class="chat-row-detail">{{ thinkingLine(entry) }}</span>
                </summary>
                <div class="chat-row-body chat-reasoning"><AssistantMessage :text="entry.thinking" :streaming="thinkingActive(entry)" /></div>
              </details>
              <AssistantMessage v-if="entry.text" :text="entry.text" :streaming="entry.streaming" />
              <span v-if="entry.error" class="chat-error">{{ entry.error }}</span>
              <span v-else-if="!entry.text && !entry.thinking && chatBusy" class="chat-typing">…</span>
              <span v-if="entry.usage" class="chat-usage">{{ usageLine(entry.usage) }}</span>
            </div>
            <!-- The run narrating itself, in the same row as the tool calls it happened among. -->
            <div v-else-if="entry.kind === 'status'" class="chat-row chat-status">
              <div class="chat-row-line is-static">
                <ChatIcon class="chat-row-icon" :name="entry.status === 'stopped' ? 'stop' : 'info'" />
                <span class="chat-row-detail">{{ t(`chat.status.${entry.status}` as MessageKey) }}</span>
              </div>
            </div>
            <!-- A tool call: the argument gets the room, the outcome shares the
                 line, and a click opens what the model sent or saw underneath. -->
            <details v-else class="chat-row chat-tool" :class="{ 'is-running': !entry.done, 'is-failed': entry.error }">
              <summary class="chat-row-line" :title="entry.error ?? toolSummary(entry)">
                <ChatIcon class="chat-row-icon" :name="toolIcon(entry)" />
                <span class="chat-row-label">{{ t(`chat.tool.${entry.name}` as MessageKey) }}</span>
                <span class="chat-row-detail">{{ toolSummary(entry) }}</span>
                <span class="chat-row-meta" v-if="toolMeta(entry)">{{ toolMeta(entry) }}</span>
              </summary>
              <pre class="chat-row-body chat-tool-error" v-if="entry.error">{{ entry.error }}</pre>
              <div class="chat-row-body chat-tool-body" v-else-if="toolDetail(entry)">
                <img v-if="toolDetail(entry)!.image" :src="toolDetail(entry)!.image" alt="" />
                <template v-for="line in toolDetail(entry)!.lines" :key="line">{{ line }}<br /></template>
                <table v-if="toolDetail(entry)!.rows">
                  <tr v-for="[k, v] in toolDetail(entry)!.rows" :key="k"><td>{{ k }}</td><td>{{ v }}</td></tr>
                </table>
              </div>
            </details>
          </template>
        </div>
        <form class="chat-compose" @submit.prevent="submitChat">
          <textarea v-model="chatDraft" class="chat-input" rows="2" :placeholder="t('chat.placeholder')"
            @keydown.enter="onChatEnter" />
          <!-- Which model, and how long it thinks, are decided while writing the
               prompt — so they sit with it. -->
          <div class="chat-compose-row">
            <SelectMenu v-model="chatModel" :options="chatModelOptions" :disabled="chatBusy"
              :aria-label="t('models.title')" :placeholder="t('models.none')" />
            <SelectMenu v-model="chatThinking" :options="chatThinkingOptions" :disabled="chatBusy" :aria-label="t('chat.thinking')" />
            <button v-if="chatBusy" type="button" class="chat-send is-stop" :title="t('chat.stop')" :aria-label="t('chat.stop')" @click="abortChat">
              <JIcon :icon="IconStop" />
            </button>
            <button v-else type="submit" class="chat-send" :disabled="!chatDraft.trim()" :title="t('chat.send')" :aria-label="t('chat.send')">
              <JIcon :icon="IconArrowUp" weight="bold" />
            </button>
          </div>
        </form>
      </section>
      <!-- Only the panels scroll; the histogram stays put as a live readout. -->
      <div class="rail-scroll" v-else>
      <div class="rail-panels">

      <section class="panel crop-panel" v-if="activeSource && cropMode">
        <header class="panel-head">
          <span>{{ t('panel.crop') }}</span>
          <button class="ghost ghost-icon" type="button" :title="t('common.reset')" :aria-label="t('common.reset')" @click="resetCrop"><JIcon :icon="IconReset" /></button>
        </header>
        <div class="control-row">
          <label class="control-label">{{ t('crop.aspect') }}</label>
          <div class="crop-aspect">
            <SelectMenu :model-value="customAspect ? 'custom' : cropAspect" :options="aspectOptions"
              :aria-label="t('crop.aspect')" @update:model-value="selectAspect" />
            <button class="icon-mini" type="button" :title="t('crop.swap')" @click="swapAspect" :aria-label="t('aria.swapAspect')">
              <JIcon :icon="IconArrowsLeftRight" />
            </button>
          </div>
        </div>
        <div class="control-row" v-if="customAspect">
          <label class="control-label">{{ t('crop.ratio') }}</label>
          <div class="crop-custom">
            <input class="slider-number" type="number" min="0.1" step="0.1" :value="customAspect[0]"
              @change="setCustomAspect(($event.target as HTMLInputElement).valueAsNumber, customAspect![1])" />
            <span class="crop-custom-x">×</span>
            <input class="slider-number" type="number" min="0.1" step="0.1" :value="customAspect[1]"
              @change="setCustomAspect(customAspect![0], ($event.target as HTMLInputElement).valueAsNumber)" />
          </div>
        </div>
        <div class="control-row">
          <label class="control-label">{{ t('crop.guide') }}</label>
          <SelectMenu :model-value="cropGuide" :options="guideOptions" :aria-label="t('crop.guide')"
            :title="t('crop.guideHint')" @update:model-value="setCropGuide" />
        </div>
        <SliderRow :model-value="Number(crop.angle.toFixed(2))" @update:model-value="setAngle"
          :label="t('crop.angle')" :min="-45" :max="45" :step="0.01" />
        <div class="crop-buttons">
          <button type="button" class="crop-tool" :class="{ 'is-on': lineTool === 'straighten' }" :title="t('crop.straighten')"
            :aria-pressed="lineTool === 'straighten'" @click="setLineTool('straighten')">
            <JIcon :icon="IconRuler" />
          </button>
          <button type="button" class="crop-tool" :title="t('crop.rotateLeft')" @click="rotateCrop(-1)">
            <JIcon :icon="IconRotateCcw" />
          </button>
          <button type="button" class="crop-tool" :title="t('crop.rotateRight')" @click="rotateCrop(1)">
            <JIcon :icon="IconRotate" />
          </button>
          <button type="button" class="crop-tool" :class="{ 'is-on': crop.flipH }" :title="t('crop.flipH')" @click="flipCropH">
            <JIcon :icon="IconFlip" />
          </button>
          <button type="button" class="crop-tool" :class="{ 'is-on': crop.flipV }" :title="t('crop.flipV')" @click="flipCropV">
            <JIcon :icon="IconFlipVertical" />
          </button>
        </div>
        <header class="panel-head crop-sub" :class="{ 'is-off': isBypassed('transform') }">
          <span class="panel-title">
            <button type="button" class="panel-switch" :class="{ 'is-on': !isBypassed('transform') }"
              :aria-pressed="!isBypassed('transform')" :title="t('panel.switch')" @click="toggleBypass('transform')" />
            {{ t('xf.title') }}
          </span>
          <button class="ghost ghost-icon" type="button" :title="t('common.reset')" :aria-label="t('common.reset')" @click="resetTransform"><JIcon :icon="IconReset" /></button>
        </header>
        <div class="xf-guided">
          <button type="button" class="crop-tool xf-guided-btn" :class="{ 'is-on': lineTool === 'guided' }"
            :title="t('xf.guidedTitle')" :aria-pressed="lineTool === 'guided'" @click="setLineTool('guided')">
            <JIcon :icon="IconGrid3x3" />
            <span>{{ t('xf.guided') }}</span>
          </button>
          <button type="button" class="crop-tool xf-guided-count" :disabled="!crop.xf.guides.length"
            :title="t('xf.removeGuide')" @click="removeLastGuide">{{ crop.xf.guides.length }} / 4 <JIcon :icon="IconX" /></button>
        </div>
        <SliderRow v-for="s in XF_SLIDERS" :key="s.key" :model-value="crop.xf[s.key]"
          @update:model-value="v => setTransform({ [s.key]: v })"
          :label="t(`xf.${s.key}`)" :min="s.min" :max="s.max" :step="1" :reset-value="s.reset" show-modified />
        <button type="button" class="crop-done" @click="exitCropMode"><JIcon :icon="IconCheck" />{{ t('crop.done') }}</button>
      </section>

      <section class="panel" v-if="editTab === 'recipes' && activeSource">
        <header class="panel-head">
          <span>{{ t('panel.recipes') }}</span>
          <span class="recipe-actions">
            <button class="ghost ghost-icon" type="button" :title="t('recipe.copyHint')" :aria-label="t('recipe.copy')" @click="openCopyDialog(null)"><JIcon :icon="IconCopy" /></button>
            <button class="ghost ghost-icon" type="button" :title="t('recipe.pasteHint')" :aria-label="t('recipe.paste')" @click="pasteRecipe"><JIcon :icon="IconClipboardPaste" /></button>
          </span>
        </header>
        <form class="recipe-save" @submit.prevent="saveRecipe">
          <input class="model-field" v-model="recipeName" :placeholder="t('recipe.namePlaceholder')" spellcheck="false" @keydown.stop />
          <button class="ghost ghost-icon" type="submit" :title="t('recipe.save')" :aria-label="t('recipe.save')"><JIcon :icon="IconPlus" /></button>
        </form>
        <ol class="history-list recipe-list" v-if="savedRecipes.length">
          <li v-for="(r, i) in savedRecipes" :key="r.name" class="recipe-row">
            <button type="button" class="history-step" @click="applyRecipeStep(r.data, r.name)">
              <span class="history-label">{{ r.name }}</span>
            </button>
            <button class="icon-mini" type="button" :aria-label="t('common.remove')" @click="deleteRecipe(i)">
              <JIcon :icon="IconX" />
            </button>
          </li>
        </ol>
        <p class="control-note">{{ t('recipe.hint') }}</p>
      </section>
      <section class="panel history-panel" v-if="editTab === 'history'">
        <header class="panel-head">
          <span>{{ t('panel.history') }}</span>
          <span class="panel-hint">{{ t('history.count', { n: history.length }) }}</span>
        </header>
        <ol class="history-list" @pointerleave="endHistoryPreview">
          <li v-for="step in historySteps" :key="step.index">
            <button type="button" class="history-step"
              :class="{ 'is-current': step.index === historyIndex, 'is-undone': step.index > historyIndex, 'is-previewing': historyPreview === history[step.index] }"
              @pointerenter="hoverHistoryStep(step.index)" @click="jumpHistory(step.index)">
              <span class="history-label">{{ step.label }}</span>
              <span class="history-author" v-if="step.author">{{ step.author }}</span>
            </button>
          </li>
        </ol>
      </section>
      <section class="panel" v-if="editTab === 'settings'">
        <header class="panel-head">
          <span>{{ t('panel.settings') }}</span>
        </header>
        <div class="control-row">
          <label class="control-label">{{ t('settings.language') }}</label>
          <SelectMenu :model-value="locale" :options="LOCALES" :aria-label="t('settings.language')"
            @update:model-value="setLocale" />
        </div>
        <div class="control-row" v-if="activeSource && isRawSource">
          <label class="control-label" :title="t('settings.engineHint')">{{ t('settings.engine') }}</label>
          <SelectMenu v-model="profileId" :options="engineOptions" :aria-label="t('settings.engine')" />
        </div>
        <!-- The look itself is picked in the Creative Look panel, next to the
             tweaks it belongs with and the reset that returns both to as-shot. -->
        <p class="control-note" v-if="activeSource && isRawSource && profileId === 'sony' && usingDcp">
          {{ t('engine.sonyUnavailable') }}
        </p>
        <div class="control-row" v-if="activeSource && isRawSource && usingDcp && dcpStyles.length">
          <label class="control-label">{{ t('settings.dcp') }}</label>
          <SelectMenu v-model="dcpCode" :options="dcpOptions" :aria-label="t('settings.dcp')" />
        </div>
        <div class="control-row" v-if="activeSource && isRawSource && usingDcp && hasCameraMatch">
          <label class="control-label" for="camera-match" :title="t('settings.cameraMatchHint')">{{ t('settings.cameraMatch') }}</label>
          <label class="switch">
            <input id="camera-match" type="checkbox" v-model="cameraMatch" />
            <span class="switch-track"><span class="switch-thumb" /></span>
          </label>
        </div>
        <div class="control-row" v-if="activeSource && p3Supported">
          <label class="control-label">{{ t('settings.display') }}</label>
          <SelectMenu v-model="viewSettings.displayGamut" :options="gamutOptions"
            :aria-label="t('settings.display')" />
        </div>
        <div class="control-row" v-if="activeSource">
          <label class="control-label">{{ t('settings.exportExif') }}</label>
          <SelectMenu v-model="viewSettings.exportStripPrivate" :options="exifOptions" :title="t('exif.hint')"
            :aria-label="t('settings.exportExif')" />
        </div>
      </section>
      <!-- The shot's in-camera Creative Look tweaks. Its own panel because these
           are Sony's stages, not ours: they start at what the body recorded and
           reset back to it, which is why they cannot share the Tone panel. -->
      <section class="panel" v-if="editTab === 'look' && lookAsShot" :class="{ 'is-off': isBypassed('look') }">
        <header class="panel-head">
          <span class="panel-title">
            <button type="button" class="panel-switch" :class="{ 'is-on': !isBypassed('look') }"
              :aria-pressed="!isBypassed('look')" :title="t('panel.switch')" @click="toggleBypass('look')" />
            {{ t('panel.creativeLook') }}
            <span v-if="lookEdited" class="panel-dot" aria-hidden="true" />
          </span>
          <button class="ghost ghost-icon" type="button" :disabled="!lookEdited" :title="t('common.reset')" :aria-label="t('common.reset')" @click="resetLook"><JIcon :icon="IconReset" /></button>
        </header>
        <!-- Every ARW carries all of the body's looks, so this switches between
             calibrations already in the file. No re-decode: they share the one
             hue-segmented matrix, so only the curve and chroma terms change. -->
        <div v-if="availableLooks.length > 1" class="control-row">
          <label class="control-label" for="look-style">{{ t('settings.creativeLook') }}</label>
          <SelectMenu id="look-style" :model-value="effectiveLookStyle" :options="lookOptions"
            @update:model-value="setLookStyle" />
        </div>
        <!-- Say so when the look is not in the RAW. The curve is exact; the
             chroma is another body's, and that is worth admitting on screen. -->
        <p class="control-note" v-if="lookBorrowed">{{ t('look.borrowedHint') }}</p>
        <!-- Edit's 色彩复制 radio, as a switch: 标准 is the stage off (Edit's
             own default) and 高级 is Sony's 3-D LUT. Sony renders only — the
             stage lives inside the engine's YCC section, which a DCP render
             does not have. A redraw, not a re-decode: the table is static. -->
        <div class="control-row" v-if="activeProfileKind === 'sony'">
          <label class="control-label" for="sony-advanced-colour"
            :title="t('look.advancedColourHint')">{{ t('look.advancedColour') }}</label>
          <label class="switch">
            <input id="sony-advanced-colour" type="checkbox" v-model="sonyAdvancedColour" />
            <span class="switch-track"><span class="switch-thumb" /></span>
          </label>
        </div>
        <!-- Camera match: the residual the engine's own export still has
             against the body's JPEG, fitted per body and look and applied as
             the post chain's last stage. Only where the worker has a table for
             this body — one fitted on another body is not offered. -->
        <div class="control-row" v-if="activeProfileKind === 'sony' && hasSonyCameraMatch">
          <label class="control-label" for="sony-camera-match"
            :title="t('look.cameraMatchHint')">{{ t('look.cameraMatch') }}</label>
          <label class="switch">
            <input id="sony-camera-match" type="checkbox" v-model="sonyCameraMatch" />
            <span class="switch-track"><span class="switch-thumb" /></span>
          </label>
        </div>
        <!-- Sharpening is a camera setting, not one of the six tweaks, so it is
             reported rather than offered: there is no slider here that could
             move it. The two ladder positions are what the body's own menu showed. -->
        <div class="control-row" v-if="sharpening">
          <span class="control-label">{{ t('look.sharpening') }}</span>
          <span class="control-value">
            {{ t('look.sharpeningValue', { level: `+${sharpening.level}`, range: `+${sharpening.range}` }) }}
          </span>
        </div>
        <SliderRow v-for="spec in lookSliders" :key="spec.key"
          :model-value="effectiveLook[spec.key]" @update:model-value="setLookTweak(spec.key, $event)"
          :label="t(`lookSlider.${spec.key}`)" :input-id="`look-${spec.key}`"
          :min="spec.min" :max="spec.max" :step="1"
          :reset-value="lookAsShot[spec.key]" show-modified />
        <!-- DRO. Belongs here rather than in Tone: it is the camera's own curve
             for this frame, not a grade of ours, and it resets to what the body
             did like everything else in this panel. -->
        <template v-if="droAvailable">
          <div class="control-row">
            <label class="control-label" :title="t('look.droHint')">{{ t('look.droModeLabel') }}</label>
          </div>
          <div class="dro-modes" role="group" :aria-label="t('look.droModeLabel')">
            <button type="button" class="dro-mode" :class="{ on: droMode === 'off' }"
              :aria-pressed="droMode === 'off'" @click="setDroMode('off')">
              {{ t('look.droOff') }}
            </button>
            <button type="button" class="dro-mode" :class="{ on: droMode === 'auto' }"
              :aria-pressed="droMode === 'auto'" @click="setDroMode('auto')">
              {{ t('look.droAuto') }}
            </button>
            <button v-for="(lv, i) in droLevels" :key="lv" type="button" class="dro-mode"
              :class="{ on: droMode === 'level' && droLevel === lv }"
              :aria-pressed="droMode === 'level' && droLevel === lv"
              @click="setDroMode('level', lv)">
              {{ t('look.droLevel', { n: i + 1 }) }}
            </button>
          </div>
          <!-- Strength only qualifies Auto: a level already *is* the amount, and
               scaling one would land between two curves Sony never ships. -->
          <SliderRow v-if="droMode === 'auto'"
            :model-value="effectiveDro" @update:model-value="setDro($event)"
            :label="t('look.droStrength')" input-id="look-dro"
            :min="0" :max="DRO_MAX" :step="0.05"
            :reset-value="droAsShot" show-modified />
          <p class="control-note" v-if="droMode === 'auto'">{{ t('look.droAutoHint') }}</p>
          <p class="control-note" v-else-if="droMode === 'level'">{{ t('look.droLevelHint') }}</p>
        </template>
      </section>
      <section v-for="group in tabGroups" :key="group.title" class="panel" :class="{ 'is-off': isBypassed(group.title) }">
        <header class="panel-head">
          <span class="panel-title">
            <button type="button" class="panel-switch" :class="{ 'is-on': !isBypassed(group.title) }"
              :aria-pressed="!isBypassed(group.title)" :title="t('panel.switch')" @click="toggleBypass(group.title)" />
            {{ t(`panel.${group.title}`) }}
            <span v-if="groupEdited(group)" class="panel-dot" aria-hidden="true" />
          </span>
          <button class="ghost ghost-icon" type="button" :disabled="!groupEdited(group)" :title="t('common.reset')" :aria-label="t('common.reset')" @click="resetGroup(group)"><JIcon :icon="IconReset" /></button>
        </header>
        <SliderRow v-for="spec in group.items" :key="spec.key"
          v-model="recipe[spec.key]" :label="t(`slider.${spec.key}`)" :input-id="`s-${spec.key}`"
          :min="spec.min" :max="spec.max" :step="spec.step"
          :reset-value="SLIDER_DEFAULTS[spec.key]" :track="WB_TRACK[spec.key]" show-modified />
        <template v-if="group.title === 'lensBlur' || group.title === 'fog'">
          <p v-if="!relightHasGeometry" class="control-note">{{ relightNotice ?? t('relight.analyzing') }}</p>
          <div v-if="group.title === 'lensBlur'" class="lb-actions">
            <button class="ghost" type="button" :class="{ 'is-on': pickingFocus }" :disabled="!relightHasGeometry"
              @click="pickingFocus = !pickingFocus">
              <JIcon :icon="IconCursorCrosshair" /> {{ pickingFocus ? t('lensBlur.picking') : t('lensBlur.pickFocus') }}
            </button>
            <button class="ghost" type="button" :disabled="recipe.blurFocusX < 0"
              @click="recipe.blurFocusX = -1; recipe.blurFocusY = -1">{{ t('lensBlur.centre') }}</button>
          </div>
        </template>
      </section>

      <section class="panel" v-if="editTab === 'detail' && activeSource && isRawSource">
        <header class="panel-head">
          <span>{{ t('panel.detail') }}</span>
          <span v-if="denoiseBusy" class="panel-hint">{{ t('detail.denoising') }}</span>
        </header>
        <div class="control-row">
          <label class="control-label" for="denoise-on">{{ t('detail.denoise') }}</label>
          <label class="switch">
            <input id="denoise-on" type="checkbox" v-model="denoise.enabled" />
            <span class="switch-track"><span class="switch-thumb" /></span>
          </label>
        </div>
        <!-- The wavelet's Auto: its strength follows the shot's ISO rather
             than the slider, and the worker resolves it since ISO lives in the
             file. Sony's own filter has no such switch (sonyDenoiser): its Auto
             is the sliders at 50, so the sliders stand and reset is Auto. -->
        <div class="control-row" v-if="!sonyDenoiser" v-show="denoise.enabled" style="margin-top: 6px;">
          <label class="control-label" for="denoise-auto">{{ t('detail.denoiseAuto') }}</label>
          <label class="switch">
            <input id="denoise-auto" type="checkbox" v-model="denoise.auto" />
            <span class="switch-track"><span class="switch-thumb" /></span>
          </label>
        </div>
        <SliderRow v-show="denoise.enabled && !denoiseAuto" v-model="denoise.amount" style="margin-top: 6px;"
          :label="t('detail.amount')" input-id="denoise-amount" :min="0" :max="100" :reset-value="50" />
        <!-- 50 is neutral for both: the camera's own detail-restore value, and
             the tuned chroma threshold. Reset therefore goes to 50, not 100. -->
        <!-- Color NR shows where it reaches the pixels: on frames whose RAW
             denoiser takes it (the wavelet fallback), and on a Sony render in
             manual mode, where it is Edit's own 色彩降噪 slider and drives
             Marble's chroma cleanup in the shader (rendering/sony-denoise.ts)
             rather than the RAW stage — Sony's own filter has no such control,
             which is why denoiseUsesChroma alone says no. In Auto the engine
             greys the slider out, so it hides. The value is kept either way, so
             it comes back if the frame changes. -->
        <SliderRow v-show="denoise.enabled && (denoiseUsesChroma || sonyDenoiser)" v-model="denoise.chroma" style="margin-top: 6px;"
          :label="t('detail.chromaNr')" input-id="denoise-chroma" :min="0" :max="100" :reset-value="50" />
        <!-- Greyed out in Auto in Edit too: Auto is the manual panel at its
             defaults, and denoisePayload sends the neutral value for it. -->
        <SliderRow v-show="denoise.enabled && !denoiseAuto" v-model="denoise.edge" style="margin-top: 6px;"
          :label="t('detail.edgeNr')" input-id="denoise-edge" :min="0" :max="100" :reset-value="50" />
      </section>

      <section class="panel" v-if="editTab === 'color' && activeSource" :class="{ 'is-off': isBypassed('hsl') }">
        <header class="panel-head">
          <span class="panel-title">
            <button type="button" class="panel-switch" :class="{ 'is-on': !isBypassed('hsl') }"
              :aria-pressed="!isBypassed('hsl')" :title="t('panel.switch')" @click="toggleBypass('hsl')" />
            {{ t('panel.hsl') }}
            <span v-if="hslEdited" class="panel-dot" aria-hidden="true" />
          </span>
          <button class="ghost ghost-icon" type="button" :disabled="!hslEdited" :title="t('common.reset')" :aria-label="t('common.reset')" @click="resetHsl"><JIcon :icon="IconReset" /></button>
        </header>
        <div class="hsl-tabs">
          <button :class="{ active: hslTab === 'hue' }" @click="hslTab = 'hue'">H</button>
          <button :class="{ active: hslTab === 'sat' }" @click="hslTab = 'sat'">S</button>
          <button :class="{ active: hslTab === 'lum' }" @click="hslTab = 'lum'">L</button>
        </div>
        <SliderRow v-for="(range, i) in HSL_RANGES" :key="range.key"
          :model-value="hslValue(i)" @update:model-value="v => setHsl(i, v)"
          :label="t(`hsl.${range.key}`)" :dot-color="range.color" row-class="hsl-row"
          :min="-100" :max="100" show-modified />
      </section>

      <section class="panel" v-if="editTab === 'color' && activeSource" :class="{ 'is-off': isBypassed('grading') }">
        <header class="panel-head">
          <span class="panel-title">
            <button type="button" class="panel-switch" :class="{ 'is-on': !isBypassed('grading') }"
              :aria-pressed="!isBypassed('grading')" :title="t('panel.switch')" @click="toggleBypass('grading')" />
            {{ t('panel.grading') }}
            <span v-if="gradingEdited" class="panel-dot" aria-hidden="true" />
          </span>
          <button class="ghost ghost-icon" type="button" :disabled="!gradingEdited" :title="t('common.reset')" :aria-label="t('common.reset')" @click="resetGrading"><JIcon :icon="IconReset" /></button>
        </header>
        <div v-for="g in GRADING_BANDS" :key="g.band" class="grading-group">
          <div class="grading-header">
            <span class="grading-dot" :style="{ background: gradingColor(g.band) }" />
            <span>{{ t(`grading.${g.band}`) }}</span>
          </div>
          <SliderRow v-model="grading[g.hueKey]" :label="t('grading.h')" row-class="grading-row" :min="-180" :max="180"
            :track="HUE_TRACK" />
          <SliderRow v-model="grading[g.satKey]" :label="t('grading.s')" row-class="grading-row" :min="0" :max="100"
            :track="satTrack(grading[g.hueKey])" />
        </div>
        <SliderRow v-model="grading.blend" :label="t('grading.blend')" :min="0" :max="100" :reset-value="50" />
        <SliderRow v-model="grading.balance" :label="t('grading.balance')" :min="-100" :max="100" />
      </section>

      <section class="panel" v-if="editTab === 'light' && activeSource" :class="{ 'is-off': isBypassed('curve') }">
        <header class="panel-head">
          <span class="panel-title">
            <button type="button" class="panel-switch" :class="{ 'is-on': !isBypassed('curve') }"
              :aria-pressed="!isBypassed('curve')" :title="t('panel.switch')" @click="toggleBypass('curve')" />
            {{ t('panel.curve') }}
          </span>
          <button class="ghost ghost-icon" type="button" :title="t('common.reset')" :aria-label="t('common.reset')" @click="resetCurve"><JIcon :icon="IconReset" /></button>
        </header>
        <div class="curve-tabs">
          <button v-for="tab in CURVE_TABS" :key="tab" type="button"
            :class="['curve-tab', `curve-tab--${tab}`, { active: curveChannel === tab }]"
            @click="setCurveChannel(tab)">{{ t(`curve.${tab}`) }}</button>
        </div>
        <canvas ref="curveCanvas" class="curve-canvas"
          @mousedown="onCurveMouseDown"
          @mousemove="onCurveHover"
          @mouseleave="onCurveLeave"
          @dblclick="onCurveDoubleClick" />

        <!-- Parametric region + split sliders -->
        <div v-if="curveChannel === 'parametric'" class="curve-params">
          <SliderRow v-for="r in PARAM_REGIONS" :key="r"
            :model-value="paramValue(r)" @update:model-value="v => setParam(r, v)"
            :label="t(`curveRegion.${r}`)" :min="-100" :max="100" />
          <!-- The three region boundaries as three thumbs on one rail. The
               inputs are stacked; only their thumbs take the pointer. -->
          <div class="curve-splits">
            <span class="curve-splits-label">{{ t('curve.splits') }}</span>
            <div class="split-rail" :style="{
              '--s1': (paramValue('shadowSplit') - 4) / 92,
              '--s2': (paramValue('midtoneSplit') - 4) / 92,
              '--s3': (paramValue('highlightSplit') - 4) / 92 }">
              <input type="range" min="4" max="96" step="1" :title="t('slider.hint')"
                :value="paramValue('shadowSplit')"
                @input="setParam('shadowSplit', Math.min(($event.target as HTMLInputElement).valueAsNumber, paramValue('midtoneSplit') - 4))" />
              <input type="range" min="4" max="96" step="1" :title="t('slider.hint')"
                :value="paramValue('midtoneSplit')"
                @input="setParam('midtoneSplit', Math.min(Math.max(($event.target as HTMLInputElement).valueAsNumber, paramValue('shadowSplit') + 4), paramValue('highlightSplit') - 4))" />
              <input type="range" min="4" max="96" step="1" :title="t('slider.hint')"
                :value="paramValue('highlightSplit')"
                @input="setParam('highlightSplit', Math.max(($event.target as HTMLInputElement).valueAsNumber, paramValue('midtoneSplit') + 4))" />
            </div>
          </div>
        </div>

        <!-- Point-curve presets (applied to the RGB master channel) -->
        <div v-else class="curve-presets">
          <button v-for="name in presetNames" :key="name" type="button"
            class="curve-preset" @click="applyCurvePreset(name)">{{ t(`curvePreset.${name}`) }}</button>
        </div>
      </section>

      <!-- Erase: brush size, the stroke list (hover shows a stroke on the
           canvas), and why erase cannot run here when it cannot. -->
      <section class="panel" v-if="editTab === 'erase' && activeSource">
        <header class="panel-head">
          <span class="panel-title">
            {{ t('panel.erase') }}
            <span v-if="erase.length" class="panel-dot" aria-hidden="true" />
          </span>
          <span v-if="eraseBusy" class="panel-hint">{{ t('erase.working') }}</span>
          <button class="ghost ghost-icon" type="button" :disabled="!erase.length" :title="t('common.reset')" :aria-label="t('common.reset')" @click="resetErase"><JIcon :icon="IconReset" /></button>
        </header>
        <div class="curve-tabs" :aria-label="t('erase.mode')">
          <button type="button" :class="['curve-tab', { active: eraseMode === 'fill' }]" @click="eraseMode = 'fill'">{{ t('erase.modeFill') }}</button>
          <button type="button" :class="['curve-tab', { active: eraseMode === 'heal' }]" @click="eraseMode = 'heal'">{{ t('erase.modeHeal') }}</button>
        </div>
        <p class="control-note" :class="{ 'is-warn': eraseNotice && !eraseDownloading && eraseMode === 'fill' }">
          {{ eraseMode === 'heal' ? t('erase.healHint') : eraseNotice ?? t('erase.hint') }}</p>
        <progress v-if="eraseDownloading" class="erase-progress" :value="eraseStatus?.received ?? 0" :max="eraseStatus?.total || 1" />
        <button v-if="eraseStatus?.reason === 'models-missing' && eraseStatus.detail" class="ghost" type="button" @click="refreshEraseStatus(true)">{{ t('erase.retryDownload') }}</button>
        <SliderRow v-model="eraseBrush" :label="t('erase.brush')" :min="4" :max="200" :reset-value="24" />
        <SliderRow v-model="eraseGrow" :label="t('erase.grow')" :min="0" :max="100" :reset-value="15" />
        <SliderRow v-model="eraseFeather" :label="t('erase.feather')" :min="0" :max="100" :reset-value="35" />
        <!-- The fill being brushed: its strokes so far, and the button that runs it. -->
        <div class="erase-draft" v-if="eraseMode === 'fill' || eraseDraft">
          <span class="erase-draft-count">{{ eraseDraft ? t('erase.draft', { n: eraseDraftLines }) : t('erase.draftEmpty') }}</span>
          <button class="ghost" type="button" :disabled="!eraseDraft" :title="t('erase.discardHint')" @click="discardEraseDraft">{{ t('erase.discard') }}</button>
          <button class="primary" type="button" :disabled="!eraseDraft || erase.length >= ERASE_MAX_STROKES"
            :title="t('erase.fillHint')" @click="commitEraseDraft">{{ t('erase.fill') }}</button>
        </div>
        <div class="control-row">
          <label class="control-label" for="erase-strokes">{{ t('erase.showStrokes') }}</label>
          <label class="switch">
            <input id="erase-strokes" type="checkbox" v-model="eraseShowStrokes" />
            <span class="switch-track"><span class="switch-thumb" /></span>
          </label>
        </div>
        <ol class="mask-list" v-if="erase.length">
          <li v-for="(s, i) in erase" :key="s.id" class="mask-row" @mouseenter="eraseHover = s.id" @mouseleave="eraseHover = null">
            <div class="mask-head erase-head">
              <button type="button" class="mask-name erase-name" :aria-expanded="eraseOpen === s.id"
                :title="t('erase.tune')" @click="eraseOpen = eraseOpen === s.id ? null : s.id">
                <JIcon v-if="s.mode === 'heal'" :icon="IconBandage" />
                {{ t(s.mode === 'heal' ? 'erase.itemHeal' : 'erase.item', { n: i + 1 }) }}</button>
              <button class="icon-mini" type="button" :title="t('erase.remove')" :aria-label="t('erase.remove')" @click="removeErase(s.id)">
                <JIcon :icon="IconX" />
              </button>
            </div>
            <div v-if="eraseOpen === s.id" class="erase-tune">
              <SliderRow :model-value="eraseParam(s, 'grow')" @update:model-value="v => setEraseParam(s.id, 'grow', v)"
                :label="t('erase.grow')" :min="0" :max="100" :reset-value="15" />
              <SliderRow :model-value="eraseParam(s, 'feather')" @update:model-value="v => setEraseParam(s.id, 'feather', v)"
                :label="t('erase.feather')" :min="0" :max="100" :reset-value="35" />
            </div>
          </li>
        </ol>
      </section>

      <!-- Relight: global light controls, then the rig (click the image to add). -->
      <section class="panel" v-if="editTab === 'relight' && activeSource">
        <header class="panel-head">
          <span class="panel-title">
            {{ t('panel.relight') }}
            <span v-if="relightActive(relight)" class="panel-dot" aria-hidden="true" />
          </span>
          <span v-if="relightBusy" class="panel-hint">{{ t('relight.analyzing') }}</span>
          <button class="ghost ghost-icon" type="button" :disabled="!relightActive(relight)" :title="t('common.reset')" :aria-label="t('common.reset')" @click="resetRelight"><JIcon :icon="IconReset" /></button>
        </header>
        <p class="control-note" :class="{ 'is-warn': !!relightError || (relightStatus && !relightStatus.available && relightStatus.reason !== 'downloading') }">
          {{ relightNotice ?? (relightHasGeometry ? t('relight.hint') : t('relight.analyzing')) }}
        </p>
        <div class="curve-tabs" :aria-label="t('relight.view')">
          <button v-for="(k, v) in (['relight.viewPhoto', 'relight.viewDepth', 'relight.viewNormals'] as const)" :key="k" type="button"
            :class="['curve-tab', { active: relightView === v }]" :disabled="v > 0 && !relightHasGeometry"
            @click="relightView = v as 0 | 1 | 2">{{ t(k) }}</button>
        </div>
        <SliderRow v-model="relight.ambient" :label="t('relight.ambient')" :min="-5" :max="1" :step="0.05" :reset-value="0" />
        <SliderRow :model-value="Math.round(relight.wrap * 100)" @update:model-value="v => relight.wrap = v / 100" :label="t('relight.wrap')" :min="0" :max="100" :reset-value="30" />
        <SliderRow :model-value="Math.round(relight.falloff * 100)" @update:model-value="v => relight.falloff = v / 100" :label="t('relight.falloff')" :min="0" :max="100" :reset-value="100" />
        <SliderRow :model-value="Math.round(relight.shadows * 100)" @update:model-value="v => relight.shadows = v / 100" :label="t('relight.shadows')" :min="0" :max="100" :reset-value="80" />
        <ol class="mask-list" v-if="relight.lights.length">
          <li v-for="(l, i) in relight.lights" :key="l.id" class="mask-row" :class="{ 'is-selected': selectedLight === l.id }"
            @click="selectedLight = l.id">
            <div class="mask-head erase-head">
              <input class="relight-color" type="color" :value="l.color" :title="t('relight.color')"
                @input="l.color = ($event.target as HTMLInputElement).value" @click.stop />
              <span class="mask-name">{{ t('relight.item', { n: i + 1 }) }}</span>
              <button class="icon-mini" type="button" :title="t('relight.remove')" :aria-label="t('relight.remove')" @click.stop="removeLight(l.id)">
                <JIcon :icon="IconX" />
              </button>
            </div>
          </li>
        </ol>
        <template v-if="selectedLightObj">
          <div class="curve-tabs">
            <button v-for="k in LIGHT_KINDS" :key="k" type="button" :class="['curve-tab', { active: (selectedLightObj.kind ?? 'point') === k }]"
              @click="selectedLightObj!.kind = k">{{ t(`relight.kind.${k}`) }}</button>
          </div>
          <SliderRow v-if="selectedLightObj.kind === 'spot'" :model-value="selectedLightObj.cone ?? 25"
            @update:model-value="v => selectedLightObj!.cone = v" :label="t('relight.cone')" :min="5" :max="80" :reset-value="25" />
          <SliderRow v-model="selectedLightObj.ev" :label="t('relight.intensity')" :min="-4" :max="6" :step="0.05" :reset-value="1" />
          <SliderRow :model-value="Math.round(selectedLightObj.lift * 100)" @update:model-value="v => selectedLightObj!.lift = v / 100"
            :label="t('relight.distance')" :min="-100" :max="95" :reset-value="40" />
        </template>
        <p v-else-if="!relight.lights.length" class="control-note">{{ t('relight.empty') }}</p>
      </section>

      <!-- Masks: the group list, then the selected group's components, the
           matte-preview switch and its local sliders (rendering/masks.ts). -->
      <section class="panel" v-if="editTab === 'masks' && activeSource" :class="{ 'is-off': isBypassed('masks') }">
        <header class="panel-head">
          <span class="panel-title">
            <button type="button" class="panel-switch" :class="{ 'is-on': !isBypassed('masks') }"
              :aria-pressed="!isBypassed('masks')" :title="t('panel.switch')" @click="toggleBypass('masks')" />
            {{ t('panel.masks') }}
            <span v-if="masks.length" class="panel-dot" aria-hidden="true" />
          </span>
          <button class="ghost ghost-icon" type="button" :disabled="!masks.length" :title="t('common.reset')" :aria-label="t('common.reset')" @click="resetMasks"><JIcon :icon="IconReset" /></button>
        </header>
        <!-- An accordion: the selected group opens under its own row, so the
             rows read as things to click. Names edit in place. -->
        <ol class="mask-list" v-if="masks.length">
          <li v-for="g in masks" :key="g.id" class="mask-row"
            :class="{ 'is-selected': selectedMask === g.id, 'is-off': !g.enabled }">
            <div class="mask-head" role="button" :aria-expanded="selectedMask === g.id" @click="selectedMask = g.id">
              <JIcon class="mask-chevron" :icon="IconChevronRight" weight="bold" />
              <input class="mask-name" type="text" :value="maskLabel(g)" :aria-label="t('mask.rename')" spellcheck="false"
                @change="g.name = ($event.target as HTMLInputElement).value.trim() || undefined"
                @keydown.enter="($event.target as HTMLInputElement).blur()" @keydown.stop />
              <label class="switch" :title="t('mask.enable')" @click.stop>
                <input type="checkbox" v-model="g.enabled" />
                <span class="switch-track"><span class="switch-thumb" /></span>
              </label>
              <button class="icon-mini" :class="{ 'is-on': g.invert }" type="button" :title="t('mask.invert')"
                :aria-pressed="g.invert" @click.stop="g.invert = !g.invert">
                <JIcon :icon="IconContrast" />
              </button>
              <button class="icon-mini" type="button" :title="t('mask.remove')" @click.stop="removeMask(g.id)">
                <JIcon :icon="IconX" />
              </button>
            </div>
            <div class="mask-body" v-if="selectedMask === g.id">
            <div class="mask-sub-head">
              <span>{{ t('mask.components') }}</span>
              <SelectMenu :model-value="''" :options="maskTypeOptions" :placeholder="t('mask.addComponent')"
                :aria-label="t('mask.addComponent')" :disabled="g.components.length >= MASK_COMPS" @update:model-value="addComponent" />
            </div>
            <div v-for="(c, i) in g.components" :key="i" class="mask-comp">
              <div class="mask-comp-head">
                <span class="mask-comp-type">{{ t(`mask.type.${c.type}`) }}</span>
                <!-- The first component has nothing to combine with. -->
                <div v-if="i > 0" class="hsl-tabs mask-ops">
                  <button v-for="op in MASK_OPS" :key="op" type="button" :class="{ active: c.op === op }"
                    :title="t(`mask.op.${op}`)" @click="c.op = op">{{ t(`mask.op.${op}`) }}</button>
                </div>
                <button class="icon-mini" :class="{ 'is-on': c.invert }" type="button" :title="t('mask.invert')"
                  :aria-pressed="c.invert" @click="c.invert = !c.invert">
                  <JIcon :icon="IconContrast" />
                </button>
                <button class="icon-mini" type="button" :title="t('mask.remove')" @click="g.components.splice(i, 1)">
                  <JIcon :icon="IconX" />
                </button>
              </div>
              <template v-if="c.type === 'ai'">
                <div class="curve-tabs">
                  <button v-for="k in AI_KINDS" :key="k" type="button" :class="['curve-tab', { active: c.kind === k }]"
                    @click="c.kind = k">{{ t(`ai.kind.${k}`) }}</button>
                </div>
                <p v-if="aiNotice" class="control-note">{{ aiNotice }}</p>
              </template>
              <template v-else-if="c.type === 'brush'">
                <div class="lb-actions">
                  <button class="ghost" type="button" :class="{ 'is-on': activeBrush?.gid === g.id && activeBrush?.idx === i }"
                    @click="toggleBrush(g.id, i)"><JIcon :icon="IconBrush" />
                    {{ activeBrush?.gid === g.id && activeBrush?.idx === i ? t('brush.painting') : t('brush.paint') }}</button>
                  <button class="ghost" type="button" :class="{ 'is-on': brushErase }" @click="brushErase = !brushErase">{{ t('brush.eraser') }}</button>
                  <button class="ghost" type="button" :disabled="!c.strokes.length" @click="c.strokes.splice(0)">{{ t('brush.clear') }}</button>
                </div>
                <p class="control-note">{{ t('brush.count', { n: c.strokes.length }) }}</p>
                <template v-if="activeBrush?.gid === g.id && activeBrush?.idx === i">
                  <SliderRow v-model="brushSize" :label="t('brush.size')" :min="2" :max="400" :reset-value="40" />
                  <SliderRow v-model="brushFeather" :label="t('brush.feather')" :min="0" :max="100" :reset-value="60" />
                  <SliderRow v-model="brushFlow" :label="t('brush.flow')" :min="5" :max="100" :reset-value="100" />
                </template>
              </template>
              <template v-else-if="c.type === 'luminance' || c.type === 'depth'">
                <p v-if="c.type === 'depth' && !relightHasGeometry" class="control-note">{{ t('relight.analyzing') }}</p>
                <SliderRow v-model="c.lo" :label="t('mask.range.lo')" :min="0" :max="100" />
                <SliderRow v-model="c.hi" :label="t('mask.range.hi')" :min="0" :max="100" :reset-value="100" />
                <SliderRow v-model="c.featherLo" :label="t('mask.range.featherLo')" :min="0" :max="100" />
                <SliderRow v-model="c.featherHi" :label="t('mask.range.featherHi')" :min="0" :max="100" />
              </template>
              <template v-else-if="c.type === 'color'">
                <!-- Stored in Oklab radians, shown in degrees. -->
                <SliderRow :model-value="deg(c.hue)" @update:model-value="v => c.hue = rad(v)" :label="t('mask.color.hue')" :min="-180" :max="180" />
                <SliderRow :model-value="deg(c.hueWidth)" @update:model-value="v => c.hueWidth = rad(v)" :label="t('mask.color.width')" :min="5" :max="120" :reset-value="35" />
              </template>
              <template v-else-if="c.type === 'radial'">
                <SliderRow :model-value="Math.round(c.feather * 100)" @update:model-value="v => c.feather = v / 100" :label="t('mask.range.feather')" :min="0" :max="100" :reset-value="50" />
                <SliderRow v-model="c.angle" :label="t('crop.angle')" :min="-180" :max="180" />
              </template>
            </div>

            <div class="control-row mask-overlay-row">
              <label class="control-label" for="mask-overlay">{{ t('mask.overlay') }}</label>
              <label class="switch">
                <input id="mask-overlay" type="checkbox" v-model="maskPreview" />
                <span class="switch-track"><span class="switch-thumb" /></span>
              </label>
            </div>
            <SliderRow v-for="sp in MASK_ADJUST_SLIDERS" :key="sp.key"
              v-model="g.adjust[sp.key]" :label="t(`slider.${sp.key}`)" :input-id="`m-${sp.key}`"
              :min="sp.min" :max="sp.max" :step="sp.step" :track="maskTintTrack(sp.key, g.adjust)" show-modified />
            </div>
          </li>
        </ol>
        <SelectMenu :model-value="''" :options="maskAddOptions" :placeholder="t('mask.add')"
          :aria-label="t('mask.add')" :disabled="masks.length >= MASK_GROUPS" @update:model-value="addMask" />
      </section>
      </div>
      </div>
      </div>
      <nav class="rail-tabs" :aria-label="t('rail.tabs')">
        <button v-for="tb in availableTabs" :key="tb.key" type="button"
          class="rail-tab" :class="{ 'is-on': editTab === tb.key }" :aria-pressed="editTab === tb.key"
          :disabled="tb.disabled"
          :title="t(`tab.${tb.key}`)" :aria-label="t(`tab.${tb.key}`)" @click="selectTab(tb.key)">
          <JIcon :icon="tb.icon" />
          <span v-if="tabEdited[tb.key]" class="rail-tab-dot" aria-hidden="true" />
        </button>
      </nav>
    </aside>

    <Filmstrip v-if="folderPhotos.length && libraryView === 'develop'" :sections="library.sections" :grouped="library.grouped" :active-id="activeId"
      :rendering="status === 'rendering'" :thumb-src="thumbSrc" :is-invalid="(id) => activeSource?.id === id && !!activeSource.invalid"
      @select="selectSource" @remove="(id) => removePhotosConfirmed([id])" @import="pickFiles" />

    <input ref="fileInput" type="file" :accept="IMPORT_ACCEPT" hidden multiple @change="onFileChange" />
    <input ref="folderInput" type="file" hidden multiple webkitdirectory @change="onFolderChange" />
    <transition name="fade"><div v-if="isDragging" class="drag-overlay">{{ t('drag.overlay') }}</div></transition>
    <!-- Copy Settings: which sections a copy takes (rendering/recipes.ts). -->
    <div v-if="copyDialog" class="copy-dialog-backdrop" @click.self="copyDialog = null" @keydown.esc="copyDialog = null">
      <div class="copy-dialog" role="dialog" aria-modal="true" :aria-label="t('recipe.copyTitle')">
        <header class="copy-dialog-head">
          <span>{{ t('recipe.copyTitle') }}</span>
          <button class="icon-mini" type="button" :aria-label="t('common.done')" @click="copyDialog = null"><JIcon :icon="IconX" /></button>
        </header>
        <div class="copy-dialog-grid">
          <label v-for="sec in RECIPE_SECTIONS" :key="sec" class="copy-check">
            <input type="checkbox" :checked="copySections.includes(sec)" @change="toggleCopySection(sec)" />
            <span>{{ t(`recipe.section.${sec}`) }}</span>
          </label>
        </div>
        <p class="control-note">{{ t('recipe.positionalNote') }}</p>
        <footer class="copy-dialog-foot">
          <button class="ghost" type="button" @click="copySections = [...RECIPE_SECTIONS]">{{ t('recipe.all') }}</button>
          <button class="ghost" type="button" @click="copySections = [...DEFAULT_SECTIONS]">{{ t('recipe.defaults') }}</button>
          <button class="ghost" type="button" @click="copySections = []">{{ t('recipe.none') }}</button>
          <button class="primary" type="button" :disabled="!copySections.length" @click="confirmCopy">{{ t('recipe.copy') }}</button>
        </footer>
      </div>
    </div>
    <transition name="fade">
      <div v-if="copyNotice || previewProgress" class="copy-pill">
        {{ previewProgress ? t('recipe.refreshing', { done: previewProgress.done, total: previewProgress.total }) : copyNotice }}
      </div>
    </transition>
    <transition name="fade">
      <div v-if="errorMessage && !activeSource?.invalid" class="error-toast" @click="errorMessage = null" :title="t('toast.dismiss')">
        {{ errorMessage }}
      </div>
    </transition>
  </div>
</template>
